# Referências, material real e telas de app

**Resumo:** vídeo sem referência sai genérico. O que prende é a pessoa reconhecer o que está vendo: a marca de verdade, o app que ela usa, o lugar, a notícia. Antes de animar, assista à referência a fundo, junte o material real do assunto e recrie as telas fiéis ao produto.

## 1. Assistir à referência de verdade

Chegou um link de referência ("quero igual a esse")? Assista com imagem **e** som, não meia dúzia de quadros:

1. Baixe: `yt-dlp -o "ref/%(id)s.%(ext)s" "<link>"` (vídeo privado ou com login não baixa: peça o arquivo).
2. Se tiver a skill `watch`, use ela para quadros com tempo e transcrição. Sem ela:
   ```bash
   ffmpeg -i ref/video.mp4 -vf "fps=2,scale=270:-1,tile=8x4" -frames:v 1 ref/folha.jpg
   uv run --with faster-whisper python -c "from faster_whisper import WhisperModel as M; [print(round(s.start,1), s.text) for s in M('base',device='cpu',compute_type='int8').transcribe('ref/video.mp4', language='pt')[0]]"
   ```
3. Escreva uma análise curta **antes do código**: estrutura (gancho, partes, final), ritmo (quantos cortes por segundo), tipo de legenda, cores, sons e o que gera comentário. Guarde junto do projeto, para não precisar reabrir o vídeo.
4. Use a referência para estrutura, ritmo e movimento. Não copie personagem, marca, texto ou desenho de outra pessoa.

**Perfil inteiro como referência** (ex.: "faz no estilo desse perfil"): pegue os 5 a 10 vídeos com mais views, analise o que eles têm em comum (gancho, duração, formato) e traga para o público e a língua da pessoa.

## 2. Material real do assunto

Tudo o que a fala cita aparece na tela:

- **Produto ou app próprio:** grave a tela real ou recrie a interface fielmente (seção 4).
- **Notícia, post ou site citado:** abra, capture, recorte e use como prova, com a fonte.
- **Marca, empresa ou app de terceiro:** ícone ou SVG oficial, só para identificar o assunto, nunca como parceiro.
- **Pessoa citada:** foto real, com crédito quando couber, sem uso enganoso. **Lugar, objeto ou dado:** imagem real ou print da fonte.
- Desenhado no motor (caderno, esquete): o "material real" vira o desenho fiel. A placa com o preço certo, o símbolo do serviço, o objeto do jeito que o público conhece.

## 3. A marca de verdade, tirada do site

Não confie na memória para cor e fonte:

1. Abra o site oficial e o CSS: cores com nome (`--color-primary`...) ou os hex mais usados; a fonte usada.
2. Procure `/brand`, `/press` ou o kit de imprensa, e capturas oficiais do produto.
3. Logo e ícones em SVG oficial.
4. Anote cada valor com a fonte num `MARCA.md` do projeto.

## 4. Telas de app dentro do vídeo

A tela "cara" é o que torna o anúncio crível:

- **Recriada em camadas, nunca print colado:** cada botão, texto e ícone é um elemento, para animar sozinho (entrar com mola, acender, ser tocado). Print só como prova (notícia, post).
- **Fiel ao produto real:** mesmas cores, fonte, raios e ícones do app que o público conhece (WhatsApp, banco, Gmail). Busque uma referência **atual** antes de desenhar.
- **Legível no celular:** texto de interface com pelo menos ~22 px num quadro de 1080 de largura. Uma ideia por tela: o que a fala diz é o maior elemento, e o resto fica neutro.
- **Estados de verdade:** digitação com o teclado subindo, botão que aperta, carregamento que carrega, notificação no formato real da plataforma.
- **Dados de exemplo plausíveis:** nomes, valores e horários que fazem sentido; nenhum dado pessoal real, e-mail ou senha na tela.
- **Regras de interface:**
  - uma família de fonte;
  - espaçamento em múltiplos de 4;
  - uma cor de destaque, com outras cores só com função (vermelho erro, verde sucesso);
  - sombra leve e larga;
  - botão que diz a consequência ("Pagar R$ 239,90", não "Confirmar");
  - nada de caixa dentro de caixa;
  - nada de degradê roxo-azul genérico.

Plataformas que o público brasileiro reconhece:

| Ação | Plataforma |
|---|---|
| mensagem com cliente | WhatsApp |
| pagamento | Pix e o banco que o público usa |
| notificação | banner do iPhone ou do Android |
| conversa com IA | a IA que o vídeo cita |
| post, repercussão | Instagram, X |
| planilha, agenda | Google Planilhas, Google Agenda |

## 5. Limites

- Logo de outra empresa só identifica o assunto. Nunca como parceira, e nunca dizendo que um produto está integrado quando não está.
- Empresa real não aparece como cliente num anúncio. Caso fictício usa marca fictícia (como o "Moedinha" do exemplo).
- Credenciais, e-mails e dados pessoais nunca aparecem na tela.
