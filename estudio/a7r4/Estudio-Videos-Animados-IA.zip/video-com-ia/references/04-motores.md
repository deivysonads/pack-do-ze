# Motores: como montar um vídeo novo

**Resumo:** cada motor é um componente React do Remotion que recebe a narração alinhada e uma lista simples (cenas, planos, selos ou cartões), todos presos a frases do roteiro. Para um vídeo novo, copie o exemplo do motor, troque as listas e registre a composição. Não precisa mexer em `src/kit/` para usar; mexa quando quiser um recurso novo.

## Vídeo novo em 5 passos

1. Roteiro em `roteiros/<nome>.txt`, voz e alinhamento ([03-voz.md](03-voz.md)). Saem `public/<nome>.wav` e `src/data/<nome>.json`.
2. Copie o exemplo do motor: `cp src/exemplos/esquete.tsx src/videos/<nome>.tsx`.
3. No arquivo novo, troque o `import d from '../data/<nome>.json'`, o `audio="<nome>.wav"`, as cenas, os selos e o texto. Ajuste os caminhos dos imports para `../kit/...`.
4. Registre em `src/index.tsx`:
   ```tsx
   import { MeuVideo, MEU_FIM } from './videos/<nome>';
   <Composition id="<nome>" component={MeuVideo} durationInFrames={q(MEU_FIM, 60)} {...REEL} />
   ```
   Use `LONGO` e `q(..., 30)` para YouTube deitado.
5. `npx tsc -p .` (confere erros) → `bash <skill>/scripts/folha.sh <nome> ...` → olhe → `bash <skill>/scripts/render.sh <nome>`.

## A peça que liga tudo: o achador

```tsx
const q = achador(W);       // W = (d as Narracao).words
q('Vinte quilos,')          // → segundo em que essa frase começa na fala
```

- Use de 2 a 4 palavras **exatas** do roteiro, na ordem. Maiúscula, acento e pontuação não importam.
- Pega a **primeira** vez que a frase aparece. Frase repetida ("E aí tu vê" e "E aí?")? Use palavras únicas.
- Frase que não existe quebra a folha com erro claro: `Frase não achada na narração: "..."`.
- Toda lista dos motores usa `f: '<frase>'` para dizer quando a coisa entra.

## Motor caderno: `ReelCaderno` (9:16)

```tsx
<ReelCaderno W={W} audio="meu.wav" cenas={CENAS} visual={{ corBone: '#E5484D' }} topo={<TopoSerie serie="o esquema" aviso="é zoeira" />} />
```

- `cenas: { f, x, C, oculos? }[]`: a cena começa na frase `f` (a 1ª começa no 0). `x` é onde o personagem fica: 280 (esquerda), 540 (meio) ou 800 (direita). Deixe o lado oposto livre para o desenho. `C` é o que aparece (componentes abaixo).
- Na troca, a cena nova desliza da direita (0,28 s) e o personagem anda até o novo `x` e dá dois quiques.
- Legenda automática embaixo, em frases de até 5 palavras, com a palavra falada acesa.
- Peças para a cena (todas com `at` em segundos, que é quando entram):
  - `<Pop at={q('...')} x={540} y={300} r={-3} s="pop">…</Pop>`: elemento que pula na tela, com som (`s={null}` = sem som).
  - `<Grande z={110} c={VERDE}>texto</Grande>`: título ou número.
  - `<Etiqueta f={AMARELO} z={70}>texto</Etiqueta>`: etiqueta de papel com sombra dura.
  - `<Conta de={a} ate={a + 1} alvo={360} pre="R$ " />`: número que rola até o valor.
  - `<Carimbo at={q('procura ajuda')} y={680} t="PROCURA AJUDA" />`: carimbo que bate, com som.
- Área livre: de y≈250 a y≈1000 (acima do personagem). A faixa do topo vai em y=150; a legenda, em y=1625.

## Motor esquete: `Esquete` (9:16)

```tsx
<Esquete W={W} audio="meu.wav" cenarios={CENARIOS} planos={PLANOS} selos={SELOS} visual={{ corRoupa: '#F59E0B' }} />
```

- **Cenário:** desenho em SVG numa tela de 1080×1920: `{ a: [x, y], Fundo, b?, Frente? }`.
  - `a` = pés do personagem principal (ex.: `[300, 1560]`).
  - `Fundo({ t })` = o desenho (use `Parede`, `Placa`, `Caixa`, `Carro`, `CelularSvg`, `Nota` ou o seu SVG).
  - `b = { x, y, P }` = o segundo personagem: um componente que recebe `{ t, fala }`. Use `<PersonagemVivo t={t} x={x} y={y} fala={fala} corRoupa="#fff" />`.
  - `Frente` = o que fica na frente dos personagens (balcão, mesa).
  - Parede até y=1250 e chão embaixo é a composição padrão.
- **Planos (câmera):** `{ f, set, foco? }[]`. A câmera corta no começo da frase `f`.
  - `foco: 'aberto'` = cena inteira; `'a'` = close no principal; `'b'` = close no segundo; `[x, y, zoom]` = um ponto do cenário (ex.: `[770, 900, 1.6]` na placa).
  - Dentro do plano, a câmera aproxima 2,5% por segundo (nunca parada) e nunca mostra fora do cenário.
  - Ritmo: um corte por frase. Alterne aberto e close.
- **Selos:** `{ f, ate?, x?, y, z?, c?, fundo?, r?, t }[]`. O selo entra na frase `f` e sai na frase `ate` ou no próximo corte de câmera.
  - Dois selos na mesma tela? Use `y` diferentes (~150 px de distância para `z` 80). Para sair antes do corte, ponha `ate`.
  - `t` aceita quebra de linha com `\n`.
  - A área livre fica de y≈250 a y≈750: a legenda vai em y=1600 e o personagem fica embaixo.
- **Duas vozes:** palavras com `quem: 'B'` (roteiro com linhas `A:`/`B:`) mexem a boca do personagem `b`.
- `visualNoTempo={(t) => ({ oculos: t > 10 })}` muda o visual no meio do vídeo. `mao={(t) => ({ maoD: Lupa, bracoD: 80 })}` põe um objeto na mão.

## Motor aula: `Aula` (16:9, 30 fps)

```tsx
<Aula W={W} audio="meu.wav" cartoes={CARTOES} visualA={{}} visualB={{ corRoupa: '#2FB36D', corBone: '#E5484D', oculos: true }} emojis={EMOJIS_PADRAO} />
```

- Fundo preto, uma palavra grande por vez ao lado de quem fala. Número e palavra longa saem maiores e em amarelo.
- `cartoes: { f, ate?, t, sub?, c? }[]` = cartão de tela cheia na frase `f`, por 2,6 s ou até `ate`. `passo(1, 'subtítulo', 'Passo número um:')` faz o "PASSO Nº 1".
  - **Poucos cartões.** Cartão cobre os personagens; mais de um a cada ~15 s esconde o vídeo.
- O personagem B (o amigo) entra quando fala e sai 1,5 s depois da última fala dele, com um "pop".
- `emojis`: lista de `[/^(palavra|outra)$/, '💸']`, comparada com a palavra sem acento. Monte a do seu nicho.
- Vídeo longo (4 a 12 min) renderiza em ~4 a 5 min por minuto de vídeo, num computador comum.

## Motor narrado: `Narrado` (9:16)

```tsx
<Narrado W={W} audio="meu.wav" cenas={CENAS} tema={{ marca: '#8B5CF6', brilho: 'rgba(139,92,246,.25)', tinta: '#1A1030' }} fim={FIM} />
```

- `cenas: { f, C, claro?, alerta? }[]`: cada cena começa 0,12 s antes da frase `f`, ganha uma câmera própria (entra com zoom vindo do desfoque, aproxima devagar, sai com zoom e desfoque) e um whoosh na troca.
- `C({ t0, dur })`: o tempo dentro da cena começa em 0. Para quem usa o tempo da fala, passe `at = q('...') - t0`.
- `claro: true` = cena clara para contraste (uma de vez em quando). `alerta: 0.5` = brilho vermelho de perigo.
- Peças:
  - `<Fala W={W} t0={t0} de={i('Teu dinheiro')} ate={i('foi?')} quebra={[i('no fim')]} y={640} size={84} quente={{ [i('some')]: '#FF5A5A' }} />`: texto palavra por palavra. `i = indice(W)` dá a posição da palavra. A fonte encolhe sozinha para a linha mais longa caber. Quebre as linhas à mão, com 4 a 9 palavras por frase.
  - `<Pilula at={...} pele="verde|vermelho|azul|escuro|branco" size={60} som="swipe">texto</Pilula>`: pílula 3D girando.
  - `<Celular3D at={...} tema={TEMA} w={480}>…tela do app…</Celular3D>`: celular inclinado que sobe. A tela dentro é um componente seu (veja `TelaApp` no exemplo). Recrie a tela do produto real.
  - `<Toque at={...} x={600} y={1140} />`: dedo que toca, com anel e clique.
- A cor da marca vem do site oficial do produto, nunca da memória ([07-referencias-e-telas.md](07-referencias-e-telas.md)).

## O personagem (`src/kit/personagem.tsx`)

- `Personagem` (pose fixa) e `PersonagemVivo` (respira, pisca, gesticula e mexe a boca enquanto `fala` é verdadeiro).
- Visual: `corRoupa`, `corBone`, `corAba`, `pele`, `terno`, `oculos`, `corrente="ZÉ"` (corrente de ouro com a sigla na medalha, para a versão "rico").
- Pose: `boca` ('fechada' | 'fala' | 'aberta' | 'tensa' | 'sorriso'), `bracoE`/`bracoD` em graus (0 = para baixo, 150 = para cima), `olhar` (−10 a 10), `suor`, `fecha` (piscar), `maoD` (objeto na mão direita, ex.: `Lupa`).
- **Crie a identidade:** escolha uma cor de boné e de roupa e use em todos os vídeos. O público reconhece o canal pelo personagem. Para o segundo personagem, use cores bem diferentes.
- O filtro `#rabisco` faz o traço tremer como desenho à mão. O `<Rabisco />` precisa estar uma vez no vídeo (os motores já põem).

## Regras de código que evitam dor de cabeça

- **Tudo é função do tempo** (`useT()` em segundos). Nada de `setTimeout`, `Math.random()` ou animação CSS solta: o mesmo quadro tem que sair igual em todo render. Para "aleatório", use conta fixa (`(i * 137) % 900`).
- **Nada de `transformStyle: preserve-3d`** em pílula e selo: a lateral briga com a face e pisca em quadros soltos.
- Dentro de uma cena com `Sequence` (motor narrado), o tempo é o da cena: `at = segundo_da_fala - t0`.
- Texto em cima de imagem ou celular: degradê escuro atrás do texto, ou mude o texto de lugar.
- Valor em reais nunca quebra linha: `whiteSpace: 'nowrap'`.
- Laço de rolagem (lista que roda): o período é a altura exata de um bloco que se repete, senão a lista pula na volta.
- Id da composição só com minúsculas, números e `-`.
- Fonte nova: baixe o `.woff2` (latin e latin-ext) para `public/fonts/` e acrescente em `src/kit/fontes.ts`. O render fica sem depender da internet.

## Ir além dos 4 motores

Pedido que nenhum motor cobre (3D, mapa, gráfico, vídeo gravado com legenda)? Monte uma composição nova com as peças do `kit/base.tsx` (`useT`, `Snd`, `achador`) e, se precisar, as skills oficiais do Remotion (`npx skills add remotion-dev/skills`). O 3D funciona com `@remotion/three`, e cada tomada escura precisa de uma fonte de luz que se veja na cena. Quando uma montagem se repetir em 3 vídeos ou mais, vire motor: componente em `src/kit/`, exemplo em `src/exemplos/` e uma linha aqui.
