# Som: efeitos, música e volume

**Resumo:** um som para cada coisa que entra, sai ou bate na tela, sempre o som do que se vê. A voz fica seca e na frente. A música, quando a pessoa quer, fica bem abaixo da voz. O volume final é nivelado para as redes pelo `render.sh`. Os efeitos do modelo foram sintetizados do zero e podem ser usados em qualquer vídeo, até comercial.

## Os efeitos do modelo (`public/sfx/`)

| Nome (`<Snd s="...">`) | Som | Use em |
|---|---|---|
| `pop` | estalo curto | selo, etiqueta, elemento que pula |
| `whoosh` | sopro curto | troca de cena, entrada rápida |
| `swipe` | sopro mais leve | deslize de cena, pílula |
| `click` | clique | toque, botão |
| `stamp` | batida de carimbo | carimbo, conclusão |
| `coin` | contador | número rolando, preço |
| `cash` | acorde de sucesso | total, dinheiro no fim da conta |
| `success` | sucesso longo | resultado, CTA |
| `notif` | sininho de notificação | notificação, mensagem |
| `error` | glitch | erro, alerta, golpe |
| `impact` | impacto grave | revelação, número chocante |
| `riser` | subida | antes de uma revelação (termina seco no corte) |
| `sparkle` | brilho | algo "mágico", conquista |
| `logo` | acorde de marca | logo, fecho |
| `tick`, `type`, `papel` | tecla, digitação, papel | digitação, folha, caderno |

```tsx
<Snd at={q('cento e oitenta')} s="cash" v={0.3} />   // at em segundos; v = volume 0 a 1
```

Os motores já tocam: `pop` no selo e no Pop, `whoosh`/`swipe` na troca de cena, `stamp` no carimbo, `click` no toque.

## Regras

1. **Um som para cada ação visível, e o som descreve a ação.** Card faz pop, botão faz clique, troca faz whoosh, carimbo bate, número rola.
2. **Só entra som que a imagem motiva.** Whoosh sem movimento e riser sem nada subindo descolam o som do vídeo.
3. **Densidade por ação, não por palavra:** no máximo dois efeitos soando juntos sob a voz.
4. **Volumes de partida:** efeitos entre 0,1 e 0,35 (`v`). Toquinho por palavra, se usar, entre 0,03 e 0,045: mais alto que isso incomoda.
5. **Tonal (nota musical) só em momento de hype, troca grande ou surpresa,** nunca em clique ou pop repetido.
6. **Voz seca:** sem reverb nem eco.
7. **Música:** só quando a pessoa pede. O padrão dos nossos Reels narrados é sem trilha. Com música, ela fica ~15 dB abaixo da voz, sobe nos respiros e cai seca ~0,5 s antes do drop.

## Música no Remotion

```tsx
import { Audio, staticFile, interpolate } from 'remotion';
<Audio src={staticFile('musica.mp3')} volume={(f) => interpolate(f, [0, 30], [0, 0.12], { extrapolateRight: 'clamp' })} />
```

Use música com licença: a biblioteca de áudio do YouTube, faixas livres com licença escrita, ou o som em alta escolhido **dentro do app** do Instagram ou do TikTok na hora de postar. Esse último não vai no arquivo de vídeo.

## Volume final

O `render.sh` aplica `loudnorm=I=-15:TP=-2:LRA=9` (Reel; −14 no YouTube) e um limitador, e mostra o resultado:

```
volume final I:   -15.5 LUFS    ← alvo -15 (Reel) / -14 (YouTube)
volume final Peak: -2.8 dBFS    ← tem que ficar abaixo de -2
```

Para conferir um arquivo qualquer: `ffmpeg -i video.mp4 -af ebur128=peak=true -f null -`.

## Trocar só o som de um vídeo pronto

Mudou só o som (efeito, música)? Não renderize a imagem de novo:

```bash
npx remotion render src/index.tsx <id> out/som.wav --codec=wav
ffmpeg -i out/<id>.mp4 -i out/som.wav -map 0:v -map 1:a -c:v copy \
  -af "loudnorm=I=-15:TP=-2:LRA=9,alimiter=limit=0.7:level=false" -c:a aac -b:a 192k out/<id>-som-novo.mp4
```

## Limite honesto

O Claude não ouve. Ele confere o volume pelos números e a sincronia pelo tempo das palavras, mas a pessoa precisa ouvir pelo menos o primeiro vídeo de cada formato, para dizer se o efeito está alto, baixo ou chato.
