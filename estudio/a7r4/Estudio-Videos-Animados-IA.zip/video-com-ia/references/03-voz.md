# Voz: narração grátis e o tempo de cada palavra

**Resumo:** a narração sai do Gemini TTS (grátis, com cota por dia), com uma voz ou com duas vozes em diálogo. Depois o Whisper, rodando no próprio computador, marca o segundo em que cada palavra é dita. É esse tempo que faz a animação acompanhar a fala. Voz gravada pela própria pessoa também serve, e é o melhor resultado quando ela fala bem.

## Gerar a narração (`voz.py`)

```bash
# uma voz
python3 <skill>/scripts/voz.py roteiros/meu-video.txt narracao.wav --voz Orus
# com outro jeito de ler
python3 <skill>/scripts/voz.py roteiros/meu-video.txt narracao.wav --voz Kore --estilo "como locutora de anúncio, confiante, ritmo firme, pausas curtas"
# diálogo: cada linha começa com "A: " ou "B: "
python3 <skill>/scripts/voz.py roteiros/aula.txt narracao.wav --voz-a Orus --voz-b Algenib --estilo "ritmo de YouTube, animado e engraçado"
```

- Rode de dentro da pasta do projeto: o script lê a chave do `.env` (`GEMINI_API_KEY`, `_2`, `_3`...).
- Sai um WAV 48 kHz sem silêncio no começo e no fim, e um `<saida>.txt` com o texto.
- Diálogo vai em blocos de 5 falas (o Gemini troca menos as vozes assim), emendados com 0,35 s de respiro.
- Modelo padrão: `gemini-2.5-flash-preview-tts`. Se o Google lançar outro, passe `--modelo <nome>`.

### Vozes que testamos

| Voz | Como soa | Uso |
|---|---|---|
| **Orus** | masculina, firme, narrador | a voz principal do nosso canal; aprovada logo de cara |
| **Algenib** | masculina, rouca, debochada | o segundo personagem (o amigo malandro) |
| **Puck** | masculina, animada | esquete leve |
| **Kore** | feminina, clara, confiante | anúncio, explicativo |
| **Leda** / **Aoede** | femininas, jovens e leves | conteúdo leve, lifestyle |
| **Charon** | grave, informativa | documentário, notícia |

Teste 2 ou 3 vozes com o mesmo trecho de 2 frases e deixe a pessoa escolher pelo ouvido. Uma vez escolhida, a voz da série não muda: é parte da identidade.

### Cota e o que fazer quando acaba

- A cota grátis é por **conta Google** e por dia. No nosso uso, foi para umas 5 narrações curtas por chave antes do erro 429. Ela volta à meia-noite do horário do Pacífico (umas 5h em Brasília).
- Com várias chaves, o script passa para a próxima sozinho. Depois de passar por todas, espera 60 s e tenta de novo (3 rodadas). Se ainda assim falhar, **pare e mande o roteiro para a pessoa gravar** em vez de insistir.
- Planeje: gere as vozes do dia logo cedo e anime durante o dia.

### Defeitos comuns do Gemini

| Defeito | Correção |
|---|---|
| Leu a instrução de estilo em voz alta no começo | o `alinhar.py` acha a 1ª palavra do roteiro e corta o que vem antes |
| Pausas enormes (voz de suspense) | estilo com "ritmo firme de Reels, pausas curtas"; gere 2 leituras e fique com a melhor |
| Pronúncia errada de sigla ou nome | escreva como se fala no roteiro ("IÁ", "píquis") e mantenha a grafia certa só na tela |
| Trocou as vozes no diálogo | blocos menores (o script já usa 5 falas); confira se as linhas começam exatamente com `A: ` e `B: ` |
| Saiu rápida demais | mais vírgulas e pontos no roteiro; estilo "ritmo calmo de conversa" |

## Ouvir antes de animar

Tudo depois depende do áudio. A pessoa ouve e aprova a voz antes da edição, se quiser aprovar. Se ela delegou, o alinhador é o seu ouvido: menos de 85% das palavras casadas indica frase pulada ou trocada.

## Voz gravada pela pessoa

Celular perto da boca, lugar quieto, sem eco. Ela pode ler o roteiro do próprio celular. Converta o arquivo para WAV e siga para o alinhamento:

```bash
ffmpeg -i gravacao.m4a -ac 1 -ar 48000 narracao.wav
```

Voz feita por IA na voz da pessoa (clone) só com a autorização dela, e nunca a voz de outra pessoa.

## Tempo de cada palavra (`alinhar.py`)

```bash
uv run --with faster-whisper python <skill>/scripts/alinhar.py narracao.wav roteiros/meu-video.txt meu-video
```

- Grava `public/meu-video.wav` (o áudio do vídeo) e `src/data/meu-video.json` (`{"words": [{"text", "start", "end", "quem"?}]}`).
- O texto que vai para a tela é o do **roteiro**: o Whisper só dá o tempo. O alinhador também converte número ("R$ 6", "1.584") para extenso, para casar com o roteiro.
- Na primeira vez, baixa o modelo `base` (~150 MB). `--modelo small` é mais preciso e mais lento.
- Use o mesmo nome em tudo: `meu-video` no alinhador, `audio="meu-video.wav"` no motor e `import d from '../data/meu-video.json'`.

## Trocar só o gancho

O vídeo está pronto e a pessoa quer outro começo? Não gere o áudio inteiro de novo:

```bash
python3 <skill>/scripts/troca_gancho.py narracao.wav "Frase nova do gancho." 3.42 nova.wav --voz Orus
```

`3.42` é o início da primeira palavra que fica (está no `src/data/<nome>.json`). Troque o gancho no roteiro, rode o `alinhar.py` no `nova.wav` e renderize de novo.
