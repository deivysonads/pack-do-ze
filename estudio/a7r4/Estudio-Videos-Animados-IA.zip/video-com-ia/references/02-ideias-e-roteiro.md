# Ideias e roteiro: o que dá view

**Resumo:** vídeo bom ensina, faz uma conta que ninguém fez ou conta um bastidor, e prende nos 3 primeiros segundos com um fato surpreendente. Série com gancho fixo cria hábito. Aqui estão as regras de conteúdo, os formatos que já funcionaram e um modelo de roteiro para cada motor.

## O que entra e o que não entra

**Entra**
- **Ensina algo útil de verdade:** passo a passo, direito que a pessoa não conhece, jeito de economizar.
- **"Como fazer R$ X" que ninguém conta:** negócio real, com a conta na tela (custo, preço, por dia, por mês), números conferidos.
- **Curiosidade e bastidor:** como uma empresa ganha dinheiro, um golpe explicado, a história por trás de uma notícia.
- **Imposto e governo explicados:** o que acontece se não pagar, a regra nova, os jeitos **legais** de pagar menos. Fato e lei, sem lado político.
- **Assunto em alta e meme do momento**, desde que o vídeo ensine algo ou conte um bastidor.

**Não entra**
- Humor de identificação raso, que só faz o público pensar "é verdade" e não ensina nada (ex.: "novembro, o mês do trabalhador"). No nosso teste, esse tipo foi reprovado e ficou com as menores views.
- Promessa de dinheiro fácil, pirâmide, aposta, golpe ensinado, sonegação.
- Conta inventada. Número tem fonte; número de exemplo aparece como "valores de exemplo" ou "aproximado".

## Gancho: os 3 primeiros segundos

- Comece pelo fato, nunca por "oi, gente" ou "hoje eu vou falar".
- Fórmulas que funcionaram: "Forma de ganhar dinheiro que tu não conta nem pra tua mãe"; "Esse negócio parece besteira, mas paga as contas"; "Imagina que…"; "[objetivo] é fácil, e eu vou te mostrar em N passos"; um número absurdo ("82,8 milhões de brasileiros com o nome sujo").
- **Série = gancho fixo com o final variando.** Exemplo: "…que tu não conta nem pra tua mãe", "…nem pro padre", "…nem pra galinha". O público reconhece a série no primeiro segundo. Não mude o começo da fórmula no meio da série.
- Escreva o gancho por último, depois de saber qual é o fato mais forte do roteiro.

## Formatos que já funcionaram

| Formato | Estrutura | Motor | Por que funciona |
|---|---|---|---|
| **"O esquema"** (zoeira) | gancho fixo → o esquema absurdo e inofensivo em 3 ou 4 cenas → a conta fechando (× por dia, por mês) → "resumindo: …" → "mano, procura ajuda" → "manda pro teu amigo que…" + aviso "é zoeira" | caderno | foi o Reel campeão do nosso canal: 16,2 mil views contra ~1,3 mil dos outros. Conta que fecha + absurdo + pedido de compartilhar para um amigo específico |
| **"Negócios que parecem besteira"** | gancho → o problema comum → preço → quanto rende por dia, semana e mês, com a conta na tela → resumindo engraçado → manda pro amigo | esquete | formato de perfil gringo que viraliza; o personagem em versão "rico" (corrente de ouro) reforça |
| **"[Objetivo] é fácil"** (YouTube) | número de impacto → promessa "é fácil, em N passos" → passo nº 1… cada passo com exemplo real → o amigo interrompe com a dúvida/besteira do público → o personagem corrige → fecho com o próximo vídeo | aula | vídeo longo de ensino retém quando cada passo é um cartão e a "objeção" vem pela boca do amigo, com humor |
| **Sobrevivência em segunda pessoa** | "Imagina que…" (cena e hora exata) → regras numeradas na tela → a virada que quebra uma regra → final com 2 escolhas ("comenta A ou B; a maioria decide a parte 2") | esquete ou 3D | o comentário vira a parte 2: o algoritmo entrega mais e o público volta |
| **Curiosidade / bastidor** | fato que choca → como funciona por dentro (2 ou 3 cenas) → o que isso muda para quem assiste | narrado ou caderno | o público compartilha porque "aprendeu algo" |
| **Anúncio de produto** | dor em 1 frase → produto resolve (tela real) → o detalhe que convence → chamada clara | narrado | ver [07-referencias-e-telas.md](07-referencias-e-telas.md): tela recriada do produto real |

Alterne os formatos na semana e veja qual o público prefere. Um formato que não pegou depois de 5 a 10 vídeos sai da rotina. O que passou muito da média vira série.

## Como escrever o roteiro

- **Escreva como se fala.** Frases curtas, de 4 a 12 palavras, no jeito de falar do público. Gíria do público, sem forçar.
- **Números por extenso** ("cento e oitenta reais"), para a voz ler certo. Na tela eles viram "R$ 180" pelos selos.
- **Pronúncia:** escreva como deve soar ("IÁ" se a voz fala "ía"; "pix" vira "píquis" se precisar).
- **Pontuação dá o respiro:** vírgula e ponto são as pausas. Texto sem vírgula sai corrido demais.
- **Uma ideia por frase**: cada frase vira um corte de cena ou um selo.
- **Duração:** a voz fala ~3 a 3,5 palavras por segundo. Reel de 25 a 45 s ≈ 80 a 140 palavras. YouTube de 4 min ≈ 750 palavras.
- **Final:** um pedido de ação específico ("manda pro teu amigo que…", "comenta A ou B", "segue para a parte 2"). Nunca "deixa o like" genérico.
- **Confira os fatos antes da voz.** Busque a fonte de cada número (site oficial, notícia de veículo grande) e anote no `README.md` do projeto.
- **A pessoa aprova o roteiro?** Se ela quiser revisar, mostre o texto inteiro antes de gastar cota de voz. Se ela delegou, siga.

## Modelos de roteiro

**Caderno ("o esquema" ou "a conta que ninguém faz")**
```
[gancho da série]: [nome do esquema].
[Cena 1: a situação comum, 1 ou 2 frases.]
[Cena 2: o que tu faz, com o detalhe absurdo.]
[Cena 3: preço] [conta: X vezes Y: total por dia]. [Total no mês].
Resumindo: [o absurdo numa frase]. Mano, procura ajuda.
Manda pro teu amigo que [o amigo específico].
```

**Esquete ("negócios que parecem besteira")**
```
Esse negócio parece besteira, mas [paga as contas / dá dinheiro]: [negócio].
[A dor: todo mundo tem/precisa de X.] Tu cobra [preço].
[O que precisa para fazer.] [Quantos por dia.] [Conta do dia].
[Conta do mês]. Resumindo: [frase engraçada]. Manda pro teu amigo [que tem o problema].
```

**Aula (YouTube 16:9), com linhas `A:` e `B:`**
```
A: [Número ou fato de impacto.]
A: [Objetivo] é fácil, e eu vou te mostrar em [N] passos.
A: Passo número um: [ação]. [Exemplo real com número.]
B: [Dúvida ou besteira que o público pensaria.]
A: [Corrige com humor e com o dado.]
... (um bloco por passo)
A: [Resumo dos passos em 1 frase.] [Próximo vídeo.]
```

**Narrado (anúncio)**
```
[Dor em uma pergunta.]
Com o [produto], tu [ação principal] e ele [benefício automático].
[Detalhe que convence, mostrado na tela real.]
[Resultado em linguagem simples.] [Chamada: baixa/compra/clica agora.]
```

## Guarde cada projeto

Uma pasta por vídeo, com o `roteiro.txt`, a narração, as fontes dos números e o resultado: `roteiros/<data>-<tema>.txt` no projeto, ou uma pasta por vídeo se a pessoa preferir. Anote o que deu certo (views, comentários) para escolher a próxima série.
