# Render e revisão: ver rápido, entregar uma vez

**Resumo:** primeiro uma folha de quadros parados (segundos), depois o render final uma vez só, e por fim a conferência do arquivo pronto: quadros, volume e saltos. Mudou um trecho? Renderize só esse trecho. Nunca diga que está pronto sem olhar o quadro de verdade.

## 1. Folha de quadros (antes de tudo)

```bash
bash <skill>/scripts/folha.sh <id> 0.5 2 4 6 8 10 12 14
```

- Compila o projeto uma vez e tira cada quadro em ~2 s. Sai `out/folha-<id>.jpg`, com o segundo escrito em cada quadro.
- Escolha os segundos: o começo de cada cena (o segundo de cada `f:` no `src/data/<nome>.json`), o meio de cada conta, a fala do segundo personagem e o último quadro.
- **Abra a imagem e olhe** (o Claude lê a imagem). Procure:
  - texto cortado na borda;
  - selo em cima de selo ou de placa;
  - elemento que apareceu antes da fala;
  - personagem cortado no close;
  - câmera mostrando fora do cenário;
  - cena escura demais;
  - linha de legenda vazando.
- Corrija e tire a folha de novo, até ficar limpo.

## 2. Prévia (opcional)

`PREVIA=1 bash <skill>/scripts/render.sh <id>`: meia resolução, em paralelo, para conferir ritmo e som. Prévia nunca é entregue. Para mexer com prévia ao vivo: `npm run studio`.

## 3. Render final

```bash
bash <skill>/scripts/render.sh <id> out/<id>.mp4
```

O que o script faz:
1. Compila uma vez e lê quadros, fps e tamanho.
2. Renderiza a imagem em pedaços de 4000 quadros com `--concurrency=1`. Em paralelo, camadas pesadas somem em quadros soltos; em pedaços, um computador fraco não estoura a memória.
3. Renderiza o áudio sozinho (WAV).
4. Junta tudo, nivela o volume (−15 LUFS em pé, −14 deitado, pico ≤ −2) e etiqueta a cor BT.709.
5. Mostra o volume final e roda o detector de saltos.

Tempo de render num notebook comum: Reel de 20 a 30 s leva ~2 a 3 min; vídeo 16:9 a 30 fps leva ~4 a 5 min por minuto de vídeo.

## 4. Conferir o arquivo pronto

- **Volume:** o script mostra. Alvo −15 (Reel) ou −14 (YouTube); pico abaixo de −2.
- **Saltos:** `detectar_saltos.py` acusa:
  - **salto:** quadro muito diferente do anterior;
  - **chapado:** quadro liso, preto ou branco;
  - **isolado:** um quadro que destoa dos vizinhos.

  Para cada tempo acusado, tire o quadro antes, no tempo e depois:
  ```bash
  for t in 10.65 10.68 10.70; do ffmpeg -v error -y -ss $t -i out/<id>.mp4 -frames:v 1 -vf scale=360:-1 out/s$t.png; done
  ```
  É corte de propósito (troca de cena no esquete, palavra trocando na aula, piscada)? Pode ficar. Não é (algo sumindo, pulando, tela preta)? É defeito: corrija e renderize de novo.
- **Folha do vídeo final:** `ffmpeg -i out/<id>.mp4 -vf "fps=1,scale=270:-1,tile=6x5" -frames:v 1 out/final.jpg` e olhe.
- **A pergunta de comparação:** lado a lado com a referência ou o melhor vídeo anterior, no tamanho do celular, "a referência grita mais?" (contraste, tamanho, peso do texto). Se sim, ainda não superou.

## 5. Consertar só um trecho

Erro num trecho de um vídeo longo? Não refaça 30 minutos de render:

```bash
npx remotion render src/index.tsx <id> out/trecho.mp4 --frames=1800-2400 --muted --concurrency=1
```

Depois troque o trecho no `ffmpeg`, cortando o vídeo pronto nos mesmos quadros e emendando com `concat`. Mudou só o som? Veja [06-som.md](06-som.md): renderize só o WAV.

## Erros que já aconteceram

| Defeito | Causa | Correção |
|---|---|---|
| Pílula ou selo 3D sumindo em quadros soltos | `preserve-3d` + render em paralelo | pílula plana (o kit já é) e `--concurrency=1` (o script já usa) |
| Texto ou lista animada não aparece | usou o tempo do vídeo dentro de uma cena com `Sequence` | dentro da cena, `at = segundo - t0` |
| Personagem dá um tranco na troca de cena | movimento que termina no meio (ex.: pulo cortado) | todo movimento começa e termina parado no lugar (o kit já corrige o quique) |
| Cartão com 1 quadro preto no corte | título nascendo com tamanho 0 | nascer em 70% e crescer (o kit já faz) |
| Lista rolando em laço pula na volta | período do laço diferente da altura do bloco | período = altura exata de um bloco que se repete |
| Primeiro quadro do 3D quase preto | luz física do three.js pede intensidade alta | aumente a luz; toda tomada escura com uma fonte de luz visível |
| Composição não registra | id com `_` | só minúsculas, números e `-` |
| Render quebra com caminho estranho | pasta com acento ou na nuvem | pasta sem acento, fora do iCloud/OneDrive |
| `NetworkError` / `Failed to load resource` de `fonts.gstatic.com` | o Chrome não conseguiu baixar uma fonte do Google na hora do render | use fontes do disco: baixe o `.woff2` para `public/fonts/` e registre em `src/kit/fontes.ts` (as do modelo já são assim). Nunca dependa de `@remotion/google-fonts` num projeto com muitos vídeos: ele carrega as fontes de todos em todo render |
| Projeto grande e render de um vídeo só travando por causa de outro | o `src/index.tsx` importa todos os vídeos | crie uma entrada só com aquele vídeo (`src/entrada-<nome>.tsx` com `registerRoot`) e rode `ENTRADA=src/entrada-<nome>.tsx bash render.sh <id>` (o `folha.sh` aceita o mesmo) |
