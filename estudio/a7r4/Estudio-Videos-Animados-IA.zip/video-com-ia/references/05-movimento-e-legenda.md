# Movimento, legenda e ritmo: os números que funcionam

**Resumo:** a pergunta de controle em cada movimento é "isso está humano ou robotizado?". Robotizado é o que anima, para morto e volta num tranco. Humano é continuar vivo o tempo todo, nem que seja com o mínimo: deriva lenta, respiração, balanço. Os números abaixo são pontos de partida testados. Se a peça pedir outro valor, use e anote no projeto.

## A cena se constrói pela fala

1. **Nada aparece antes de ser dito.** Cada elemento entra na palavra que o justifica, até ~0,15 s antes e nunca segundos antes. A cena começa vazia, ou só com a legenda, e vai se montando. A exceção é o "herói" de que a voz já está falando (o celular onde a ação acontece).
2. **A tela só troca depois da frase.** A cena nova começa no fim da última palavra da frase anterior, mais um respiro curto, ou na primeira palavra da frase nova (os motores fazem assim).
3. **Um elemento real ou uma metáfora para cada ideia dita.** "Negócio local" pede o mapa real. "Mais lento que fila de posto" pede a fila e o painel de senha. Frase sem elemento tem que funcionar só com a legenda.
4. **Antes de animar, escreva a tabela `palavra → segundo → o que entra`.** Na folha de quadros, procure qualquer coisa que apareceu sem ter sido falada.

## Legenda

| Regra | Valor |
|---|---|
| Tamanho da frase | 4 a 9 palavras por linha, no máximo 2 linhas, quebradas à mão |
| Tempo de leitura | cada frase fica ~0,6 s depois da última palavra entrar; a próxima nunca adianta a fala |
| Sem quebra automática | a fonte encolhe para caber (nunca nasce uma 3ª linha escondida) |
| Destaque | a palavra-chave na cor de destaque e um peso acima, no máximo uma por frase; nada de marca-texto (faixa atrás da palavra) |
| Reels "legenda amarela e preta" | maiúscula, branca com contorno preto de 10 px, palavra falada em amarelo, até 4 palavras (motor esquete) |
| Texto pequeno e limpo | no anúncio narrado, texto pequeno entrando palavra por palavra e saindo do desfoque; nunca legenda gigante |
| Nada atrás do herói | legenda numa faixa própria (topo ou base), nunca em cima do celular ou do personagem |
| Interface no vídeo | pelo menos 22 px de texto num quadro de 1080 de largura |

## Movimento

| Regra | Valor de partida |
|---|---|
| Mola padrão (card, botão, balão, selo) | passa ~12% do alvo e assenta em ~0,6 s; em código: `spring({ stiffness: 120–140, damping: 16–20 })` ou `Easing.out(Easing.back(1.6–2))` em 0,28 s |
| Câmera e troca de cena | `Easing.bezier(.86, 0, .07, 1)` para trocas rápidas; `(.33, 0, .23, 1)` para câmera viajando |
| Câmera nunca morta | deriva contínua lenta (zoom de ~2,5% por segundo, ou 7% por cena) + balanço suave. Parada total só de propósito, em 2 ou 3 momentos-chave |
| Duração | nada abaixo de ~0,8 s em movimento de câmera, exceto chicote (~0,27 s) e mergulho (~0,37 s) |
| Entrada e saída | entra já em movimento (desacelerando); sai acelerando ou com desfoque, cortando no pico |
| Troca por zoom e desfoque | a cena nova entra vindo do desfoque com escala um pouco maior; a antiga **continua opaca**, só desfoca e cresce (duas cenas semitransparentes deixam um véu cinza) |
| Quadros por segundo | Reel 60 fps sempre (nada de mola que treme); YouTube longo 30 fps |
| Ritmo do Reel | algo novo a cada ~1 s; troca de cena a cada ~2 a 4 s, na primeira palavra da frase; nunca mais de 1,5 s sem nada mudar |
| Ritmo de tutorial | menos é mais: uma ideia principal por vez, no máximo 3 coisas além da legenda |
| Texto de destaque | sempre com acabamento: degradê, brilho, contorno ou sombra dura |
| Digitação na tela | teclado subindo e teclas reais; nunca texto "esticando" por máscara |
| Clique | dedo ou cursor visível em todo clique, com onda e som de clique |
| Personagem | respira (balanço de ~5 px), pisca a cada ~3,7 s, gesticula enquanto fala, dá um quique na troca de cena (começa e termina no chão) |

## Identidade do vídeo

- **Assunto com marca forte?** O vídeo veste a marca: fonte, cores e ícones tirados do site oficial.
- **Assunto sem marca?** Base limpa e uma cor de destaque só.
- **Série:** mesma faixa no topo, mesmo personagem, mesmas cores e mesmo gancho. A identidade da série é o que o público reconhece no primeiro segundo.
- **Cena clara de vez em quando** num vídeo escuro dá contraste (motor narrado: `claro: true`).

## Recursos que funcionam (escolha, não use todos)

| Recurso | Quando |
|---|---|
| Câmera que fecha na ação (escala 1,3 a 1,8) | digitação, toque, número na placa |
| Contador que rola | todo número citado |
| Carimbo | a conclusão ou o "procura ajuda" |
| Selo com sombra dura | cada número da conta |
| Pílula 3D girando | benefício, rótulo de marca |
| Celular 3D inclinado | produto ou app |
| Emoji que pula na palavra-chave | aula 16:9 |
| Pilha de palavras | benefícios falados em série: a palavra dita no centro, a anterior sobe apagada |
| Transição de pontos | só 2 ou 3 viradas grandes por vídeo |

## Checklist antes de renderizar

- [ ] Tabela palavra → elemento escrita; nenhum elemento antes da palavra.
- [ ] Legenda legível, sem 3ª linha, nada atrás do herói.
- [ ] Nenhum texto cortado na borda nem em cima de outro texto (folha de quadros).
- [ ] Câmera nunca sai do cenário e nunca fica parada.
- [ ] Toda conta na tela confere (faça a conta de novo).
- [ ] Nenhuma tela vazia por mais de ~0,3 s (exceto cena escura que respira até ~1 s antes da 1ª palavra).
