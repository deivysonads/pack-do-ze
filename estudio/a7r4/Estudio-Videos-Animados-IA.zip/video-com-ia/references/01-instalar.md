# Instalar: do computador vazio ao primeiro vídeo

**Resumo:** quatro programas grátis (Node, ffmpeg, uv e Chrome), uma cópia do projeto modelo e uma chave grátis do Gemini. Leva de 10 a 20 minutos. No fim, renderize um exemplo para provar que tudo funciona antes de fazer o primeiro vídeo de verdade.

## 1. Instalar esta skill no Claude Code

A skill é a pasta `video-com-ia/` (com o `SKILL.md` dentro). Coloque em um destes lugares:

- **Para todos os projetos:** `~/.claude/skills/video-com-ia/` (no Windows: `C:\Users\<voce>\.claude\skills\video-com-ia\`).
- **Só num projeto:** `<pasta do projeto>/.claude/skills/video-com-ia/`.

Recebeu um `.zip`? Descompacte e mova a pasta `video-com-ia` para um desses lugares. Feche e abra o Claude Code. Para conferir, peça: "quais skills você tem?". A `video-com-ia` tem que aparecer.

## 2. Programas

Confira o que já existe antes de instalar: `node -v`, `ffmpeg -version`, `uv --version`.

| Programa | Para quê | Mac | Windows |
|---|---|---|---|
| **Node.js 18 ou mais novo** | roda o Remotion (o motor de vídeo em código) | `brew install node` | `winget install OpenJS.NodeJS.LTS` |
| **ffmpeg** | corta, junta e nivela áudio e vídeo | `brew install ffmpeg` | `winget install Gyan.FFmpeg` |
| **uv** | roda os scripts Python sem bagunçar o computador | `brew install uv` | `winget install astral-sh.uv` |
| **Google Chrome** | o Remotion desenha cada quadro num navegador | já costuma ter | já costuma ter |
| **Python 3** | os scripts de voz | já vem no Mac (`python3`) | `winget install Python.Python.3.12` |

No Mac sem Homebrew, instale primeiro pelo site brew.sh. A pessoa precisa colar o comando e digitar a senha do Mac: o Claude não faz esse passo por ela. Depois de instalar, feche e abra o terminal.

## 3. O projeto de vídeos

```bash
cp -R <skill>/modelo ~/meus-videos      # Windows (PowerShell): Copy-Item -Recurse <skill>\modelo $HOME\meus-videos
cd ~/meus-videos
npm install                              # ~1 minuto, ~200 MB
cp .env.exemplo .env
```

Use uma pasta **sem acento, sem "ç" e fora do iCloud ou do OneDrive**. Alguns renderizadores quebram com acento no caminho, e a sincronização da nuvem trava os arquivos durante o render.

Estrutura:

```
meus-videos/
├── src/kit/        ← os 4 motores e as peças (não precisa mexer para usar)
├── src/exemplos/   ← um vídeo pronto de cada motor (copie para começar o seu)
├── src/videos/     ← os SEUS vídeos (crie a pasta)
├── src/data/       ← tempo das palavras de cada narração (o alinhador grava)
├── src/index.tsx   ← a lista de vídeos (composições)
├── public/         ← áudios das narrações e public/sfx/ com os efeitos
├── roteiros/       ← os roteiros em texto
└── out/            ← renders e folhas de quadros
```

## 4. Chave grátis do Gemini (a voz)

1. A pessoa entra em https://aistudio.google.com/apikey com a conta Google dela e clica em **Create API key**. Ela mesma faz isso; o Claude não cria a conta nem digita senha.
2. Ela cola a chave no arquivo `.env` do projeto, na linha `GEMINI_API_KEY=`. Se ela colar a chave no chat, grave no `.env` e não repita o valor.
3. **Mais de uma conta Google?** Cada conta dá a sua cota grátis por dia. Ponha `GEMINI_API_KEY_2=`, `GEMINI_API_KEY_3=`... e o `voz.py` passa para a próxima quando uma acaba.

Sem chave, ainda dá para fazer vídeo: a pessoa grava a narração no celular (perto da boca, lugar quieto) e segue do alinhamento em diante.

## 5. Prova de que funciona

```bash
cd ~/meus-videos
npx remotion compositions src/index.tsx          # lista os 4 exemplos
bash <skill>/scripts/folha.sh exemplo-caderno 1 5 9 13 17
bash <skill>/scripts/render.sh exemplo-caderno out/teste.mp4
```

A folha sai em `out/folha-exemplo-caderno.jpg`: abra e olhe. O render leva de 1 a 4 minutos e termina mostrando o volume final (perto de −15 LUFS). Se der erro de navegador, passe o caminho do Chrome: `CHROME="/caminho/do/chrome" bash ...`. Sem Chrome, o Remotion baixa o navegador dele sozinho na primeira vez.

Para ver e mexer no vídeo com prévia ao vivo: `npm run studio` abre o Remotion Studio no navegador.

## 6. Opcional, mas ajuda

| O quê | Para quê | Como |
|---|---|---|
| Skill `watch` | o Claude assistir a um vídeo de referência (quadros e transcrição) | `npx skills add bradautomates/claude-video` |
| `yt-dlp` | baixar referência do YouTube ou do Instagram | `brew install yt-dlp` / `winget install yt-dlp` |
| Skills oficiais do Remotion | documentação do Remotion à mão | `npx skills add remotion-dev/skills` |
| Conector do Metricool | agendar post no Instagram, YouTube e TikTok direto do Claude | em claude.ai, Configurações → Conectores ([09-publicar.md](09-publicar.md)) |
| GitHub CLI (`gh`) | link público do vídeo, que o agendador precisa | `brew install gh` e `gh auth login` (a pessoa faz o login) |
