# Publicar: agendar, horários e rotina

**Resumo:** o vídeo pronto vai para o Instagram (Reels), o YouTube (Shorts e vídeos longos) e o TikTok por um agendador. O que usamos é o Metricool, que tem plano grátis e um conector que o Claude chama direto. Postar é uma ação pública: o Claude só agenda sozinho se a pessoa autorizou isso claramente.

## Antes de agendar

- **A pessoa autorizou postar sem aprovar?** Se não, mostre o vídeo e a legenda e espere o OK. Se sim, registre essa regra no projeto (ex.: no `README.md`: "pode agendar sozinho, até 6 por dia").
- **Vídeo conferido** ([08-render-e-revisao.md](08-render-e-revisao.md)): volume, saltos, folha final.
- **Números conferidos** e marcados como exemplo quando forem.

## Metricool (o que usamos)

1. A pessoa cria a conta grátis em metricool.com e conecta Instagram, YouTube e TikTok lá. Ela faz esse login; o Claude não.
2. Liga o conector do Metricool em claude.ai, em Configurações → Conectores. Ele aparece no Claude Code da mesma conta.
3. **O vídeo precisa de um link público** (o Metricool baixa o arquivo do link). Um jeito grátis é um repositório público no GitHub, usando os anexos de uma "release":
   ```bash
   gh repo create meus-videos-publicos --public     # uma vez (a pessoa faz o gh auth login antes)
   gh release create v1 --repo <usuario>/meus-videos-publicos --title videos --notes "vídeos para agendar"   # uma vez
   gh release upload v1 out/<id>.mp4 --repo <usuario>/meus-videos-publicos --clobber
   # link: https://github.com/<usuario>/meus-videos-publicos/releases/download/v1/<id>.mp4
   ```
   O link de um anexo novo pode levar até 1 minuto para parar de dar 404. **Tudo nesse repositório é público:** só vídeo que já vai ser postado.
4. Agende com a ferramenta `createScheduledPost` do conector:
   - data e hora no fuso da marca (ex.: `America/Sao_Paulo`);
   - redes (Instagram Reels, YouTube);
   - o link do vídeo;
   - a legenda;
   - no YouTube, título e categoria. Capa (`videoThumbnailUrl`) só aparece se o canal for verificado no YouTube.
5. Confira na resposta se o post ficou agendado. Se a chamada falhar sem resposta clara, olhe o calendário do Metricool antes de tentar de novo, para não duplicar.

**Pegadinhas:**
- No plano grátis, não existe a aprovação do próprio Metricool (o "para revisão" dá erro 403). A aprovação, se a pessoa quiser, fica com ela, no chat ou num painel.
- O Metricool não apaga post que já foi publicado: isso é no app da rede.
- Rascunho no Metricool não publica sozinho.

Sem Metricool: o agendador do próprio app (Instagram e YouTube Studio agendam de graça). O Claude prepara vídeo, legenda e horário, e a pessoa sobe.

## Horários e volume

- **Reels e Shorts:** até 6 por dia, em horário fixo (usamos 9h, 11h, 13h, 15h, 17h e 19h de Brasília). Mais que isso vira spam e a conta perde alcance.
- **YouTube longo (16:9):** 1 por dia, no mesmo horário (usamos 18h).
- Mesmo vídeo vertical no Reels, no Shorts e no TikTok: pode, e é o mais eficiente.
- Série: mesmo dia ou mesmo horário para cada série ajuda o público a voltar.

## Legenda do post

```
[gancho em 1 linha, diferente do da fala]
[1 a 2 linhas com o dado principal ou a dúvida]
[pedido de ação: "comenta X que eu faço a parte 2", "manda pro amigo que..."]
[3 a 5 hashtags do nicho]
```

- No YouTube, o título tem até ~60 caracteres, com a palavra que a pessoa buscaria. A descrição repete o dado e a fonte dos números.
- Nada de promessa que o vídeo não cumpre.

## Rotina sugerida de "6 vídeos por dia"

1. **De manhã:** escolher 6 ideias (as que mais deram view viram série; 1 ou 2 formatos novos para testar) e escrever os 6 roteiros.
2. Gerar as 6 vozes cedo: a cota grátis volta de madrugada.
3. Alinhar, montar, tirar a folha e renderizar um por vez. Agendar cada um assim que fica pronto, sem esperar fechar o lote.
4. **No fim do dia:** anotar views e comentários dos posts da véspera e decidir a próxima série.

Painel de acompanhamento (opcional): uma página com a fila (título, data, rede, status, link) ajuda a pessoa a ver o que já está agendado. Mantenha os dados dela fora de lugares públicos.
