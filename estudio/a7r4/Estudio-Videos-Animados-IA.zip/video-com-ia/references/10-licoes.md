# Lições: o que já testamos e não funcionou

**Resumo:** antes de prometer "vídeo com IA realista" ou "voz local", leia isto. São testes reais feitos num Mac M1 de 8 GB em novembro de 2026. Num computador comum, gerar vídeo realista localmente sai feio, curto ou lento demais. O que entrega é animação em código (os motores desta skill) com voz do Gemini.

## Gerar vídeo com IA no próprio computador

| Testamos | Resultado | Conclusão |
|---|---|---|
| **Draw Things + Wan 2.1 T2V 1.3B (8-bit)** | 25 quadros = 1,5 s de vídeo em ~7 min, rosto derretido, sem voz | ruim para pessoa falando; o modelo bom (14B) não cabe em 8 GB |
| **LTX-Video 2.3** | memória de troca acima de 15 GB, travou | não roda em 8 GB |
| **SadTalker** (foto que fala) | 1 min de render por segundo de fala, 256 px, cara de foto animada; precisou de vários remendos para rodar no chip do Mac | a pessoa reprovou ("isso é uma bosta") |
| **Sites "grátis" de vídeo com IA** | créditos que acabam em 1 ou 2 vídeos, marca d'água | servem para testar, não para 6 vídeos por dia |

Se a pessoa precisa de vídeo realista, os caminhos honestos são placa de vídeo emprestada (Kaggle: umas 30 h por semana grátis; Google Colab), rodando Wan 2.1/2.2 completo, ou um serviço pago. Avise o custo e o tempo antes. Para "pessoa falando com a câmera", a própria pessoa gravando no celular ainda ganha de tudo.

## Voz

| Testamos | Resultado |
|---|---|
| **Gemini TTS (Orus)** | a melhor, de graça; a pessoa aprovou na hora ("ficou absurda") |
| Vozes masculinas geradas na ElevenLabs | recusadas; a feminina "Keren" agradou, mas a ElevenLabs é paga para volume |
| Kokoro (local) | perdeu para o Orus no ouvido da pessoa; desinstalado |
| Qwen3-TTS, Voicebox (locais) | testados e removidos |
| App de voz local com interface (VoiceStudio) | lento demais para a rotina |
| Áudio gravado pela própria pessoa | o melhor resultado quando ela fala bem; a IA só tira o tempo das palavras |

## Imagem

- A geração de imagem do Gemini **não tem cota grátis** (dá erro de cota ou de crédito). Os ícones e cenários dos motores são desenhados em código, de graça e sem direito autoral de terceiros.
- Emojis da Apple funcionam bem como ícone no Chrome do Mac. No Windows, os emojis do sistema são outros: confira a folha.

## Conteúdo

- Humor de identificação raso ("todo mundo já passou por isso") teve as menores views e foi reprovado.
- O campeão foi um esquema absurdo com a conta fechando na tela e o pedido de mandar para um amigo específico: 16,2 mil views contra ~1,3 mil dos outros.
- Gancho errado mata a série. Depois de definido ("Forma de ganhar dinheiro que tu não conta nem pra tua mãe"), não troque o começo.
- Formato "Reels" num pedido de YouTube longo foi erro grave: vídeo longo é 16:9 (1920×1080). Confirme o formato antes de renderizar.

## Ferramentas

- **Metricool grátis:** agenda, mas não tem aprovação nem apaga post publicado ([09-publicar.md](09-publicar.md)).
- **Análise de tendências (vidIQ e parecidos):** os créditos de "assistir vídeo longo" acabam rápido. Baixar com `yt-dlp` e analisar localmente é de graça.
- **Remotion:** render em paralelo derrubou camadas em quadros soltos; `--concurrency=1` resolveu. O id com `_` não registra.
- **Python 3.15 e bibliotecas de IA antigas:** muitas não instalam. Use `uv` com a versão de Python que a biblioteca pede (`uv venv -p 3.10`) e instale fora da pasta do projeto de vídeos.
