#!/usr/bin/env bash
# Render final de uma composição do Remotion, do jeito que não quebra em computador fraco:
#   1. imagem em pedaços de 1000 quadros (PASSO=...), cada um num processo novo, um quadro por vez (--concurrency=1: em paralelo, camadas somem em quadros soltos);
#   2. o áudio sozinho (WAV), uma vez;
#   3. junta tudo, nivela o volume para as redes e confere o volume final.
#
# Uso (de dentro da pasta do projeto Remotion):
#   bash <skill>/scripts/render.sh <id-da-composicao> [saida.mp4]
#   PREVIA=1 bash <skill>/scripts/render.sh <id>     # prévia rápida: meia resolução, em paralelo, sem pedaços
#   LUFS=-14 bash ...                                 # volume alvo (padrão: -15 em vídeo em pé, -14 em vídeo deitado)
#   CHROME=/caminho/do/chrome bash ...                # navegador (padrão: o Chrome do Mac, se existir; senão o do Remotion)
#   ENTRADA=src/outra-entrada.tsx bash ...            # outro arquivo de entrada (padrão: src/index.tsx)
set -euo pipefail
ID="${1:?uso: render.sh <id-da-composicao> [saida.mp4]}"
OUT="${2:-out/$ID.mp4}"
[ -d public ] && [ -f src/index.tsx ] || { echo "Rode de dentro da pasta do projeto Remotion (a que tem src/index.tsx)."; exit 1; }
mkdir -p "$(dirname "$OUT")"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

BR=()
CH="${CHROME:-/Applications/Google Chrome.app/Contents/MacOS/Google Chrome}"
[ -x "$CH" ] && BR=(--browser-executable="$CH")

# Compila uma vez (cada pedaço usa o mesmo pacote) e lê quadros, fps e tamanho da composição.
npx remotion bundle "${ENTRADA:-src/index.tsx}" --out-dir="$TMP/pacote" >/dev/null 2>&1 || { echo "Erro ao compilar: rode npx remotion compositions src/index.tsx para ver o erro."; exit 1; }
PK="$TMP/pacote"
INFO="$(npx remotion compositions "$PK" "${BR[@]}" 2>/dev/null | grep -E "^$ID[[:space:]]" || true)"
[ -n "$INFO" ] || { echo "Composição '$ID' não encontrada. Rode: npx remotion compositions src/index.tsx"; exit 1; }
FPS="$(echo "$INFO" | awk '{print $2}')"
TAM="$(echo "$INFO" | awk '{print $3}')"
TOTAL="$(echo "$INFO" | awk '{print $4}')"
W="${TAM%x*}"; H="${TAM#*x}"
LUFS="${LUFS:-$([ "$H" -gt "$W" ] && echo -15 || echo -14)}"
echo "$ID: $TOTAL quadros a $FPS fps ($TAM), volume alvo $LUFS LUFS"

if [ "${PREVIA:-0}" = 1 ]; then
  npx remotion render "$PK" "$ID" "$OUT" --scale=0.5 --crf=28 --timeout=120000 "${BR[@]}"
  echo "prévia: $OUT (não é a entrega)"; exit 0
fi

T0=$(date +%s)
PASSO="${PASSO:-1000}"; i=0; : > "$TMP/lista.txt"
for ((a = 0; a < TOTAL; a += PASSO)); do
  b=$((a + PASSO - 1)); [ $b -ge $((TOTAL - 1)) ] && b=$((TOTAL - 1))
  echo "pedaço $((i + 1)): quadros $a-$b"
  npx remotion render "$PK" "$ID" "$TMP/p$i.mp4" --frames=$a-$b --muted --codec=h264 --crf=17 --concurrency=1 --timeout=120000 --log=error "${BR[@]}"
  echo "file '$TMP/p$i.mp4'" >> "$TMP/lista.txt"; i=$((i + 1))
done
echo "áudio"
npx remotion render "$PK" "$ID" "$TMP/audio.wav" --codec=wav --log=error "${BR[@]}"
ffmpeg -v error -y -f concat -safe 0 -i "$TMP/lista.txt" -c copy "$TMP/video.mp4"
ffmpeg -v error -y -i "$TMP/video.mp4" -i "$TMP/audio.wav" -map 0:v -map 1:a -c:v copy \
  -af "loudnorm=I=$LUFS:TP=-2:LRA=9,alimiter=limit=0.7:level=false" -c:a aac -b:a 192k -ar 48000 \
  -colorspace bt709 -color_primaries bt709 -color_trc bt709 -movflags +faststart -shortest "$OUT"
echo "pronto: $OUT em $(( $(date +%s) - T0 )) s"
ffmpeg -hide_banner -nostats -i "$OUT" -af ebur128=peak=true -f null - 2>&1 | grep -E "^\s+(I|Peak):" | sed 's/^ */  volume final /'

# Conferência de quadros pulados ou vazios (precisa do uv; pule com CONFERE=0)
if [ "${CONFERE:-1}" = 1 ] && command -v uv >/dev/null; then
  uv run -q --with numpy python "$(dirname "$0")/detectar_saltos.py" "$OUT" || echo "ATENÇÃO: veja os saltos acima. Todo salto que sobrar tem que ser corte de propósito."
fi
