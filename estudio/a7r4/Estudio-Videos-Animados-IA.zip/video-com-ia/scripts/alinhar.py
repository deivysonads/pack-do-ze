#!/usr/bin/env python3
"""Tempo de cada palavra da narração, casado com o roteiro (roda no seu computador, sem internet depois do 1º uso).

Uso (de dentro da pasta do projeto Remotion):
    uv run --with faster-whisper python <skill>/scripts/alinhar.py narracao.wav roteiro.txt <nome>

- Transcreve com o faster-whisper (modelo "base", ~150 MB, baixa sozinho no 1º uso) e casa palavra a palavra com o
  roteiro (difflib). Palavras que o Whisper errou herdam o tempo das vizinhas. O texto na tela fica igual ao roteiro.
- Roteiro com linhas "A: ..." / "B: ..." (diálogo) grava quem fala em cada palavra ("quem": "A" ou "B").
- Se a voz começou lendo algo que não está no roteiro (o Gemini às vezes lê a instrução de estilo em voz alta),
  o áudio é cortado na primeira palavra do roteiro e os tempos andam junto.
- Grava public/<nome>.wav (o áudio que o vídeo usa) e src/data/<nome>.json ({ "words": [{text, start, end, quem?}] }).
"""
import argparse, difflib, json, os, re, subprocess, sys

ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
ap.add_argument('audio'); ap.add_argument('roteiro'); ap.add_argument('nome')
ap.add_argument('--modelo', default='base', help='base (rápido) ou small (mais preciso, mais lento)')
ap.add_argument('--lingua', default='pt')
a = ap.parse_args()
if not os.path.isdir('public') or not os.path.isdir('src'):
    sys.exit('Rode de dentro da pasta do projeto Remotion (a que tem public/ e src/).')
from faster_whisper import WhisperModel  # noqa: E402

# Roteiro → lista de (palavra, quem)
txt = []
for l in open(a.roteiro, encoding='utf-8'):
    l = l.strip()
    if not l:
        continue
    quem = None
    if l[:3] in ('A: ', 'B: '):
        quem, l = l[0], l[3:]
    txt += [(w, quem) for w in l.split()]

U = 'zero um dois três quatro cinco seis sete oito nove dez onze doze treze catorze quinze dezesseis dezessete dezoito dezenove'.split()
D = ['', '', 'vinte', 'trinta', 'quarenta', 'cinquenta', 'sessenta', 'setenta', 'oitenta', 'noventa']
C = ['', 'cento', 'duzentos', 'trezentos', 'quatrocentos', 'quinhentos', 'seiscentos', 'setecentos', 'oitocentos', 'novecentos']


def extenso(n):
    """Número inteiro por extenso em português (até centenas de milhões), como a voz fala."""
    if n < 20: return U[n]
    if n < 100: return D[n // 10] + ('' if n % 10 == 0 else ' e ' + U[n % 10])
    if n == 100: return 'cem'
    if n < 1000: return C[n // 100] + ('' if n % 100 == 0 else ' e ' + extenso(n % 100))
    if n < 1_000_000:
        m, r = divmod(n, 1000)
        cab = 'mil' if m == 1 else extenso(m) + ' mil'
        return cab + ('' if r == 0 else (' e ' if r < 100 or r % 100 == 0 else ' ') + extenso(r))
    m, r = divmod(n, 1_000_000)
    cab = 'um milhão' if m == 1 else extenso(m) + ' milhões'
    return cab + ('' if r == 0 else (' e ' if r < 100 else ' ') + extenso(r))


def por_extenso(stt):
    """O Whisper escreve "R$ 6", "22" e "1.584"; o roteiro tem "seis reais", "vinte e dois"... Expande para casar."""
    junto = []
    for w in stt:
        p = w['word']
        if junto and re.fullmatch(r'[.,]\d{3}[.,!?]?', p) and re.fullmatch(r'\d+', junto[-1]['word'].rstrip('.,')):
            junto[-1] = {'word': junto[-1]['word'].rstrip('.,') + p, 'start': junto[-1]['start'], 'end': w['end']}
        elif junto and p == '$' and junto[-1]['word'] == 'R':
            junto[-1] = {'word': 'R$', 'start': junto[-1]['start'], 'end': w['end']}
        else:
            junto.append(dict(w))
    saida, moeda = [], None
    for w in junto:
        p = w['word']
        if p in ('R$', 'R$,'):
            moeda = w; continue
        m = re.fullmatch(r'(R\$)?(\d{1,3}(?:[.]\d{3})+|\d+)(%?)([.,!?:;]?)', p)
        if m:
            ini = moeda['start'] if moeda else w['start']
            ws = extenso(int(m.group(2).replace('.', ''))).split()
            if m.group(1) or moeda: ws.append('reais')
            if m.group(3): ws += ['por', 'cento']
            d = (w['end'] - ini) / len(ws)
            saida += [{'word': x, 'start': ini + d * k, 'end': ini + d * (k + 1)} for k, x in enumerate(ws)]
        else:
            if moeda: saida.append(moeda)
            saida.append(w)
        moeda = None
    return saida


segs, _ = WhisperModel(a.modelo, device='cpu', compute_type='int8').transcribe(a.audio, language=a.lingua, word_timestamps=True)
stt = por_extenso([{'word': w.word.strip(), 'start': w.start, 'end': w.end} for s in segs for w in s.words])
if not stt:
    sys.exit('O Whisper não ouviu nenhuma palavra: confira o áudio.')
limpa = lambda x: re.sub(r'[^\w]', '', x.lower())
sm = difflib.SequenceMatcher(None, [limpa(w) for w, _ in txt], [limpa(w['word']) for w in stt], autojunk=False)
blocos = [m for m in sm.get_matching_blocks() if m.size]
casadas = sum(m.size for m in blocos)

# Corte do começo: fala que não é do roteiro antes da primeira palavra casada.
corte = 0.0
if blocos and blocos[0].a == 0 and blocos[0].b >= 3 and stt[blocos[0].b]['start'] > 0.6:
    corte = max(0.0, stt[blocos[0].b]['start'] - 0.1)
    print(f'aviso: a voz falou {blocos[0].b} palavras fora do roteiro no começo; cortando {corte:.2f} s')

ts = [None] * len(txt)
for m in blocos:
    for k in range(m.size):
        ts[m.a + k] = (stt[m.b + k]['start'] - corte, stt[m.b + k]['end'] - corte)
dur = stt[-1]['end'] - corte
i = 0
while i < len(ts):
    if ts[i]:
        i += 1; continue
    j = i
    while j < len(ts) and not ts[j]:
        j += 1
    ini = ts[i - 1][1] if i else 0
    fim = ts[j][0] if j < len(ts) else dur
    d = max(fim - ini, 0.01) / (j - i)
    for k in range(i, j):
        ts[k] = (ini + d * (k - i), ini + d * (k - i + 1))
    i = j

saida = f'public/{a.nome}.wav'
cmd = ['ffmpeg', '-v', 'error', '-y'] + (['-ss', f'{corte:.3f}'] if corte else []) + ['-i', a.audio, '-ac', '1', '-ar', '48000', '-c:a', 'pcm_s16le', saida]
subprocess.run(cmd, check=True)
os.makedirs('src/data', exist_ok=True)
words = []
for (w, quem), t in zip(txt, ts):
    d = {'text': w, 'start': round(max(0, t[0]), 3), 'end': round(max(0, t[1]), 3)}
    if quem:
        d['quem'] = quem
    words.append(d)
json.dump({'words': words}, open(f'src/data/{a.nome}.json', 'w', encoding='utf-8'), ensure_ascii=False)
taxa = casadas / max(1, len(txt))
print(f'{a.nome}: {casadas} de {len(txt)} palavras casadas ({taxa:.0%}), fala termina em {words[-1]["end"]:.1f} s')
if taxa < 0.85:
    print('ATENÇÃO: menos de 85% casou. A voz pode ter pulado ou trocado frases: ouça antes de montar o vídeo.')
