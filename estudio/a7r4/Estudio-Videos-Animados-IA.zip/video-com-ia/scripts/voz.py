#!/usr/bin/env python3
"""Narração com o Gemini TTS (grátis, com cota diária), uma voz ou diálogo de duas vozes.

Uso:
    python3 voz.py roteiro.txt narracao.wav                       # uma voz (padrão: Orus)
    python3 voz.py roteiro.txt narracao.wav --voz Kore --estilo "animada, ritmo de Reels"
    python3 voz.py dialogo.txt narracao.wav --voz-a Orus --voz-b Algenib   # linhas "A: ..." e "B: ..."

Roteiro de uma voz: o texto puro (parágrafos separados por linha em branco).
Diálogo: uma fala por linha, começando com "A: " ou "B: ". Vai em blocos de 5 falas (o Gemini erra menos assim)
e os blocos são emendados com 0,35 s de respiro.

Chave: GEMINI_API_KEY (e, se tiver mais de uma conta, GEMINI_API_KEY_2, _3...) no ambiente ou num arquivo .env
na pasta atual. Pegue grátis em https://aistudio.google.com/apikey. Quando uma chave bate o limite (429) ou não
tem crédito (402/403), o script tenta a próxima; depois de passar por todas, espera 60 s e tenta de novo (3 rodadas).

Sai um WAV 48 kHz mono sem silêncio no começo e no fim, e um <saida>.txt com o texto puro (o alinhador usa).
Só biblioteca padrão do Python + ffmpeg.
"""
import argparse, base64, json, os, subprocess, sys, tempfile, time, urllib.error, urllib.request

VOZES = 'Zephyr Puck Charon Kore Fenrir Leda Orus Aoede Callirrhoe Autonoe Enceladus Iapetus Umbriel Algieba Despina Erinome Algenib Rasalgethi Laomedeia Achernar Alnilam Schedar Gacrux Pulcherrima Achird Zubenelgenubi Vindemiatrix Sadachbia Sadaltager Sulafat'.split()


def chaves():
    ks = []
    env = {}
    if os.path.exists('.env'):
        for l in open('.env', encoding='utf-8'):
            if '=' in l and not l.lstrip().startswith('#'):
                k, v = l.split('=', 1)
                env[k.strip()] = v.strip().strip('"\'')
    nomes = sorted({k for k in list(os.environ) + list(env) if k.startswith('GEMINI_API_KEY') or k.startswith('GEMINI_FREE_KEY')})
    for n in nomes:
        v = os.environ.get(n) or env.get(n)
        if v and v not in ks:
            ks.append(v)
    if not ks:
        sys.exit('Sem chave: crie uma grátis em https://aistudio.google.com/apikey e ponha GEMINI_API_KEY=... no arquivo .env desta pasta.')
    return ks


def chama(corpo, modelo, ks):
    url = f'https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent'
    for rodada in range(3):
        for i, k in enumerate(ks):
            req = urllib.request.Request(url, json.dumps(corpo).encode(), {'Content-Type': 'application/json', 'x-goog-api-key': k})
            try:
                d = json.load(urllib.request.urlopen(req, timeout=300))
                return base64.b64decode(d['candidates'][0]['content']['parts'][0]['inlineData']['data'])
            except urllib.error.HTTPError as e:
                print(f'  chave {i + 1}: erro {e.code}' + (' (sem cota hoje)' if e.code == 429 else ''), flush=True)
                if e.code not in (429, 402, 403, 500, 503):
                    raise
            except (KeyError, IndexError):
                print(f'  chave {i + 1}: resposta sem áudio, tentando de novo', flush=True)
        if rodada < 2:
            print('  todas as chaves falharam; esperando 60 s', flush=True)
            time.sleep(60)
    sys.exit('A VOZ FALHOU: as chaves estão sem cota (a cota grátis volta à meia-noite do horário do Pacífico, ~5h em Brasília). '
             'Grave o roteiro com a sua voz ou tente mais tarde.')


def pcm_para_wav(pcm, saida, pad=0.0):
    corta = 'silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.03,areverse,silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.03,areverse,aresample=48000'
    if pad:
        corta += f',apad=pad_dur={pad}'
    with tempfile.NamedTemporaryFile(suffix='.pcm', delete=False) as f:
        f.write(pcm)
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 's16le', '-ar', '24000', '-ac', '1', '-i', f.name, '-af', corta, '-ac', '1', '-c:a', 'pcm_s16le', saida], check=True)
    os.remove(f.name)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('roteiro'); ap.add_argument('saida')
    ap.add_argument('--voz', default='Orus', help='voz única (ex.: Orus, Kore, Puck, Leda, Charon, Algenib)')
    ap.add_argument('--voz-a', default='Orus'); ap.add_argument('--voz-b', default='Algenib')
    ap.add_argument('--estilo', default='como um narrador de Reels animado, ritmo rápido, tom de conversa com um amigo, sem pausas longas')
    ap.add_argument('--modelo', default='gemini-2.5-flash-preview-tts')
    a = ap.parse_args()
    linhas = [l.strip() for l in open(a.roteiro, encoding='utf-8') if l.strip()]
    dialogo = all(l[:3] in ('A: ', 'B: ') for l in linhas)
    ks = chaves()
    if not dialogo:
        texto = open(a.roteiro, encoding='utf-8').read().strip()
        corpo = {'contents': [{'parts': [{'text': f'Leia em português do Brasil, {a.estilo}. Leia só o texto abaixo, sem ler esta instrução:\n\n{texto}'}]}],
                 'generationConfig': {'responseModalities': ['AUDIO'], 'speechConfig': {'voiceConfig': {'prebuiltVoiceConfig': {'voiceName': a.voz}}}}}
        t = time.time(); pcm_para_wav(chama(corpo, a.modelo, ks), a.saida, pad=0.3)
        open(a.saida + '.txt', 'w', encoding='utf-8').write(texto + '\n')
        print(f'voz pronta: {a.saida} ({time.time() - t:.0f} s)')
        return
    blocos = [linhas[i:i + 5] for i in range(0, len(linhas), 5)]
    tmp = tempfile.mkdtemp()
    partes = []
    for i, b in enumerate(blocos):
        corpo = {'contents': [{'parts': [{'text': f'Leia este diálogo em português do Brasil, {a.estilo}. A é o narrador; B é o amigo dele, que interrompe com as dúvidas do público. Leia só as falas:\n\n' + '\n'.join(b)}]}],
                 'generationConfig': {'responseModalities': ['AUDIO'], 'speechConfig': {'multiSpeakerVoiceConfig': {'speakerVoiceConfigs': [
                     {'speaker': 'A', 'voiceConfig': {'prebuiltVoiceConfig': {'voiceName': a.voz_a}}},
                     {'speaker': 'B', 'voiceConfig': {'prebuiltVoiceConfig': {'voiceName': a.voz_b}}}]}}}}
        p = f'{tmp}/b{i:02d}.wav'; pcm_para_wav(chama(corpo, a.modelo, ks), p); partes.append(p)
        print(f'bloco {i + 1}/{len(blocos)} pronto', flush=True)
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'lavfi', '-t', '0.35', '-i', 'anullsrc=r=48000:cl=mono', '-c:a', 'pcm_s16le', f'{tmp}/pausa.wav'], check=True)
    with open(f'{tmp}/lista.txt', 'w') as f:
        for i, p in enumerate(partes):
            if i: f.write(f"file '{tmp}/pausa.wav'\n")
            f.write(f"file '{p}'\n")
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', f'{tmp}/lista.txt', '-af', 'apad=pad_dur=0.3', '-c:a', 'pcm_s16le', a.saida], check=True)
    open(a.saida + '.txt', 'w', encoding='utf-8').write('\n'.join(linhas) + '\n')
    print(f'diálogo pronto: {a.saida} ({len(blocos)} blocos)')


if __name__ == '__main__':
    main()
