#!/usr/bin/env bash
# Folha de contato: tira quadros parados de uma composição em vários segundos e junta numa imagem só.
# Serve para conferir ANTES do render inteiro: texto cortado, elemento antes da hora, câmera saindo do cenário, cena escura.
# Uso (de dentro do projeto Remotion):  bash <skill>/scripts/folha.sh <id> <seg1> <seg2> ...   (ex.: 0.5 3 6 9 12)
# Sai em out/folha-<id>.jpg.
set -euo pipefail
ID="${1:?uso: folha.sh <id> <segundos...>}"; shift
[ $# -gt 0 ] || { echo "Passe os segundos que quer ver (ex.: 0.5 3 6 9)"; exit 1; }
BR=(); CH="${CHROME:-/Applications/Google Chrome.app/Contents/MacOS/Google Chrome}"; [ -x "$CH" ] && BR=(--browser-executable="$CH")
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT; mkdir -p out; n=0
# Compila o projeto UMA vez; cada quadro sai do pacote pronto em ~2 s.
npx remotion bundle "${ENTRADA:-src/index.tsx}" --out-dir="$TMP/pacote" >/dev/null 2>&1 || { echo "Erro ao compilar: rode npx remotion compositions src/index.tsx para ver o erro."; exit 1; }
FPS="$(npx remotion compositions "$TMP/pacote" "${BR[@]}" 2>/dev/null | grep -E "^$ID[[:space:]]" | awk '{print $2}')"
[ -n "$FPS" ] || { echo "Composição '$ID' não encontrada."; exit 1; }
for s in "$@"; do
  f=$(python3 -c "print(round($s*$FPS))")
  npx remotion still "$TMP/pacote" "$ID" "$TMP/q$(printf %02d $n).png" --frame=$f --scale=0.4 "${BR[@]}" >/dev/null 2>&1
  ffmpeg -v error -y -i "$TMP/q$(printf %02d $n).png" -vf "drawtext=text='${s}s':x=12:y=12:fontsize=28:fontcolor=white:box=1:boxcolor=black@0.6" "$TMP/r$(printf %02d $n).png" 2>/dev/null || cp "$TMP/q$(printf %02d $n).png" "$TMP/r$(printf %02d $n).png"
  n=$((n + 1))
done
COLS=$(( n < 6 ? n : 6 )); LIN=$(( (n + COLS - 1) / COLS ))
ffmpeg -v error -y -framerate 1 -i "$TMP/r%02d.png" -vf "tile=${COLS}x${LIN}:padding=6:color=white" -frames:v 1 "out/folha-$ID.jpg"
echo "folha: out/folha-$ID.jpg ($n quadros)"
