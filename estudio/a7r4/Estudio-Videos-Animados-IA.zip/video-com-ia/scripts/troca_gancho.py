#!/usr/bin/env python3
"""Troca só o começo (o gancho) de uma narração pronta, sem gastar cota gerando o áudio inteiro de novo.

Uso:
    python3 troca_gancho.py narracao.wav "Frase nova do gancho." <segundo_onde_o_resto_começa> nova.wav [--voz Orus]

O <segundo> é o início da primeira palavra que FICA (pegue no src/data/<nome>.json). A frase nova é gerada com o
voz.py (mesma voz e estilo), emendada com 0,12 s de respiro e o resto do áudio antigo.
Depois, troque o gancho no roteiro.txt e rode o alinhar.py de novo no nova.wav.
"""
import os, subprocess, sys, tempfile

if len(sys.argv) < 5:
    sys.exit(__doc__)
narr, frase, corte, out = sys.argv[1], sys.argv[2], float(sys.argv[3]), sys.argv[4]
extra = sys.argv[5:]
d = tempfile.mkdtemp()
open(f'{d}/g.txt', 'w', encoding='utf-8').write(frase)
subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'voz.py'), f'{d}/g.txt', f'{d}/g.wav'] + extra, check=True)
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', f'{d}/g.wav', '-af', 'areverse,silenceremove=start_periods=1:start_threshold=-45dB,areverse,apad=pad_dur=0.12', '-ac', '1', '-ar', '48000', '-c:a', 'pcm_s16le', f'{d}/a.wav'], check=True)
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', str(corte), '-i', narr, '-ac', '1', '-ar', '48000', '-c:a', 'pcm_s16le', f'{d}/b.wav'], check=True)
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', f'{d}/a.wav', '-i', f'{d}/b.wav', '-filter_complex', '[0][1]concat=n=2:v=0:a=1', '-c:a', 'pcm_s16le', out], check=True)
print('gancho trocado:', out)
