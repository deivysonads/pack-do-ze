// Exemplo do motor "esquete": negócio que parece besteira (lavar tênis). Copie este arquivo para fazer o seu.
import React from 'react';
import { Narracao, fimDaFala } from '../kit/base';
import { AMARELO, MAO, TINTA, VERDE, VERMELHO, traco } from '../kit/personagem';
import { Cenario, Esquete, Nota, Parede, Placa, Plano, Selo } from '../kit/esquete';
import d from '../data/exemplo-esquete.json';

const W = (d as Narracao).words;

/** Tênis desenhado. `sujo` = 0 (branco) a 1 (encardido). */
const Tenis: React.FC<{ x: number; y: number; s?: number; sujo?: number; r?: number }> = ({ x, y, s = 1, sujo = 0, r = 0 }) => (
  <g transform={`translate(${x} ${y}) rotate(${r}) scale(${s})`}>
    <path d="M-90 0 Q-92 -40 -60 -52 L-10 -70 Q20 -60 40 -40 L90 -24 Q104 -10 96 0 Z" fill={sujo > 0.5 ? '#CBB98F' : '#fff'} {...traco} strokeWidth={6} />
    <path d="M-92 0 H98 V14 H-92 Z" fill={sujo > 0.5 ? '#8A7A5A' : '#E9E9E9'} {...traco} strokeWidth={6} />
    <path d="M-20 -60 l10 18 M-4 -56 l10 18 M12 -50 l10 18" stroke={TINTA} strokeWidth={5} />
    {sujo > 0.5 && <path d="M-50 -20 q10 6 20 0 M30 -14 q8 5 16 0" stroke="#6B5A3A" strokeWidth={6} fill="none" />}
  </g>
);

const A: [number, number] = [300, 1560];
const CENARIOS: Record<string, Cenario> = {
  rua: { a: A, Fundo: ({ t }) => <g>
    <Parede cor="#BFE4FF" chao="#9A9A9A" />
    <rect x={560} y={560} width={420} height={690} fill="#F2E3C6" {...traco} strokeWidth={8} />
    <Placa x={770} y={680} w={380} t="LAVO TÊNIS" f={AMARELO} z={56} />
    <Placa x={770} y={860} w={240} t="R$ 30" f="#fff" c={VERDE} z={64} />
    {[0, 1, 2].map(i => <Tenis key={i} x={680 + i * 100} y={1120 + Math.sin(t * 2 + i) * 3} s={0.55} r={-6} />)}
  </g> },
  armario: { a: A, Fundo: () => <g>
    <Parede cor="#E9D8C0" chao="#B98D5E" />
    <rect x={480} y={300} width={520} height={950} fill="#C99A5B" {...traco} strokeWidth={8} />
    <rect x={510} y={330} width={460} height={890} fill="#7A5A3A" {...traco} strokeWidth={6} />
    {[0, 1, 2, 3].map(i => <Tenis key={i} x={600 + (i % 2) * 220} y={700 + Math.floor(i / 2) * 320} s={0.75} sujo={1} />)}
    <text x={740} y={560} textAnchor="middle" fontFamily={MAO} fontSize={60} fill="#fff">eca</text>
  </g> },
  quintal: { a: A, Fundo: ({ t }) => <g>
    <Parede cor="#CDEBC5" chao="#8BBF6A" />
    <path d="M580 1250 l40 -220 h220 l40 220 z" fill="#3B82F6" {...traco} strokeWidth={8} />
    {[0, 1, 2, 3, 4].map(i => <circle key={i} cx={640 + i * 50} cy={1020 - ((t * 60 + i * 40) % 160)} r={14} fill="#fff" stroke="#9CC2F7" strokeWidth={4} />)}
    {Array.from({ length: 8 }, (_, i) => <Tenis key={i} x={560 + (i % 4) * 120} y={1420 + Math.floor(i / 4) * 120} s={0.5} r={i * 7 - 20} />)}
    <Nota x={900} y={1650} r={-10} /><Nota x={960} y={1700} r={8} />
  </g> },
};

const PLANOS: Plano[] = [
  { f: 0, set: 'rua' },
  { f: 'Todo mundo', set: 'armario', foco: [740, 900, 1.5] },
  { f: 'Tu cobra', set: 'rua', foco: [770, 900, 1.6] },
  { f: 'Com escova,', set: 'quintal' },
  { f: 'Oito vezes', set: 'quintal', foco: [720, 1300, 1.5] },
  { f: 'Quatro sábados:', set: 'rua', foco: 'a' },
  { f: 'Manda pro', set: 'rua' },
];
const SELOS: Selo[] = [
  { f: 'Esse negócio', y: 300, z: 64, t: 'negócio que parece besteira' },
  { f: 'lavar tênis.', y: 450, z: 90, fundo: AMARELO, t: '👟 lavar tênis' },
  { f: 'Tu cobra', y: 250, z: 84, fundo: '#C7F0D8', t: 'R$ 30 o par' },
  { f: 'uns oito', y: 360, z: 70, t: '8 pares por sábado' },
  { f: 'Oito vezes', y: 290, z: 80, t: '8 × R$ 30' },
  { f: 'duzentos e quarenta', y: 500, z: 110, c: VERDE, t: 'R$ 240' },
  { f: 'Quatro sábados:', ate: 'Resumindo:', y: 330, z: 72, t: '4 sábados' },
  { f: 'novecentos e sessenta', ate: 'Resumindo:', y: 470, z: 100, c: VERDE, fundo: '#C7F0D8', t: 'R$ 960 no mês' },
  { f: 'Resumindo:', y: 360, z: 66, c: VERMELHO, r: -5, t: 'dinheiro com o\nchulé dos outros 🤢' },
  { f: 'Manda pro', y: 360, z: 58, fundo: AMARELO, t: 'manda pro amigo do tênis branco' },
];

export const ESQUETE_FIM = fimDaFala(W);
export const ExemploEsquete: React.FC = () => <Esquete W={W} audio="exemplo-esquete.wav" cenarios={CENARIOS} planos={PLANOS} selos={SELOS} visual={{ corBone: VERMELHO, corRoupa: '#F59E0B' }} />;
