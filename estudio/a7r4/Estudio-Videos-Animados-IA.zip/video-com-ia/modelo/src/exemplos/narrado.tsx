// Exemplo do motor "narrado": anúncio de um app FICTÍCIO ("Moedinha"), para mostrar o padrão. Num anúncio de verdade,
// as telas são recriadas do produto real e a cor da marca vem do site oficial.
import React from 'react';
import { Narracao, fimDaFala, indice, useT, lerp } from '../kit/base';
import { CenaNarrada, Celular3D, Fala, INTER, Narrado, Pilula, Tema, Toque } from '../kit/narrado';
import { interpolate, Easing } from 'remotion';
import d from '../data/exemplo-narrado.json';

const W = (d as Narracao).words;
const i = indice(W);
const q = (f: string) => W[i(f)].start;
const ROXO = '#8B5CF6';
const TEMA: Tema = { marca: ROXO, brilho: 'rgba(139,92,246,.25)', tinta: '#1A1030' };

/** Tela do app recriada (lista de gastos que vai se separando). */
const TelaApp: React.FC<{ t0: number }> = ({ t0 }) => {
  const t = useT() + t0;
  const itens = [['🛒', 'Mercado', 'R$ 412'], ['🍔', 'Delivery', 'R$ 186'], ['🚌', 'Transporte', 'R$ 98'], ['📺', 'Assinaturas', 'R$ 64']];
  const ini = q('separa cada');
  return (
    <div style={{ padding: '90px 34px', fontFamily: INTER, color: '#1A1030' }}>
      <div style={{ fontSize: 30, fontWeight: 700, opacity: 0.6 }}>Novembro</div>
      <div style={{ fontSize: 64, fontWeight: 800, letterSpacing: '-0.03em', marginBottom: 30 }}>R$ 760</div>
      {itens.map(([e, n, v], k) => {
        const p = interpolate(t, [ini + k * 0.18, ini + k * 0.18 + 0.4], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.back(1.6)) });
        return <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 18, background: '#fff', borderRadius: 24, padding: '20px 22px', marginBottom: 16, boxShadow: '0 8px 24px rgba(26,16,48,.08)', opacity: p, transform: `translateY(${(1 - p) * 40}px) scale(${lerp(p, 0.9, 1)})` }}>
          <div style={{ fontSize: 40 }}>{e}</div><div style={{ flex: 1, fontSize: 30, fontWeight: 700 }}>{n}</div><div style={{ fontSize: 30, fontWeight: 800, color: ROXO }}>{v}</div>
        </div>;
      })}
    </div>
  );
};

const CENAS: CenaNarrada[] = [
  { f: 0, C: ({ t0 }) => (<>
    <Fala W={W} t0={t0} de={i('Teu dinheiro')} ate={i('pra onde foi?') + 2} quebra={[i('no fim'), i('e tu')]} y={640} size={84} quente={{ [i('some')]: '#FF5A5A' }} />
    <div style={{ position: 'absolute', top: 1180, width: '100%', textAlign: 'center' }}><Pilula at={q('fim do') - t0} pele="vermelho" size={58}>💸 fim do mês</Pilula></div>
  </>) },
  { f: 'Com o', C: ({ t0 }) => (<>
    <Fala W={W} t0={t0} de={i('Com o')} ate={i('cada gasto sozinho.') + 2} quebra={[i('tu conecta'), i('e ele')]} y={170} size={64} quente={{ [i('Moedinha,')]: ROXO }} />
    <Celular3D at={q('Com o') - t0 + 0.1} tema={TEMA} w={480}><TelaApp t0={t0} /></Celular3D>
  </>) },
  { f: 'Vai estourar', alerta: 0.55, C: ({ t0 }) => (<>
    <Fala W={W} t0={t0} de={i('Vai estourar')} ate={i('avisa antes.') + 1} quebra={[i('do mercado?'), i('Ele te')]} y={560} size={80} quente={{ [i('estourar')]: '#FF5A5A' }} />
    <div style={{ position: 'absolute', top: 1100, width: '100%', textAlign: 'center' }}><Pilula at={q('Ele te') - t0} pele="branco" size={50} som="notif">⚠️ Mercado: 90% do limite</Pilula></div>
  </>) },
  { f: 'Em trinta', claro: true, C: ({ t0 }) => (<>
    <Fala W={W} t0={t0} de={i('Em trinta')} ate={i('cada real.') + 1} quebra={[i('tu sabe')]} y={520} size={76} cor="#1A1030" quente={{ [i('cada real.')]: ROXO }} />
    <div style={{ position: 'absolute', top: 1080, width: '100%', textAlign: 'center' }}><Pilula at={q('Baixa o') - t0} pele="azul" size={60} som="success">Baixar o Moedinha</Pilula></div>
    <Toque at={q('começa hoje.') - t0} x={600} y={1140} />
  </>) },
];

export const NARRADO_FIM = fimDaFala(W, 1.4);
export const ExemploNarrado: React.FC = () => <Narrado W={W} audio="exemplo-narrado.wav" cenas={CENAS} tema={TEMA} fim={NARRADO_FIM} />;
