// Exemplo do motor "caderno": a conta que ninguém faz (cafezinho). Copie este arquivo para fazer o seu.
import React from 'react';
import { Narracao, achador, fimDaFala } from '../kit/base';
import { AMARELO, VERDE } from '../kit/personagem';
import { CenaCaderno, Carimbo, Conta, Etiqueta, Grande, Pop, ReelCaderno, TopoSerie } from '../kit/caderno';
import d from '../data/exemplo-caderno.json';

const W = (d as Narracao).words;
const q = achador(W);
const Em: React.FC<{ z?: number; children: React.ReactNode }> = ({ z = 150, children }) => <div style={{ fontSize: z }}>{children}</div>;

const CENAS: CenaCaderno[] = [
  { f: 'Sabe', x: 540, C: () => (<>
    <Pop at={0} y={340} s="whoosh"><Grande z={100}>o cafezinho de todo dia</Grande></Pop>
    <Pop at={0.2} y={530} s={null}><Em z={170}>☕</Em></Pop>
    <Pop at={q('Seis reais.')} y={760} r={-3} s="coin"><Etiqueta f={AMARELO} z={96}>R$ 6</Etiqueta></Pop>
    <Pop at={q('Parece nada,')} y={930} s="pop"><Etiqueta z={58}>parece nada, né?</Etiqueta></Pop>
  </>) },
  { f: 'Mas o', x: 800, C: () => (<>
    <Pop at={q('Mas o')} y={330}><Grande z={96}>📅 22 dias úteis</Grande></Pop>
    <Pop at={q('Seis vezes')} y={540}><Grande z={110}>6 × 22</Grande></Pop>
    <Pop at={q('cento e trinta')} y={740} s="cash"><Conta de={q('cento e trinta')} ate={q('cento e trinta') + 0.9} alvo={132} pre="R$ " c={VERDE} z={150} /></Pop>
    <Pop at={q('cento e trinta') + 1} y={900} s={null}><Etiqueta z={56}>por mês</Etiqueta></Pop>
  </>) },
  { f: 'No ano,', x: 280, oculos: true, C: () => (<>
    <Pop at={q('No ano,')} y={320}><Grande z={96}>no ano…</Grande></Pop>
    <Pop at={q('mil quinhentos')} x={620} y={540} s="cash"><Conta de={q('mil quinhentos')} ate={q('mil quinhentos') + 1.1} alvo={1584} pre="R$ " c={VERDE} z={140} /></Pop>
    <Pop at={q('Dá pra')} x={620} y={760} r={2}><Etiqueta f="#BFE4FF" z={70}>✈️ uma viagem</Etiqueta></Pop>
  </>) },
  { f: 'Resumindo:', x: 540, C: () => (<>
    <Pop at={q('Resumindo:')} y={400}><Etiqueta z={58}>{'o problema não é o café'}</Etiqueta></Pop>
    <Carimbo at={q('é a conta')} y={640} t="FAZ A CONTA" />
    <Pop at={q('Manda pro')} y={880} r={-2} s="whoosh"><Etiqueta f={AMARELO} z={54}>manda pro amigo da padaria</Etiqueta></Pop>
  </>) },
];

export const CADERNO_FIM = fimDaFala(W, 1.6);
export const ExemploCaderno: React.FC = () => <ReelCaderno W={W} cenas={CENAS} audio="exemplo-caderno.wav" topo={<TopoSerie serie="a conta que ninguém faz" aviso="valores de exemplo" />} />;
