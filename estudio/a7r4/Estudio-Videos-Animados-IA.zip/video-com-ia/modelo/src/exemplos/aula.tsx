// Exemplo do motor "aula" (YouTube 16:9): primeiro vídeo com IA em 3 passos, com o amigo que interrompe.
import React from 'react';
import { Narracao, fimDaFala } from '../kit/base';
import { VERDE } from '../kit/personagem';
import { Aula, Cartao, passo } from '../kit/aula';
import d from '../data/exemplo-aula.json';

const W = (d as Narracao).words;
const CARTOES: Cartao[] = [
  { f: 'Fazer teu', t: 'FAZER TEU PRIMEIRO VÍDEO É FÁCIL', sub: 'em 3 passos' },
  passo(1, 'o gancho', 'Passo número um:'),
  passo(2, 'postar todo dia', 'Passo número dois:'),
  { f: 'trinta vídeos aprende', t: '30 VÍDEOS > 1 IDEIA', c: VERDE },
  passo(3, 'copiar o que deu certo', 'Passo número três:'),
];

export const AULA_FIM = fimDaFala(W, 1.2);
export const ExemploAula: React.FC = () => <Aula W={W} audio="exemplo-aula.wav" cartoes={CARTOES} />;
