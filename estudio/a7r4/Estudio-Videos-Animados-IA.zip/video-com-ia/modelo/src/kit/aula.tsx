// Motor "aula" (YouTube 16:9, 30 fps): fundo preto, uma palavra grande por vez ao lado de quem fala, emoji que pula
// nas palavras-chave, cartões de tela cheia ("PASSO Nº 1", número com fonte) e um segundo personagem que entra
// quando fala (o amigo que interrompe com a dúvida do público). Bom para vídeo longo de ensino: 4 a 12 minutos.
import React from 'react';
import { AbsoluteFill, Audio, interpolate, staticFile, Easing } from 'remotion';
import { Snd, useT, Palavra, achador, cl } from './base';
import { AMARELO, MAO, Personagem, Rabisco, VERMELHO, Visual } from './personagem';

/** Cartão de tela cheia que entra na frase `f` e fica até `ate` (ou 2,6 s). `c` = cor do título. */
export type Cartao = { f: string; ate?: string; t: string; sub?: string; c?: string };

const limpa = (x: string) => x.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9%$]/g, '');
/** Palavra-chave → emoji. Troque e amplie para o SEU nicho (receita, academia, games...). */
export const EMOJIS_PADRAO: [RegExp, string][] = [
  [/^(dinheiro|grana|reais|real|salario|lucro|renda)$/, '💸'], [/^(cartao|fatura|rotativo)$/, '💳'], [/^(banco|bancos)$/, '🏦'], [/^(juro|juros)$/, '📈'],
  [/^(divida|dividas|devendo|deve)$/, '📉'], [/^(casa|aluguel)$/, '🏠'], [/^(celular|app|aplicativo|whatsapp)$/, '📱'],
  [/^(ia|robo|chatgpt|inteligencia)$/, '🤖'], [/^(golpe|golpista|golpes|fraude)$/, '🚨'], [/^(investir|investimento|tesouro|cdb)$/, '📊'], [/^(negocio|empresa|mei|cnpj)$/, '🏪'],
  [/^(vender|venda|vendas|cliente|clientes)$/, '🤝'], [/^(imposto|impostos|receita)$/, '🏛️'], [/^(mercado|comida|lanche)$/, '🛒'],
  [/^(tempo|mes|meses|ano|anos|dia)$/, '⏳'], [/^(chefe|patrao)$/, '👔'], [/^(ideia|ideias)$/, '💡'], [/^(erro|errado|cuidado)$/, '⚠️'],
];
const NUM = /^(\d|r\$|um|dois|tres|quatro|cinco|seis|sete|oito|nove|dez|vinte|trinta|quarenta|cinquenta|cem|cento|duzentos|trezentos|quatrocentos|quinhentos|mil|milhao|milhoes|bilhoes|porcento|%)/;

const PalavraGrande: React.FC<{ W: Palavra[]; t: number }> = ({ W, t }) => {
  const i = W.findIndex(w => t >= w.start - 0.03 && t < w.end + 0.12);
  if (i < 0) return null;
  const w = W[i], l = limpa(w.text);
  const k = interpolate(t, [w.start - 0.03, w.start + 0.09], [0.6, 1], { ...cl, easing: Easing.out(Easing.back(3)) });
  const destaque = NUM.test(l) || l.length > 9;
  const b = w.quem === 'B';
  // A palavra fica do lado de quem fala, ancorada para crescer para o centro.
  return <div style={{ position: 'absolute', ...(b ? { right: 520 } : { left: 960 }), top: 300, width: 900, textAlign: b ? 'right' : 'left', transform: `scale(${k})`, transformOrigin: b ? 'right center' : 'left center', fontFamily: '"Arial Black", Arial, sans-serif', fontWeight: 900, fontSize: destaque ? 150 : 120, color: destaque ? AMARELO : '#fff', lineHeight: 1, whiteSpace: 'nowrap' }}>{w.text.replace(/[.,:;!?]+$/, '')}</div>;
};

const Emoji: React.FC<{ W: Palavra[]; t: number; mapa: [RegExp, string][] }> = ({ W, t, mapa }) => {
  let at = -1, e = '';
  for (const w of W) { if (w.start > t) break; const m = mapa.find(([r]) => r.test(limpa(w.text))); if (m) { at = w.start; e = m[1]; } }
  if (at < 0 || t > at + 1.6) return null;
  const k = interpolate(t, [at, at + 0.25, at + 1.3, at + 1.6], [0, 1, 1, 0], { ...cl, easing: Easing.out(Easing.back(2)) });
  return <div style={{ position: 'absolute', left: 1250, top: 560, fontSize: 220, transform: `scale(${k}) rotate(${(at * 37) % 20 - 10}deg)` }}>{e}</div>;
};

const CartaoTela: React.FC<{ t: number; at: number; q: Cartao }> = ({ t, at, q }) => {
  const k = interpolate(t, [at, at + 0.3], [0, 1], { ...cl, easing: Easing.out(Easing.back(1.6)) });
  return <AbsoluteFill style={{ background: '#0E0E10', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 30 }}>
    {/* O título já nasce em 70% (nunca um quadro preto vazio no corte) e cresce com mola. */}
    <div style={{ transform: `scale(${0.7 + 0.3 * k})`, fontFamily: '"Arial Black", Arial, sans-serif', fontWeight: 900, fontSize: q.t.length > 18 ? 130 : 180, color: q.c ?? '#fff', textAlign: 'center', lineHeight: 1.05, padding: '0 80px' }}>{q.t}</div>
    {q.sub && <div style={{ opacity: Math.min(1, 0.3 + k), fontFamily: MAO, fontSize: 80, color: VERMELHO }}>{q.sub}</div>}
  </AbsoluteFill>;
};

export const Aula: React.FC<{ W: Palavra[]; audio: string; cartoes: Cartao[]; visualA?: Visual; visualB?: Visual; emojis?: [RegExp, string][] }> = ({ W, audio, cartoes, visualA = {}, visualB = { corRoupa: '#2FB36D', corBone: VERMELHO, oculos: true }, emojis = EMOJIS_PADRAO }) => {
  const t = useT();
  const q = achador(W);
  const fala = (quem: 'A' | 'B') => W.some(w => (w.quem ?? 'A') === quem && t >= w.start - 0.02 && t <= w.end);
  const fa = fala('A'), fb = fala('B');
  // O personagem B entra quando começa a falar e sai 1,5 s depois da última fala dele.
  const bNaTela = W.some(w => w.quem === 'B' && w.start <= t && t - w.end < 1.5);
  const qs = cartoes.map(x => ({ ...x, a: q(x.f), b: x.ate ? q(x.ate) : q(x.f) + 2.6 }));
  const ativo = qs.find(x => t >= x.a && t < x.b);
  const g = fa ? Math.sin(t * 5.5) * 14 : 0;
  return (
    <AbsoluteFill style={{ background: '#0E0E10', overflow: 'hidden' }}>
      <Rabisco />
      <svg width={1920} height={1080} style={{ position: 'absolute', inset: 0 }}>
        <Personagem {...visualA} x={bNaTela ? 330 : 560} y={900 + Math.sin(t * 2.2) * 5} s={1.7} boca={(fa ? (Math.sin(t * 24) > 0.1 ? 'aberta' : 'fala') : 'sorriso') as never} olhar={bNaTela ? 10 : 6} fecha={t % 3.7 < 0.12 ? 1 : 0} bracoE={16 + g * 0.6} bracoD={26 + g} />
        {bNaTela && <Personagem {...visualB} x={1620} y={900 + Math.sin(t * 2.6 + 1) * 5} s={1.7} boca={(fb ? (Math.sin(t * 22) > 0 ? 'aberta' : 'fala') : 'sorriso') as never} olhar={-10} bracoE={fb ? 60 + Math.sin(t * 6) * 30 : 20} bracoD={fb ? 120 : 20} />}
      </svg>
      <PalavraGrande W={W} t={t} />
      <Emoji W={W} t={t} mapa={emojis} />
      {ativo && <CartaoTela t={t} at={ativo.a} q={ativo} />}
      {qs.map((x, k) => <Snd key={k} at={x.a} s="whoosh" v={0.22} />)}
      {W.filter(w => w.quem === 'B').filter((w, k, a) => k === 0 || w.start - a[k - 1].end > 1.5).map((w, k) => <Snd key={'b' + k} at={w.start - 0.1} s="pop" v={0.25} />)}
      <Audio src={staticFile(audio)} />
    </AbsoluteFill>
  );
};

/** Cartão "PASSO Nº n" que entra quando o narrador fala `f` (ex.: "Passo número um"). */
export const passo = (n: number, sub: string, f: string): Cartao => ({ f, t: `PASSO Nº ${n}`, sub });
