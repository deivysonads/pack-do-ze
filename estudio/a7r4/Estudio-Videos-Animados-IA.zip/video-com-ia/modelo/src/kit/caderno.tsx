// Motor "caderno" (Reel 9:16, 60 fps): fundo de caderno, uma cena por trecho da fala, o personagem anda até o lado
// livre da cena, pula na troca e fala; legenda por frase embaixo. Ideal para "conta que fecha", lista e explicação rápida.
import React from 'react';
import { AbsoluteFill, Audio, interpolate, staticFile, Easing } from 'remotion';
import { Snd, lerp, useT, Fx, Palavra, achador, cl } from './base';
import { Caderno, MAO, Personagem, Rabisco, TINTA, Visual, VERMELHO } from './personagem';

/**
 * Uma cena do Reel. `f` = primeiras palavras do trecho que abre a cena (a 1ª cena começa no 0, o `f` dela é ignorado).
 * `x` = onde o personagem fica (deixe o lado oposto livre para o desenho da cena). `C` = o que aparece na cena.
 */
export type CenaCaderno = { f: string; x: number; C: React.FC; oculos?: boolean };

export const ReelCaderno: React.FC<{ W: Palavra[]; cenas: CenaCaderno[]; audio: string; visual?: Visual; topo?: React.ReactNode }> = ({ W, cenas, audio, visual = {}, topo }) => {
  const t = useT();
  const q = achador(W);
  const ULT = W.length - 1;
  const INI = cenas.map((c, i) => (i ? q(c.f) : 0));
  let i = 0;
  INI.forEach((s, k) => { if (t >= s - 0.28) i = k; });
  const de = INI[i], C = cenas[i].C, Prev = i ? cenas[i - 1].C : null;
  // A cena nova entra deslizando da direita em 0,28 s, terminando no começo da frase.
  const a = i ? interpolate(t, [de - 0.28, de], [1, 0], { ...cl, easing: Easing.out(Easing.cubic) }) : 0;

  let x = cenas[0].x, z = 0;
  INI.forEach((s, k) => {
    if (t >= s - 0.05) z = k;
    if (k) x = lerp(interpolate(t, [s - 0.05, s + 0.5], [0, 1], { ...cl, easing: Easing.inOut(Easing.cubic) }), x, cenas[k].x);
  });
  const fala = W.some(w => t >= w.start - 0.02 && t <= w.end);
  const boca = fala ? (Math.sin(t * 24) > 0.1 ? 'aberta' : 'fala') : 'sorriso';
  // Pulo na troca de cena: dois quiques que começam e terminam no chão (sem salto de quadro), somados ao balanço de respirar.
  const pulo = Math.sin(t * 2.2) * 5 + (z && t > INI[z] && t < INI[z] + 0.5 ? Math.abs(Math.sin(((t - INI[z]) / 0.5) * Math.PI * 2)) * 26 : 0);
  const dir = x < 500 ? 1 : x > 580 ? -1 : 0;
  const g = fala ? Math.sin(t * 5.5) * 14 : 0;

  // Legenda: frases de até 5 palavras, cortadas na pontuação; a palavra falada acende.
  const frases: [number, number][] = [];
  let ini = 0;
  W.forEach((w, k) => { if (/[.?!:,]$/.test(w.text) || k - ini + 1 >= 5 || k === ULT) { frases.push([ini, k]); ini = k + 1; } });
  const f = [...frases].reverse().find(([b]) => t >= W[b].start - 0.05) ?? frases[0];

  return (
    <AbsoluteFill style={{ overflow: 'hidden', background: '#F6F0E1' }}>
      <Rabisco />
      <Caderno />
      {a > 0 && Prev && <div style={{ position: 'absolute', inset: 0 }}><Prev /></div>}
      <div style={{ position: 'absolute', inset: 0, transform: `translateX(${a * 1100}px)` }}>{a > 0 && <Caderno />}<C /></div>
      <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
        <Personagem {...visual} oculos={cenas[z].oculos ?? visual.oculos} x={x} y={1560 - pulo} s={1.25} boca={boca as never} olhar={dir * 10} fecha={t % 3.7 < 0.12 ? 1 : 0} bracoD={dir > 0 ? 125 + g * 0.3 : 26 + g} bracoE={dir < 0 ? 125 + g * 0.3 : 16 + g * 0.6} />
      </svg>
      {t <= W[ULT].end + 0.5 && <div style={{ position: 'absolute', left: 40, right: 40, top: 1625, textAlign: 'center' }}><span style={{ fontFamily: MAO, fontSize: 62, lineHeight: 1.15, background: 'rgba(246,240,225,.95)', borderRadius: 12, padding: '2px 18px', boxDecorationBreak: 'clone', WebkitBoxDecorationBreak: 'clone' }}>{W.slice(f[0], f[1] + 1).map((w, k) => <span key={k} style={{ color: TINTA, opacity: t >= w.start - 0.03 ? 1 : 0.3 }}>{w.text} </span>)}</span></div>}
      {topo}
      {INI.slice(1).map((s, k) => <Snd key={k} at={s - 0.28} s="swipe" v={0.14} />)}
      <Audio src={staticFile(audio)} />
    </AbsoluteFill>
  );
};

/** Elemento que "pula" na tela no segundo `at` (com som). Posição pelo centro. */
export const Pop: React.FC<{ at: number; x?: number; y: number; r?: number; s?: Fx | null; children: React.ReactNode }> = ({ at, x = 540, y, r = 0, s = 'pop', children }) => {
  const t = useT();
  const k = interpolate(t, [at, at + 0.3], [0, 1], { ...cl, easing: Easing.out(Easing.back(1.8)) });
  return <>{s && <Snd at={at} s={s} v={0.22} />}{k > 0 && <div style={{ position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) scale(${k}) rotate(${r}deg)`, fontFamily: MAO, color: TINTA, textAlign: 'center', whiteSpace: 'nowrap' }}>{children}</div>}</>;
};
/** Etiqueta de papel com borda e sombra dura (para valores e nomes). */
export const Etiqueta: React.FC<{ f?: string; z?: number; children: React.ReactNode }> = ({ f = '#fff', z = 62, children }) => <div style={{ background: f, fontSize: z, padding: '10px 30px', borderRadius: 18, border: `6px solid ${TINTA}`, boxShadow: `7px 8px 0 ${TINTA}`, lineHeight: 1.08 }}>{children}</div>;
/** Texto grande (título da cena, número, emoji). */
export const Grande: React.FC<{ z?: number; c?: string; children: React.ReactNode }> = ({ z = 120, c = TINTA, children }) => <div style={{ fontSize: z, color: c, lineHeight: 1.02 }}>{children}</div>;

/** Número que rola de 0 até `alvo` entre os segundos `de` e `ate` (formato brasileiro: 1.250). */
export const Conta: React.FC<{ de: number; ate: number; alvo: number; pre?: string; z?: number; c?: string }> = ({ de, ate, alvo, pre = '', z = 200, c = TINTA }) => {
  const t = useT();
  const n = Math.round(interpolate(t, [de, ate], [0, alvo], { ...cl, easing: Easing.out(Easing.cubic) }));
  return <div style={{ fontFamily: MAO, fontSize: z, color: c, lineHeight: 1, whiteSpace: 'nowrap', fontVariantNumeric: 'tabular-nums' }}>{pre}{n.toLocaleString('pt-BR')}</div>;
};
/** Carimbo que bate na tela (com som). */
export const Carimbo: React.FC<{ at: number; y: number; t: string; c?: string; z?: number }> = ({ at, y, t: txt, c = VERMELHO, z = 110 }) => {
  const t = useT();
  const k = interpolate(t, [at, at + 0.16], [0, 1], { ...cl, easing: Easing.in(Easing.cubic) });
  return <><Snd at={at + 0.1} s="stamp" v={0.3} />{k > 0 && <div style={{ position: 'absolute', left: 540, top: y, transform: `translate(-50%,-50%) scale(${2.3 - 1.3 * k}) rotate(-7deg)`, opacity: k, fontFamily: MAO, fontSize: z, color: c, border: `9px solid ${c}`, borderRadius: 20, padding: '2px 30px', whiteSpace: 'nowrap', background: 'rgba(246,240,225,.92)' }}>{txt}</div>}</>;
};
/** Faixa do topo com o nome da série e um aviso (ex.: "é zoeira"). Série com nome fixo cria hábito no público. */
export const TopoSerie: React.FC<{ serie: string; aviso?: string }> = ({ serie, aviso }) => (
  <div style={{ position: 'absolute', left: 50, right: 50, top: 150, display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontFamily: MAO }}>
    <span style={{ fontSize: 42, background: '#fff', border: `4px solid ${TINTA}`, borderRadius: 30, padding: '2px 22px', color: VERMELHO }}>● {serie}</span>
    {aviso && <span style={{ fontSize: 38, color: '#6A6658', transform: 'rotate(2deg)' }}>{aviso}</span>}
  </div>
);
