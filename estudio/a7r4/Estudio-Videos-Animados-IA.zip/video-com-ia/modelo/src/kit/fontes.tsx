// Fontes carregadas do disco (public/fonts/), sem depender da internet no render.
// Motivo (05/11): o Chrome do Remotion falhou ao baixar do Google Fonts (QUIC timeout e conexão recusada) e o render travava.
// Inter (variável, pesos 100 a 900) e Patrick Hand, latin + latin-ext, licença SIL Open Font License (public/fonts/LICENCA-FONTES.md).
// A espera (delayRender) fica DENTRO de um componente: no topo do arquivo ela também nascia na página que o Remotion usa só
// para ler o projeto, ficava pendurada lá e derrubava o render longo depois do prazo.
import React, { useEffect, useState } from 'react';
import { continueRender, delayRender, staticFile } from 'remotion';

const LATIN = 'U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD';
const LATIN_EXT = 'U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF';

export const INTER = 'Inter Local';
export const MAO = 'Patrick Hand Local';

const FACES: [string, string, string, string][] = [
  [INTER, 'fonts/inter-latin.woff2', LATIN, '100 900'],
  [INTER, 'fonts/inter-latin-ext.woff2', LATIN_EXT, '100 900'],
  [MAO, 'fonts/patrick-latin.woff2', LATIN, '400'],
  [MAO, 'fonts/patrick-latin-ext.woff2', LATIN_EXT, '400'],
];

let carregando: Promise<void> | null = null;
const carrega = () => {
  if (!carregando) {
    carregando = Promise.all(FACES.map(([fam, arq, range, peso]) => {
      const f = new FontFace(fam, `url(${staticFile(arq)}) format('woff2')`, { unicodeRange: range, weight: peso, style: 'normal' });
      return f.load().then(x => { (document.fonts as unknown as { add: (f: FontFace) => void }).add(x); });
    })).then(() => undefined);
  }
  return carregando;
};

/** Ponha uma vez dentro do vídeo (os motores já põem): segura o quadro até as fontes do disco estarem prontas. */
export const FontesLocais: React.FC = () => {
  const [h] = useState(() => delayRender('fontes locais', { timeoutInMilliseconds: 30000 }));
  useEffect(() => {
    let livre = false;
    const solta = () => { if (!livre) { livre = true; continueRender(h); } };
    const t = setTimeout(() => { console.warn('Fontes locais demoraram mais de 10 s; seguindo o render'); solta(); }, 10000);
    carrega().then(solta).catch(e => { console.error('Fonte local falhou', e); solta(); });
    return () => { clearTimeout(t); solta(); };
  }, [h]);
  return null;
};
