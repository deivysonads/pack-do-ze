// O personagem desenhado (traço de caneta que treme de leve) e o fundo de caderno.
// Troque as cores, o boné e a roupa para criar o SEU personagem: é o que faz o público reconhecer o canal.
import React from 'react';
import { AbsoluteFill } from 'remotion';
import { useT } from './base';

/** Fonte de letra de mão (Patrick Hand, do disco: src/kit/fontes.ts). */
import { MAO, FontesLocais } from './fontes';
export { MAO };
export const TINTA = '#1B1B22', PAPEL = '#F6F0E1', AZUL = '#3257F5', AMARELO = '#FFD23F', VERMELHO = '#E5484D', VERDE = '#2FB36D', PELE = '#F6C9A0';
export const traco = { stroke: TINTA, strokeWidth: 6, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const };

/** Caderno quadriculado com margem vermelha (fundo do motor "caderno"). */
export const Caderno: React.FC = () => (
  <AbsoluteFill style={{ background: PAPEL }}>
    <AbsoluteFill style={{ backgroundImage: 'linear-gradient(rgba(50,87,245,.13) 2px, transparent 2px), linear-gradient(90deg, rgba(50,87,245,.13) 2px, transparent 2px)', backgroundSize: '54px 54px' }} />
    <div style={{ position: 'absolute', left: 108, top: 0, bottom: 0, width: 4, background: 'rgba(229,72,77,.45)' }} />
    <AbsoluteFill style={{ background: 'radial-gradient(85% 85% at 50% 50%, transparent 60%, rgba(120,90,40,.16) 100%)' }} />
  </AbsoluteFill>
);

/** Filtro que treme o traço como desenho à mão (troca 8 vezes por segundo). Ponha uma vez por vídeo e use filter="url(#rabisco)". */
export const Rabisco: React.FC = () => {
  const t = useT();
  return (
    <>
    <FontesLocais />
    <svg width={0} height={0} style={{ position: 'absolute' }}>
      <filter id="rabisco" x="-5%" y="-5%" width="110%" height="110%">
        <feTurbulence type="fractalNoise" baseFrequency="0.018" numOctaves={2} seed={Math.floor(t * 8) % 7} />
        <feDisplacementMap in="SourceGraphic" scale={5} />
      </filter>
    </svg>
    </>
  );
};

export type Boca = 'fechada' | 'fala' | 'aberta' | 'tensa' | 'sorriso';
/** Visual fixo do personagem (cores e acessórios). */
export type Visual = { corRoupa?: string; corBone?: string; corAba?: string; pele?: string; terno?: boolean; oculos?: boolean; corrente?: string };
export type Pose = Visual & { x: number; y: number; s?: number; boca?: Boca; bracoE?: number; bracoD?: number; olhar?: number; suor?: boolean; fecha?: number; so?: 'tudo' | 'cabeca'; maoD?: React.ReactNode };

/**
 * O personagem. (x, y) = ponto entre os pés. Ângulo do braço em graus (0 = para baixo, 150 = para cima).
 * `corrente` desenha uma corrente de ouro com a letra/sigla na medalha (versão "rico").
 */
export const Personagem: React.FC<Pose> = ({ x, y, s = 1, boca = 'fala', bracoE = 20, bracoD = 20, olhar = 0, suor, fecha = 0, oculos, terno, corRoupa, corBone = AZUL, corAba, pele = PELE, corrente, so = 'tudo', maoD }) => {
  const cor = corRoupa ?? (terno ? '#2B2B36' : AZUL);
  const Braco = ({ lado, ang }: { lado: 1 | -1; ang: number }) => (
    <g transform={`translate(${lado * 66} -150) rotate(${-lado * ang})`}>
      <line x1={0} y1={0} x2={0} y2={118} stroke={TINTA} strokeWidth={36} strokeLinecap="round" />
      <line x1={0} y1={0} x2={0} y2={118} stroke={cor} strokeWidth={24} strokeLinecap="round" />
      <circle cx={0} cy={134} r={20} fill={pele} {...traco} />
      {lado === 1 && maoD}
    </g>
  );
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} filter="url(#rabisco)">
      {so === 'tudo' && <>
        <path d="M-34 -30 L-38 70 M34 -30 L38 70" {...traco} strokeWidth={20} fill="none" />
        <path d="M-62 78 q24 -22 46 0 z M16 78 q22 -22 46 0 z" fill={TINTA} {...traco} />
        <Braco lado={-1} ang={bracoE} />
        <path d="M-72 -160 Q0 -192 72 -160 L78 -20 Q0 0 -78 -20 Z" fill={cor} {...traco} />
        {terno ? <><path d="M-26 -172 L0 -90 L26 -172 Z" fill="#fff" {...traco} strokeWidth={4} /><path d="M-9 -160 H9 L6 -130 L13 -92 L0 -78 L-13 -92 L-6 -130 Z" fill={VERMELHO} {...traco} strokeWidth={4} /></> : <path d="M-30 -60 h60 v30 h-60 z" fill="rgba(0,0,0,.14)" {...traco} strokeWidth={4} />}
        {corrente && <g>
          {/* agasalho com detalhe dourado (visual "rico") */}
          <path d="M-60 -150 q20 30 0 60 M60 -150 q-20 30 0 60 M-50 -60 q25 -10 30 10 M50 -60 q-25 -10 -30 10" fill="none" stroke="#E5B80B" strokeWidth={7} strokeLinecap="round" />
          <path d="M-34 -30 L-38 70 M34 -30 L38 70" stroke="#E5B80B" strokeWidth={6} />
          <path d="M-44 -172 Q0 -60 44 -172" fill="none" stroke="#C9961A" strokeWidth={14} strokeLinecap="round" /><path d="M-44 -172 Q0 -60 44 -172" fill="none" stroke="#FFD84A" strokeWidth={7} strokeDasharray="10 6" strokeLinecap="round" />
          <circle cx={0} cy={-104} r={30} fill={AMARELO} stroke={TINTA} strokeWidth={6} /><text x={0} y={-93} textAnchor="middle" fontFamily="Arial Black, Arial" fontWeight={900} fontSize={corrente.length > 2 ? 18 : 26} fill={TINTA}>{corrente}</text>
        </g>}
        <Braco lado={1} ang={bracoD} />
      </>}
      <g transform="translate(0 -250)">
        <circle cx={0} cy={0} r={92} fill={pele} {...traco} />
        <path d="M-90 -18 Q-84 -92 0 -94 Q84 -92 90 -18 Z" fill={corBone} {...traco} />
        <path d="M30 -24 Q96 -30 130 -6 Q80 -2 26 -6 Z" fill={corAba ?? corBone} {...traco} />
        {[-34, 34].map(ex => (
          <g key={ex}>
            <ellipse cx={ex} cy={12} rx={24} ry={Math.max(2, 30 * (1 - fecha))} fill={fecha > 0.7 ? pele : '#fff'} {...traco} strokeWidth={5} />
            {fecha <= 0.7 && <circle cx={ex + olhar} cy={16} r={11} fill={TINTA} />}
          </g>
        ))}
        {oculos && <g><path d="M-68 -8 H68" {...traco} /><rect x={-66} y={-10} width={58} height={48} rx={16} fill={TINTA} /><rect x={8} y={-10} width={58} height={48} rx={16} fill={TINTA} /><path d="M-52 2 l16 -6 M22 2 l16 -6" stroke="#fff" strokeWidth={5} strokeLinecap="round" /></g>}
        {boca === 'fechada' && <path d="M-22 58 Q0 66 22 58" fill="none" {...traco} />}
        {boca === 'sorriso' && <path d="M-34 50 Q0 84 34 50 Z" fill="#fff" {...traco} />}
        {boca === 'fala' && <ellipse cx={0} cy={60} rx={20} ry={13} fill="#7A1F2B" {...traco} strokeWidth={5} />}
        {boca === 'aberta' && <ellipse cx={0} cy={62} rx={27} ry={22} fill="#7A1F2B" {...traco} strokeWidth={5} />}
        {boca === 'tensa' && <path d="M-30 60 q10 -14 20 0 q10 14 20 0 q10 -14 20 0" fill="none" {...traco} />}
        {suor && <path d="M86 -22 q18 26 0 36 q-18 -10 0 -36 Z M-104 8 q14 20 0 28 q-14 -8 0 -28 Z" fill="#7CC4FF" {...traco} strokeWidth={4} />}
      </g>
    </g>
  );
};

/** Personagem "vivo": respira, pisca, mexe a boca e gesticula enquanto `fala` for true. */
export const PersonagemVivo: React.FC<Visual & { t: number; x: number; y: number; fala: boolean; s?: number; olhar?: number; maoD?: React.ReactNode; bracoD?: number; bracoE?: number }> = ({ t, x, y, fala, s = 1.5, olhar = 10, maoD, bracoD, bracoE, ...visual }) => {
  const g = fala ? Math.sin(t * 5.5) * 14 : 0;
  const boca: Boca = fala ? (Math.sin(t * 24) > 0.1 ? 'aberta' : 'fala') : 'sorriso';
  return <Personagem {...visual} x={x} y={y + Math.sin(t * 2.2) * 5} s={s} boca={boca} olhar={olhar} fecha={t % 3.7 < 0.12 ? 1 : 0} bracoE={bracoE ?? 16 + g * 0.6} bracoD={bracoD ?? 26 + g} maoD={maoD} />;
};

/** Texto solto em letra de mão, posicionado pelo centro (ou pela esquerda com ancora="start"). */
export const Texto: React.FC<{ children: React.ReactNode; x: number; y: number; size?: number; cor?: string; fundo?: string; rot?: number; ancora?: 'start' | 'center' }> = ({ children, x, y, size = 72, cor = TINTA, fundo, rot = 0, ancora = 'center' }) => (
  <div style={{ position: 'absolute', left: x, top: y, transform: `translate(${ancora === 'center' ? '-50%' : '0'},-50%) rotate(${rot}deg)`, fontFamily: MAO, fontSize: size, lineHeight: 1.05, color: cor, whiteSpace: 'nowrap', background: fundo, padding: fundo ? '6px 24px' : undefined, borderRadius: fundo ? 10 : undefined }}>{children}</div>
);

/** Lupa para pôr na mão do personagem (maoD={Lupa}). */
export const Lupa = (
  <g transform="translate(0 134)">
    <line x1={0} y1={0} x2={0} y2={84} stroke={TINTA} strokeWidth={18} strokeLinecap="round" />
    <circle cx={0} cy={148} r={72} fill="rgba(124,196,255,.3)" stroke={TINTA} strokeWidth={14} />
  </g>
);
