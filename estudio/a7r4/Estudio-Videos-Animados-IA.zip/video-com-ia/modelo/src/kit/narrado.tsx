// Motor "narrado" (anúncio, produto, explicativo 9:16 a 60 fps): fundo escuro com brilho na cor da marca e listras finas,
// texto pequeno entrando palavra por palavra e saindo do desfoque, pílulas 3D girando, toque na tela, celular 3D
// e câmera sempre andando, com troca de cena por zoom e desfoque. Cada cena começa ~0,12 s antes da palavra que a abre.
import React from 'react';
import { AbsoluteFill, Audio, Sequence, interpolate, staticFile, useVideoConfig, Easing } from 'remotion';
import { Snd, lerp, useT, useSpr, Fx, Palavra, achador, cl } from './base';

import { INTER, FontesLocais } from './fontes';
export { INTER };

/** Cores da marca do vídeo. Troque `marca` pela cor do produto (tirada do site oficial, não da memória). */
export type Tema = { marca: string; brilho: string; tinta: string };
export const TEMA_PADRAO: Tema = { marca: '#22C768', brilho: 'rgba(34,199,104,.22)', tinta: '#0B1410' };

export const FundoEscuro: React.FC<{ children?: React.ReactNode; tema?: Tema; alerta?: number }> = ({ children, tema = TEMA_PADRAO, alerta = 0 }) => {
  const t = useT();
  return (
    <AbsoluteFill style={{ background: '#040605', overflow: 'hidden', fontFamily: INTER, color: '#fff' }}>
      <AbsoluteFill style={{ backgroundImage: 'repeating-linear-gradient(135deg, rgba(255,255,255,.028) 0 2px, transparent 2px 14px)', transform: `translateX(${-t * 12}px)` }} />
      <AbsoluteFill style={{ background: `radial-gradient(55% 38% at 50% ${48 + Math.sin(t * 0.8) * 3}%, ${tema.brilho}, transparent 75%)` }} />
      {alerta > 0 && <AbsoluteFill style={{ background: 'radial-gradient(70% 50% at 50% 50%, rgba(255,40,40,.35), rgba(60,0,0,.6) 80%)', opacity: alerta }} />}
      <AbsoluteFill style={{ background: 'radial-gradient(90% 70% at 50% 50%, transparent 55%, rgba(0,0,0,.75) 100%)' }} />
      {children}
    </AbsoluteFill>
  );
};
/** Cena clara para contraste (use 1 de vez em quando, não o vídeo todo). */
export const FundoClaro: React.FC<{ children?: React.ReactNode; tema?: Tema }> = ({ children, tema = TEMA_PADRAO }) => (
  <AbsoluteFill style={{ background: 'radial-gradient(80% 60% at 50% 45%, #FFFFFF 0%, #F1F5F2 70%, #E4EBE6 100%)', overflow: 'hidden', fontFamily: INTER, color: tema.tinta }}>{children}</AbsoluteFill>
);

/** Câmera da cena: entra com zoom vindo do desfoque, vai se aproximando devagar e sai com zoom e desfoque. */
export const Camera: React.FC<{ children: React.ReactNode; dur: number; deriva?: number; semEntrada?: boolean; semSaida?: boolean }> = ({ children, dur, deriva = 0.07, semEntrada, semSaida }) => {
  const t = useT();
  const inn = semEntrada ? 1 : interpolate(t, [0, 0.28], [0, 1], { ...cl, easing: Easing.out(Easing.exp) });
  const out = semSaida ? 0 : interpolate(t, [dur - 0.16, dur], [0, 1], { ...cl, easing: Easing.in(Easing.quad) });
  const s = lerp(inn, 0.82, 1) * (1 + (t / Math.max(dur, 0.1)) * deriva) * lerp(out, 1, 1.45);
  const blur = (1 - inn) * 22 + out * 26;
  return (
    // A cena nasce já visível (desfocada e menor): opacidade 0 no 1º quadro daria um quadro preto no corte.
    <AbsoluteFill style={{ transform: `scale(${s}) rotate(${(1 - inn) * -3 + Math.sin(t * 0.7) * 0.4}deg)`, filter: blur > 0.4 ? `blur(${blur}px)` : undefined, opacity: Math.min(1, 0.45 + inn * 1.6) * (1 - out * 0.6) }}>
      {children}
    </AbsoluteFill>
  );
};

/**
 * Texto da fala, palavra por palavra (cada palavra sobe saindo do desfoque quando é dita).
 * `de`/`ate` = índices da primeira e da última palavra; `quebra` = índices onde começa nova linha.
 * `quente` = índice da palavra → cor de destaque (no máximo uma por frase). `t0` = início da cena em segundos.
 */
export const Fala: React.FC<{ W: Palavra[]; t0: number; de: number; ate: number; quebra?: number[]; y: number; size?: number; cor?: string; quente?: Record<number, string> }> = ({ W, t0, de, ate, quebra = [], y, size = 70, cor = '#fff', quente = {} }) => {
  const t = useT() + t0;
  const linhas: number[][] = [[]];
  for (let i = de; i <= ate; i++) { if (quebra.includes(i) && linhas[linhas.length - 1].length) linhas.push([]); linhas[linhas.length - 1].push(i); }
  // Sem quebra automática: a fonte encolhe até a linha mais longa caber em 960 px (nunca nasce uma linha escondida).
  const maior = Math.max(...linhas.map(l => l.reduce((n, i) => n + W[i].text.length + 1, -1)));
  size = Math.min(size, 960 / (maior * 0.56));
  return (
    <div style={{ position: 'absolute', left: 60, right: 60, top: y, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: size * 0.05 }}>
      {linhas.map((l, li) => (
        <div key={li} style={{ display: 'flex', gap: `0 ${size * 0.26}px`, flexWrap: 'nowrap', justifyContent: 'center' }}>
          {l.map(i => {
            const w = W[i];
            const p = interpolate(t, [w.start - 0.05, w.start + 0.22], [0, 1], { ...cl, easing: Easing.out(Easing.exp) });
            const c = quente[i];
            return <span key={i} style={{ display: 'inline-block', fontFamily: INTER, fontWeight: c ? 800 : 700, fontSize: size, letterSpacing: '-0.035em', lineHeight: 1.08, color: c ?? cor, textShadow: c ? `0 0 28px ${c}88` : 'none', opacity: p, filter: p < 0.99 ? `blur(${(1 - p) * 12}px)` : undefined, transform: `translateY(${(1 - p) * 34}px) scale(${lerp(p, 0.92, 1)})`, whiteSpace: 'nowrap' }}>{w.text}</span>;
          })}
        </div>
      ))}
    </div>
  );
};

const PELES = {
  verde: { face: 'linear-gradient(180deg,#7CF7B0 0%,#2BD472 48%,#14A453 100%)', lado: '#0B6B33', brilho: 'rgba(43,212,114,.6)', texto: '#fff' },
  vermelho: { face: 'linear-gradient(180deg,#FF8A8A 0%,#F23B3B 50%,#C51E1E 100%)', lado: '#7A0D0D', brilho: 'rgba(242,59,59,.6)', texto: '#fff' },
  azul: { face: 'linear-gradient(180deg,#9DB2FF 0%,#4D72FF 48%,#2A47D8 100%)', lado: '#1A2C8C', brilho: 'rgba(77,114,255,.6)', texto: '#fff' },
  escuro: { face: 'linear-gradient(180deg,#2A332E 0%,#141A17 100%)', lado: '#050706', brilho: 'rgba(43,212,114,.25)', texto: '#fff' },
  branco: { face: 'linear-gradient(180deg,#FFFFFF 0%,#E9EFEB 100%)', lado: '#B9C4BD', brilho: 'rgba(0,0,0,.18)', texto: '#0B1410' },
};
export type Pele = keyof typeof PELES;
/** Pílula 3D: entra girando no eixo Y e assenta. A espessura é uma camada embaixo (sem preserve-3d, que pisca no render). */
export const Pilula: React.FC<{ children: React.ReactNode; at: number; pele?: Pele; r?: number; pad?: string; size?: number; inclina?: number; som?: Fx | null; style?: React.CSSProperties }> = ({ children, at, pele = 'verde', r = 30, pad = '26px 44px', size = 64, inclina = -6, som = 'swipe', style }) => {
  const t = useT();
  const p = useSpr(at, 120, 16);
  const k = PELES[pele];
  if (t < at - 0.02) return null;
  const wob = Math.sin((t - at) * 1.6) * 3;
  return (
    <>
      {som && <Snd at={at} s={som} v={0.3} />}
      <div style={{ perspective: 1400, display: 'inline-block', ...style }}>
        <div style={{ position: 'relative', transform: `rotateY(${(1 - p) * 95 + wob}deg) rotateX(${(1 - p) * 25 + 8}deg) rotateZ(${inclina * p}deg) scale(${lerp(p, 0.6, 1)})`, opacity: Math.min(1, p * 2.5) }}>
          <div style={{ position: 'absolute', inset: 0, borderRadius: r, background: k.lado, transform: 'translateY(12px)', boxShadow: `0 40px 60px -20px rgba(0,0,0,.6), 0 0 90px ${k.brilho}` }} />
          <div style={{ position: 'relative', borderRadius: r, padding: pad, background: k.face, color: k.texto, fontFamily: INTER, fontWeight: 800, fontSize: size, letterSpacing: '-0.03em', whiteSpace: 'nowrap', boxShadow: 'inset 0 4px 0 rgba(255,255,255,.55), inset 0 -10px 18px rgba(0,0,0,.18)', display: 'flex', alignItems: 'center', gap: size * 0.3 }}>{children}</div>
        </div>
      </div>
    </>
  );
};

/** Toque na tela: bolinha que chega, aperta e solta um anel (com som de clique). */
export const Toque: React.FC<{ at: number; x: number; y: number; claro?: boolean }> = ({ at, x, y, claro }) => {
  const t = useT();
  if (t < at - 0.35 || t > at + 0.7) return null;
  const vem = interpolate(t, [at - 0.35, at - 0.05], [0, 1], { ...cl, easing: Easing.out(Easing.cubic) });
  const aperta = interpolate(t, [at - 0.05, at, at + 0.12], [1, 0.8, 1], cl);
  const anel = interpolate(t, [at, at + 0.5], [0, 1], { ...cl, easing: Easing.out(Easing.cubic) });
  const some = interpolate(t, [at + 0.4, at + 0.7], [1, 0], cl);
  const c = claro ? '255,255,255' : '20,30,25';
  return (
    <>
      <Snd at={at} s="click" v={0.4} />
      <div style={{ position: 'absolute', left: x, top: y, width: 0, height: 0, zIndex: 50, opacity: some }}>
        <span style={{ position: 'absolute', width: 260 * anel, height: 260 * anel, left: -130 * anel, top: -130 * anel, borderRadius: '50%', border: `5px solid rgba(${c},${0.6 * (1 - anel)})` }} />
        <span style={{ position: 'absolute', width: 86, height: 86, left: -43 + (1 - vem) * 160, top: -43 + (1 - vem) * 220, borderRadius: '50%', background: `rgba(${c},.35)`, border: `4px solid rgba(${c},.85)`, transform: `scale(${aperta})`, opacity: vem }} />
      </div>
    </>
  );
};

/** Celular inclinado em 3D que sobe e balança devagar. Ponha a tela do app (recriada do produto real) como children. */
export const Celular3D: React.FC<{ children: React.ReactNode; w?: number; ry?: number; rx?: number; at?: number; tema?: Tema }> = ({ children, w = 520, ry = -16, rx = 8, at = 0, tema = TEMA_PADRAO }) => {
  const t = useT();
  const p = useSpr(at, 90, 18);
  const h = w * 2.08;
  return (
    <div style={{ position: 'absolute', left: 540 - w / 2, top: 960 - h / 2 + 120, perspective: 2200 }}>
      <div style={{ transform: `translateY(${(1 - p) * 900}px) rotateY(${ry + Math.sin(t * 0.9) * 4 + (1 - p) * 30}deg) rotateX(${rx + (1 - p) * 20}deg) rotateZ(${(1 - p) * -8}deg)` }}>
        <div style={{ position: 'relative', width: w, height: h, borderRadius: w * 0.14, background: '#0B0F0D', padding: w * 0.028, boxShadow: `0 90px 140px -40px rgba(0,0,0,.8), 0 0 0 3px #2A322D inset, 0 0 120px ${tema.brilho}` }}>
          <div style={{ position: 'relative', width: '100%', height: '100%', borderRadius: w * 0.115, overflow: 'hidden', background: '#F3F4F3' }}>
            {children}
            <div style={{ position: 'absolute', top: w * 0.028, left: '50%', transform: 'translateX(-50%)', width: w * 0.3, height: w * 0.075, borderRadius: 999, background: '#000', zIndex: 50 }} />
            <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(115deg, rgba(255,255,255,.18) 0%, transparent 35%)', pointerEvents: 'none' }} />
          </div>
        </div>
      </div>
    </div>
  );
};

/** Uma cena do anúncio: começa na frase `f` (a 1ª no 0). `C` recebe `t0` (início da cena em segundos) e `dur`. */
export type CenaNarrada = { f: string | 0; C: React.FC<{ t0: number; dur: number }>; claro?: boolean; alerta?: number };

/** Junta as cenas: cada uma vira uma Sequence com câmera própria, do começo da frase até a próxima cena. */
export const Narrado: React.FC<{ W: Palavra[]; audio: string; cenas: CenaNarrada[]; tema?: Tema; fim: number }> = ({ W, audio, cenas, tema = TEMA_PADRAO, fim }) => {
  const { fps } = useVideoConfig();
  const q = achador(W);
  const ini = cenas.map(c => (c.f === 0 ? 0 : Math.max(0, q(c.f) - 0.12)));
  return (
    <AbsoluteFill style={{ background: '#040605' }}>
      <FontesLocais />
      {cenas.map((c, k) => {
        const a = ini[k], b = k + 1 < cenas.length ? ini[k + 1] : fim, dur = b - a;
        // Começo e fim em quadros inteiros a partir do MESMO arredondamento: nenhum quadro fica sem cena entre duas.
        const qa = Math.round(a * fps), qb = Math.round(b * fps);
        const Fundo = c.claro ? FundoClaro : FundoEscuro;
        return (
          <Sequence key={k} from={qa} durationInFrames={Math.max(1, qb - qa)}>
            <Fundo tema={tema} {...(c.claro ? {} : { alerta: c.alerta })}><Camera dur={dur} semEntrada={k === 0} semSaida={k === cenas.length - 1}><c.C t0={a} dur={dur} /></Camera></Fundo>
          </Sequence>
        );
      })}
      {ini.slice(1).map((s, k) => <Snd key={k} at={Math.max(0, s - 0.1)} s="whoosh" v={0.18} />)}
      <Audio src={staticFile(audio)} />
    </AbsoluteFill>
  );
};
