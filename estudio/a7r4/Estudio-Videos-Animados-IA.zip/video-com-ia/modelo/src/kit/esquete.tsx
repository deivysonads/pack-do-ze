// Motor "esquete" (Reel 9:16, 60 fps): cenário desenhado, câmera que corta entre plano aberto e close de quem fala
// a cada frase, selos com os números entrando na palavra certa e legenda amarela e preta de Reels.
// Funciona com uma voz (narrador "A") ou duas (diálogo: palavras com quem "A" e "B").
import React from 'react';
import { AbsoluteFill, Audio, interpolate, staticFile, Easing } from 'remotion';
import { Snd, useT, Palavra, achador, cl, falando } from './base';
import { AMARELO, MAO, PersonagemVivo, Rabisco, TINTA, VERMELHO, Visual, traco } from './personagem';

/** Um corte de câmera: a partir da frase `f` (0 = começo), mostra o cenário `set` com o `foco` escolhido. */
export type Plano = { f: string | 0; set: string; foco?: 'aberto' | 'a' | 'b' | [number, number, number] };
/** Selo (plaquinha) que entra na frase `f` e sai na frase `ate` (ou no próximo corte). `t` = conteúdo. */
export type Selo = { f: string; ate?: string; x?: number; y: number; z?: number; c?: string; fundo?: string; r?: number; t: React.ReactNode };
/**
 * Cenário em SVG de 1080x1920. `a` = onde fica o personagem principal (pés).
 * `b` = segundo personagem (opcional): posição e o componente dele (recebe se está falando).
 * `Frente` = coisas desenhadas na frente dos personagens (balcão, mesa).
 */
export type Cenario = { Fundo: React.FC<{ t: number }>; a: [number, number]; b?: { x: number; y: number; P: React.FC<{ t: number; fala: boolean }> }; Frente?: React.FC<{ t: number }> };

export const SeloTela: React.FC<{ at: number; x: number; y: number; z?: number; c?: string; f?: string; r?: number; children: React.ReactNode }> = ({ at, x, y, z = 80, c = TINTA, f = '#fff', r = -3, children }) => {
  const t = useT();
  const k = interpolate(t, [at, at + 0.28], [0, 1], { ...cl, easing: Easing.out(Easing.back(2)) });
  return <><Snd at={at} s="pop" v={0.22} />{k > 0 && <div style={{ position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) scale(${k}) rotate(${r}deg)`, fontFamily: MAO, fontSize: z, color: c, background: f, border: `7px solid ${TINTA}`, borderRadius: 20, boxShadow: `8px 9px 0 ${TINTA}`, padding: '6px 28px', whiteSpace: 'pre', lineHeight: 1.05, textAlign: 'center' }}>{children}</div>}</>;
};

/** Legenda de Reels: maiúscula, branca com contorno preto, a palavra falada em amarelo, até 4 palavras por vez. */
export const LegendaReels: React.FC<{ W: Palavra[]; t: number; top?: number }> = ({ W, t, top = 1600 }) => {
  const FIM = W[W.length - 1].end;
  if (t > FIM + 0.4) return null;
  const fr: [number, number][] = []; let a = 0;
  W.forEach((w, i) => { if (/[.?!:,]$/.test(w.text) || i - a + 1 >= 4 || i === W.length - 1) { fr.push([a, i]); a = i + 1; } });
  const f = [...fr].reverse().find(([b]) => t >= W[b].start - 0.05) ?? fr[0];
  return <div style={{ position: 'absolute', left: 30, right: 30, top, textAlign: 'center', fontFamily: '"Arial Black", Arial, sans-serif', fontWeight: 900, fontSize: 78, lineHeight: 1.1, textTransform: 'uppercase', WebkitTextStroke: '10px #111', paintOrder: 'stroke fill' }}>
    {W.slice(f[0], f[1] + 1).map((w, k) => <span key={k} style={{ color: t >= w.start - 0.03 && t <= w.end + 0.05 ? AMARELO : '#fff' }}>{w.text.replace(/[.,:]$/, '')} </span>)}
  </div>;
};

export const Esquete: React.FC<{
  W: Palavra[]; audio: string; cenarios: Record<string, Cenario>; planos: Plano[]; selos: Selo[];
  visual?: Visual; visualNoTempo?: (t: number) => Visual; mao?: (t: number) => { maoD?: React.ReactNode; bracoD?: number };
}> = ({ W, audio, cenarios, planos, selos, visual = {}, visualNoTempo, mao }) => {
  const t = useT();
  const q = achador(W);
  const ini = planos.map(p => (p.f === 0 ? 0 : q(p.f)));
  let i = 0;
  ini.forEach((s, k) => { if (t >= s - 0.04) i = k; });
  const p = planos[i], C = cenarios[p.set];
  if (!C) throw new Error('Cenário não existe: ' + p.set);
  const foco = p.foco ?? 'aberto';
  const [fx, fy, z0] = Array.isArray(foco) ? foco : foco === 'a' ? [C.a[0] + 70, C.a[1] - 420, 1.8] : foco === 'b' && C.b ? [C.b.x - 40, C.b.y - 360, 1.85] : [540, 760, 1];
  // Câmera viva: aproxima 2,5% por segundo dentro do plano (nunca parada).
  const z = z0 * (1 + Math.min(1.5, t - ini[i]) * 0.025);
  // Câmera presa ao cenário: nunca mostra fora da tela de 1080x1920.
  const cx = Math.min(Math.max(fx, 540 / z), 1080 - 540 / z), cy = Math.min(Math.max(fy, 760 / z), 1920 - 1160 / z);
  const m = mao?.(t) ?? {};
  const v = { ...visual, ...(visualNoTempo?.(t) ?? {}) };
  return (
    <AbsoluteFill style={{ background: '#111', overflow: 'hidden' }}>
      <Rabisco />
      <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0 }}>
        <g transform={`translate(540 760) scale(${z}) translate(${-cx} ${-cy})`}>
          <C.Fundo t={t} />
          {C.b && <C.b.P t={t} fala={falando(W, t, 'B')} />}
          {C.Frente && <C.Frente t={t} />}
          <PersonagemVivo {...v} t={t} x={C.a[0]} y={C.a[1]} fala={falando(W, t)} {...m} />
        </g>
      </svg>
      {ini.slice(1).map((s, k) => <Snd key={k} at={s} s="whoosh" v={0.1} />)}
      {selos.map((s, k) => { const a = q(s.f), b = s.ate ? q(s.ate) : ini.find(x => x > a + 0.01) ?? 1e9; return t >= a && t < b ? <SeloTela key={k} at={a} x={s.x ?? 540} y={s.y} z={s.z} c={s.c} f={s.fundo} r={s.r}>{s.t}</SeloTela> : null; })}
      <LegendaReels W={W} t={t} />
      <Audio src={staticFile(audio)} />
    </AbsoluteFill>
  );
};

// ---------- peças de cenário (SVG, coordenadas da tela 1080x1920) ----------
/** Parede até y=1250 e chão embaixo. */
export const Parede: React.FC<{ cor: string; chao: string }> = ({ cor, chao }) => <><rect width={1080} height={1250} fill={cor} /><rect y={1250} width={1080} height={670} fill={chao} /><path d="M0 1250 H1080" stroke={TINTA} strokeWidth={8} /></>;
/** Placa com texto (nome da loja, preço, aviso). */
export const Placa: React.FC<{ x: number; y: number; w: number; t: string; f?: string; c?: string; z?: number }> = ({ x, y, w, t, f = '#fff', c = TINTA, z = 76 }) => <g><rect x={x - w / 2} y={y} width={w} height={z * 1.45} rx={12} fill={f} {...traco} strokeWidth={8} /><text x={x} y={y + z * 1.08} textAnchor="middle" fontFamily={MAO} fontSize={z} fill={c}>{t}</text></g>;
export const Caixa: React.FC<{ x: number; y: number; w?: number; h?: number; t?: string }> = ({ x, y, w = 160, h = 120, t }) => <g><rect x={x} y={y} width={w} height={h} fill="#C99A5B" {...traco} strokeWidth={6} /><path d={`M${x} ${y + 26} H${x + w} M${x + w / 2} ${y} V${y + 26}`} stroke={TINTA} strokeWidth={5} />{t && <text x={x + w / 2} y={y + h * 0.7} textAnchor="middle" fontFamily={MAO} fontSize={26} fill={VERMELHO}>{t}</text>}</g>;
export const Carro: React.FC<{ x: number; y: number; cor: string; s?: number; amassado?: boolean }> = ({ x, y, cor, s = 1, amassado }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path d="M-150 0 V-70 Q-140 -90 -100 -95 L-60 -150 H70 L120 -95 Q150 -90 150 -70 V0 Z" fill={cor} {...traco} strokeWidth={7} />
    <path d="M-48 -140 H-5 V-98 H-80 Z M10 -140 H60 L96 -98 H10 Z" fill="#BFE4FF" {...traco} strokeWidth={5} />
    {amassado && <path d="M60 -60 l20 15 l-15 10 l25 12" fill="none" stroke={TINTA} strokeWidth={6} />}
    {[-90, 90].map(w => <g key={w}><circle cx={w} cy={0} r={34} fill={TINTA} /><circle cx={w} cy={0} r={14} fill="#aaa" /></g>)}
  </g>
);
export const CelularSvg: React.FC<{ x: number; y: number; s?: number; children?: React.ReactNode }> = ({ x, y, s = 1, children }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}><rect x={-110} y={-200} width={220} height={400} rx={30} fill={TINTA} /><rect x={-95} y={-175} width={190} height={350} rx={16} fill="#fff" />{children}</g>
);
/** Nota de dinheiro desenhada. */
export const Nota: React.FC<{ x: number; y: number; r?: number; s?: number }> = ({ x, y, r = 0, s = 1 }) => <g transform={`translate(${x} ${y}) rotate(${r}) scale(${s})`}><rect x={-60} y={-28} width={120} height={56} rx={6} fill="#7FBF7F" stroke={TINTA} strokeWidth={4} /><circle cx={0} cy={0} r={16} fill="#5E9E5E" /><text x={-46} y={-8} fontFamily={MAO} fontSize={18} fill={TINTA}>R$</text></g>;
