// Peças comuns a todos os motores: tempo em segundos, efeito sonoro no segundo exato e o "achador" de frases na narração.
import React from 'react';
import { Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig, Easing } from 'remotion';

/** Palavra da narração com o tempo em segundos. `quem` diz quem fala (diálogo com duas vozes). */
export type Palavra = { text: string; start: number; end: number; quem?: string };
/** O que o alinhador grava em src/data/<nome>.json. */
export type Narracao = { words: Palavra[] };

/** Opções do interpolate que travam nos dois lados (o valor não passa do alvo). */
export const cl = { extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const };
export const lerp = (v: number, a: number, b: number) => a + (b - a) * v;

/** Tempo do vídeo em segundos (tudo é função do tempo: o mesmo quadro sai igual em todo render). */
export function useT() { const f = useCurrentFrame(); const { fps } = useVideoConfig(); return f / fps; }
/** 0 → 1 suave a partir de `at` segundos, durando `d` segundos. */
export function useEase(at: number, d = 0.35, e = Easing.out(Easing.exp)) { const t = useT(); return interpolate(t, [at, at + d], [0, 1], { ...cl, easing: e }); }
/** Mola sem tremedeira a partir de `at` segundos. */
export function useSpr(at: number, stiff = 140, damp = 20) {
  const f = useCurrentFrame(); const { fps } = useVideoConfig();
  return spring({ frame: f - at * fps, fps, config: { stiffness: stiff, damping: damp, mass: 1 } });
}

/** Nomes dos efeitos em public/sfx/<nome>.mp3 (biblioteca sintetizada, sem direito autoral de terceiros). */
export type Fx = 'tick' | 'type' | 'whoosh' | 'swipe' | 'pop' | 'click' | 'coin' | 'cash' | 'notif' | 'error' | 'impact' | 'riser' | 'sparkle' | 'stamp' | 'success' | 'logo' | 'papel';
/** Efeito sonoro que começa em `at` segundos. `v` = volume (0 a 1). */
export const Snd: React.FC<{ at: number; s: Fx; v?: number; d?: number }> = ({ at, s, v = 0.35, d = 1.6 }) => {
  const { fps } = useVideoConfig();
  return <Sequence from={Math.max(0, Math.round(at * fps))} durationInFrames={Math.max(1, Math.round(d * fps))} layout="none"><Audio src={staticFile(`sfx/${s}.mp3`)} volume={v} /></Sequence>;
};

const limpa = (x: string) => x.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\p{L}\p{N}%$]/gu, '');
/**
 * Devolve uma função que acha o segundo em que uma frase começa na narração.
 * Use 2 a 4 palavras únicas do roteiro ("Vinte quilos," acha a primeira vez que isso é falado).
 * Frase que não existe quebra o render com erro claro, em vez de cair no lugar errado.
 */
export const achador = (W: Palavra[]) => (frase: string): number => {
  const a = frase.split(/\s+/).map(limpa).filter(Boolean);
  for (let i = 0; i <= W.length - a.length; i++) if (a.every((x, j) => limpa(W[i + j].text) === x)) return W[i].start;
  throw new Error('Frase não achada na narração: "' + frase + '". Use palavras exatas do roteiro.');
};
/** Igual ao achador, mas devolve a POSIÇÃO da 1ª palavra da frase (para o motor narrado e para destacar palavras). */
export const indice = (W: Palavra[]) => (frase: string): number => {
  const a = frase.split(/\s+/).map(limpa).filter(Boolean);
  for (let i = 0; i <= W.length - a.length; i++) if (a.every((x, j) => limpa(W[i + j].text) === x)) return i;
  throw new Error('Frase não achada na narração: "' + frase + '".');
};
/** Duração do vídeo: fim da última palavra + respiro. */
export const fimDaFala = (W: Palavra[], respiro = 1.4) => W[W.length - 1].end + respiro;
/** Alguém está falando agora? (sem `quem`, vale qualquer palavra sem dono ou do narrador "A"). */
export const falando = (W: Palavra[], t: number, quem?: string) => W.some(w => (quem ? (w.quem ?? 'A') === quem : !w.quem || w.quem === 'A') && t >= w.start - 0.02 && t <= w.end);
