# Licença das fontes

**Resumo:** as duas fontes desta pasta são livres sob a SIL Open Font License 1.1. Podem ser usadas em qualquer vídeo, inclusive comercial, e redistribuídas junto com este aviso. Não podem ser vendidas sozinhas.

- **Inter** (`inter-latin.woff2`, `inter-latin-ext.woff2`): Copyright 2020 The Inter Project Authors (https://github.com/rsms/inter).
- **Patrick Hand** (`patrick-latin.woff2`, `patrick-latin-ext.woff2`): Copyright (c) 2010-2012 Patrick Wagesreiter (mail@patrickwagesreiter.at).

Arquivos baixados do Google Fonts, sem modificação. Texto completo da licença: https://openfontlicense.org/open-font-license-official-text/
