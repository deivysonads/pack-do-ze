# Licença e créditos

**Resumo:** a skill é livre (licença MIT): pode usar, copiar, mudar e distribuir, inclusive em vídeo comercial, desde que mantenha este aviso. Os efeitos sonoros foram sintetizados do zero e a fonte é aberta. Música, imagem e marca que você puser nos seus vídeos são responsabilidade sua.

## MIT

Copyright (c) 2026 Deivyson Lucas (Zé do Digital) e estudio-ia

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## Créditos

- **Método e scripts de base:** [estudio-ia](https://github.com/iamjeffia/estudio-ia) (MIT). Daí vêm o detector de saltos (`scripts/detectar_saltos.py`) e o sintetizador que gerou os efeitos.
- **Efeitos sonoros (`modelo/public/sfx/`):** sintetizados por código, sem gravação de terceiros. Livres para qualquer uso.
- **Fontes:** Patrick Hand e Inter, do Google Fonts (SIL Open Font License), em `modelo/public/fonts/` e carregadas do disco por `src/kit/fontes.ts` (o render não depende da internet).
- **Remotion:** biblioteca de terceiros com licença própria. É grátis para pessoa física e empresas pequenas; empresas maiores precisam da licença da empresa (remotion.dev/license). Confira antes de usar comercialmente numa empresa.
- **Narrações de exemplo:** geradas com o Gemini TTS do Google para esta skill. O app "Moedinha" do exemplo é fictício.
