---
name: video-com-ia
description: Fábrica de vídeos com IA no Claude Code, do zero ao post agendado — ideia, roteiro, narração grátis (Gemini TTS, uma voz ou diálogo), tempo de cada palavra (Whisper local), animação em código com 4 motores prontos (Reel de caderno com personagem, esquete com cenário e câmera, aula 16:9 para YouTube e anúncio narrado de produto), efeitos sonoros próprios, render que não trava em computador fraco, revisão quadro a quadro e publicação. Usar sempre que a pessoa pedir um vídeo, Reel, Short, TikTok, vídeo para YouTube, anúncio, série de conteúdo, "faz um vídeo sobre X", roteiro para vídeo, narração, legenda animada, ou quiser montar a rotina de postar vídeo todo dia.
---

# Vídeo com IA: do zero ao post

**Resumo:** esta skill transforma o Claude Code num estúdio de vídeo. A pessoa diz o assunto; o Claude escreve o roteiro, gera a narração de graça, sincroniza cada palavra, anima num dos 4 motores prontos, põe som, renderiza, confere e (se ela quiser) agenda o post. Tudo roda no computador da pessoa, com ferramentas grátis. Os detalhes de cada etapa estão em `references/`; aqui está o caminho e as regras que não podem ser quebradas.

## Antes de tudo

1. **Primeira vez?** Siga [references/01-instalar.md](references/01-instalar.md): Node, ffmpeg, uv, Chrome, o projeto modelo e a chave grátis do Gemini. Confira com `node -v && ffmpeg -version && uv --version` antes de seguir.
2. **Combine o "pronto" uma vez, no começo.** Se o pedido não diz, pergunte de uma vez só, com opções: formato (Reel 9:16 ou YouTube 16:9), duração, onde vai ser postado, qual motor (ou "você escolhe") e se a pessoa quer aprovar o roteiro e a voz antes. Depois disso, resolva sozinho.
3. **Fale simples.** Quem usa esta skill quase nunca é programador. Explique o termo quando precisar e mostre o resultado (folha de quadros, vídeo), não só o comando.

## O caminho de todo vídeo

| # | Etapa | Como | Detalhes |
|---|---|---|---|
| 1 | **Ideia que presta** | um fato surpreendente nos 3 primeiros segundos; ensina, faz conta ou conta bastidor; nada de humor raso que não ensina | [02-ideias-e-roteiro.md](references/02-ideias-e-roteiro.md) |
| 2 | **Roteiro** | escrito como se fala, frases curtas, números por extenso, gancho fixo da série, final que manda compartilhar | [02-ideias-e-roteiro.md](references/02-ideias-e-roteiro.md) |
| 3 | **Narração** | `python3 <skill>/scripts/voz.py roteiro.txt narracao.wav` (uma voz) ou diálogo com linhas `A:`/`B:` | [03-voz.md](references/03-voz.md) |
| 4 | **Ouvir antes de animar** | a pessoa aprova a voz (ou você confere com o Whisper se ela delegou): tudo depois depende do áudio | [03-voz.md](references/03-voz.md) |
| 5 | **Tempo das palavras** | `uv run --with faster-whisper python <skill>/scripts/alinhar.py narracao.wav roteiro.txt <nome>` → `public/<nome>.wav` + `src/data/<nome>.json` | [03-voz.md](references/03-voz.md) |
| 6 | **Referência e material real** | o que a fala cita aparece na tela (marca, app, lugar, notícia), com visual da plataforma real | [07-referencias-e-telas.md](references/07-referencias-e-telas.md) |
| 7 | **Montar no motor** | copie o exemplo do motor certo para `src/videos/<nome>.tsx`, troque cenas, selos e cartões, registre em `src/index.tsx` | [04-motores.md](references/04-motores.md) |
| 8 | **Folha de quadros** | `bash <skill>/scripts/folha.sh <id> 0.5 3 6 9 ...` e OLHE a imagem antes de renderizar | [08-render-e-revisao.md](references/08-render-e-revisao.md) |
| 9 | **Render final** | `bash <skill>/scripts/render.sh <id> out/<id>.mp4` (pedaços, áudio à parte, volume das redes, conferência de saltos) | [08-render-e-revisao.md](references/08-render-e-revisao.md) |
| 10 | **Assistir e conferir** | quadros do vídeo final, volume, salto de quadro; corrigir e renderizar só o que mudou | [08-render-e-revisao.md](references/08-render-e-revisao.md) |
| 11 | **Publicar** | agendar (Metricool ou o app da rede), legenda, horário fixo, série | [09-publicar.md](references/09-publicar.md) |

`<skill>` é a pasta desta skill (onde está este arquivo). Os comandos das etapas 5, 8 e 9 rodam **de dentro da pasta do projeto** (a cópia do `modelo/`).

## Qual motor usar

| Motor | Formato | Quando | Exemplo pronto |
|---|---|---|---|
| **caderno** (`ReelCaderno`) | Reel 9:16, 60 fps | conta que fecha, lista, explicação rápida; personagem anda e fala sobre um caderno quadriculado | `src/exemplos/caderno.tsx` |
| **esquete** (`Esquete`) | Reel 9:16, 60 fps | historinha com cenário desenhado, câmera que corta para o close, selos com números, legenda amarela e preta; uma ou duas vozes | `src/exemplos/esquete.tsx` |
| **aula** (`Aula`) | YouTube 16:9, 30 fps | vídeo longo de ensino (4 a 12 min): palavra grande por vez, emoji nas palavras-chave, cartões "PASSO Nº", amigo que interrompe com a dúvida do público | `src/exemplos/aula.tsx` |
| **narrado** (`Narrado`) | Reel 9:16, 60 fps | anúncio de produto ou app, explicativo "sério": fundo escuro com brilho da marca, texto palavra por palavra, pílulas 3D, celular 3D com a tela do app, toque | `src/exemplos/narrado.tsx` |

Não sabe? **Reel de dinheiro, curiosidade ou dica = caderno ou esquete. YouTube = aula. Produto = narrado.** Alterne formatos na semana para testar o que o público prefere.

## Regras que não podem ser quebradas

**Conteúdo**
- Nada de conta inventada. Número vem de fonte (e a fonte fica anotada no projeto) ou aparece na tela como "valores de exemplo".
- Nada de promessa de dinheiro fácil, pirâmide, aposta, golpe ensinado ou sonegação. Imposto e governo: fato e lei, sem lado político.
- Nada de rosto de pessoa real sem autorização, logo de empresa como se fosse parceira, depoimento falso ou marca real como cliente fictício.
- Música e imagem de terceiros só com licença. Os efeitos sonoros do modelo são sintetizados (livres).

**Técnica** (os números completos estão em [05-movimento-e-legenda.md](references/05-movimento-e-legenda.md))
- **Nada aparece antes de ser dito.** Cada elemento entra na palavra que o justifica (o `achador` acha o segundo exato pela frase do roteiro).
- **A tela só troca depois da frase.** Câmera nunca parada: deriva lenta o tempo todo.
- **Reel a 60 fps, YouTube a 30 fps.** Render final com `--concurrency=1` (em paralelo, camadas somem em quadros soltos): o `render.sh` já faz.
- **Volume final:** −15 LUFS no Reel e −14 no YouTube, pico ≤ −2 dBTP. O `render.sh` já nivela e mostra o valor.
- **Id da composição:** só minúsculas, números e `-` (`yt-dividas`, nunca `yt_dividas`).
- **Olhe o quadro de verdade** antes de dizer que está pronto: comando que terminou sem erro não prova que o vídeo está bom.

**Segurança**
- A chave do Gemini fica no `.env` do projeto (que está no `.gitignore`). Nunca escreva o valor em doc, código ou chat.
- Não crie conta nem digite senha pela pessoa: deixe tudo pronto e peça para ela fazer esse passo.
- Publicar é ação pública. Agende sozinho só se a pessoa disse claramente que pode postar sem aprovar; senão, mostre e peça o OK.

## Quando algo falha

| Sintoma | O que fazer |
|---|---|
| `voz.py`: erro 429 em todas as chaves | cota grátis do dia acabou (volta ~5h de Brasília). Ponha mais chaves (`GEMINI_API_KEY_2`...), ou peça para a pessoa gravar o roteiro no celular e siga do passo 5 com o áudio dela |
| `alinhar.py`: "menos de 85% casou" | a voz pulou ou trocou frase: ouça; gere de novo ou ajuste o roteiro para o que foi falado |
| A voz leu a instrução de estilo em voz alta | o `alinhar.py` corta sozinho a fala que vem antes da 1ª palavra do roteiro |
| `Frase não achada na narração` | o `f:` de uma cena ou selo não bate com o roteiro: use 2 a 4 palavras exatas, na ordem |
| Render lento ou travando | normal em máquina fraca (~4 a 5 min por minuto de vídeo 1080p). Feche outros programas; use `PREVIA=1` para testar |
| Quadro preto ou camada sumindo num quadro | rode `detectar_saltos.py` (o `render.sh` roda) e renderize de novo só o trecho com `--frames` |
| Quer gerar vídeo "de verdade" com IA (pessoa falando, cena realista) num Mac/PC comum | não funciona bem localmente; leia [10-licoes.md](references/10-licoes.md) antes de prometer |

## Referências

- [01-instalar.md](references/01-instalar.md): programas, projeto modelo, chave do Gemini, como instalar esta skill.
- [02-ideias-e-roteiro.md](references/02-ideias-e-roteiro.md): o que dá view, ganchos, séries que funcionaram, modelos de roteiro por formato.
- [03-voz.md](references/03-voz.md): Gemini TTS (vozes, estilo, diálogo, cota), voz própria, alinhamento, trocar só o gancho.
- [04-motores.md](references/04-motores.md): como usar e estender cada motor, o personagem e um vídeo novo do zero.
- [05-movimento-e-legenda.md](references/05-movimento-e-legenda.md): os números de movimento, câmera, legenda e ritmo.
- [06-som.md](references/06-som.md): efeitos, música, volume e mixagem.
- [07-referencias-e-telas.md](references/07-referencias-e-telas.md): assistir referência, material real, marca, telas de app dentro do vídeo.
- [08-render-e-revisao.md](references/08-render-e-revisao.md): folha de quadros, render, conferência, consertar só um trecho.
- [09-publicar.md](references/09-publicar.md): agendamento, horários, legendas, rotina de 6 vídeos por dia.
- [10-licoes.md](references/10-licoes.md): o que já testamos e não funcionou, para não perder tempo.
