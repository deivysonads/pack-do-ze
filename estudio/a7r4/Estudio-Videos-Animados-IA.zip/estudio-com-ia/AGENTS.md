# Estúdio de Vídeos Animados com IA

Esta pasta é o estúdio de vídeo da pessoa. Ela **não é programadora**: fale português simples, explique o termo quando precisar e mostre o resultado (a folha de quadros, o vídeo), não só o comando.

## Como trabalhar aqui

1. **Antes de qualquer pedido sobre vídeo, leia `video-com-ia/SKILL.md` e siga.** Onde o manual diz `<skill>`, é a pasta `./video-com-ia`. O projeto de vídeos é **esta pasta** (ela já tem `package.json`, `src/` e `public/`): não copie o modelo para outro lugar.
2. **Primeira vez** (não existe a pasta `node_modules/`) ou a pessoa disse "prepara tudo": siga o passo 0 de `video-com-ia/references/01-instalar.md`. Confira e instale o que falta (Node, ffmpeg, uv), rode `npm install`, crie o `.env` e renderize um exemplo para provar que funciona. Depois diga, em 3 linhas, o que ela pode pedir agora.
3. **Voz:** peça a chave grátis do Google (passo 4 do manual de instalação). Se ela não quiser, ofereça o VoiceStudio (voz grátis no próprio computador, `video-com-ia/references/03-voz.md`) ou gravar a voz no celular.
4. **Ela colou um link de vídeo** (YouTube, Instagram, TikTok)? Baixe, assista e aprenda o modelo (`video-com-ia/references/07-referencias-e-telas.md`). Use a estrutura e o ritmo; não copie personagem, marca nem texto de outra pessoa.
5. **Pediu ideias?** Dê 10 ideias com o gancho de cada uma (`video-com-ia/references/02-ideias-e-roteiro.md`) e ofereça fazer a que ela escolher.
6. **Nunca peça senha no chat.** Se um instalador pedir a senha do computador, é ela que digita, na janela do próprio computador. A chave da voz fica só no arquivo `.env`.
7. Os vídeos prontos saem na pasta `out/`. Diga sempre o nome do arquivo.
