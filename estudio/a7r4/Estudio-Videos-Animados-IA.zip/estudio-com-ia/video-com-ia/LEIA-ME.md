# Vídeo com IA: a skill

**Resumo:** uma skill para o Claude Code que faz vídeo do zero: roteiro, narração grátis, animação, som, render e agendamento. Ela traz 5 motores prontos (Reel de caderno, esquete com cenário, aula 16:9 para YouTube, anúncio narrado e dossiê de investigação), um exemplo de cada e os scripts que fazem o trabalho pesado. Tudo grátis, rodando no seu computador.

## Veio a pasta `estudio-com-ia`? Não precisa instalar nada

Abra a pasta `estudio-com-ia` no Claude (aba Code → escolher pasta) e mande: "prepara tudo pra eu fazer meu primeiro vídeo". Os passos abaixo são só para quem recebeu esta pasta `video-com-ia` solta.

## Instalar em 3 passos

1. **Coloque esta pasta** (`video-com-ia`) em `~/.claude/skills/` (no Windows: `C:\Users\<voce>\.claude\skills\`). Crie a pasta `skills` se ela não existir.
2. **Abra o Claude Code** em qualquer pasta e peça:
   > Use a skill video-com-ia e prepare tudo para eu fazer meu primeiro vídeo.

   O Claude confere e instala o que falta (Node, ffmpeg, uv), monta o seu projeto de vídeos e pede a sua chave grátis do Gemini (https://aistudio.google.com/apikey).
3. **Peça um vídeo:**
   > Faz um Reel de 30 segundos explicando quanto rende guardar 10 reais por dia.

## O que vem dentro

```
video-com-ia/
├── SKILL.md          ← o que o Claude lê primeiro: o caminho de todo vídeo
├── references/       ← o manual de cada etapa (ideia, voz, motores, movimento, som, render, publicar, lições)
├── scripts/          ← voz.py, alinhar.py, troca_gancho.py, folha.sh, render.sh, detectar_saltos.py
└── modelo/           ← projeto de vídeo pronto (Remotion): os 5 motores, 5 exemplos com voz, efeitos sonoros próprios e trilha de suspense
```

## Requisitos

- Claude Code (claude.com/claude-code).
- Mac, Windows ou Linux com uns 2 GB livres. Rodou num MacBook M1 de 8 GB: um Reel de 20 s renderiza em ~2 min.
- Conta Google, para a chave grátis da voz. Sem ela, grave a narração no celular.

Licença MIT ([LICENCA.md](LICENCA.md)).
