#!/usr/bin/env python3
"""Trilha e efeitos de suspense/investigação, sintetizados do zero (sem amostra de ninguém).

Uso: .venv/bin/python scripts/som/suspense.py <pasta-saida> <segundos-da-trilha>
Sai na pasta:
  trilha.wav    drone grave + pad em ré menor que respira + pulso de relógio + chiado de vinil
  maquina.wav   uma tecla de máquina de escrever (varie o volume e repita pra digitar)
  sino.wav      o "ding" do fim de linha da máquina
  impacto.wav   batida grave de troca de cena (boom + sopro)
  placas.wav    o clique-clique de um contador de placas (split-flap) girando, 0,9 s
  papel.wav     papel deslizando na mesa
  carimbo.wav   carimbo batendo na mesa
  riser.wav     subida de tensão, 2 s
Depois de montar, nivele o vídeo inteiro (−15 LUFS, regra do estúdio).
"""
import sys, wave
import numpy as np

SR = 48000
out = sys.argv[1]
DUR = float(sys.argv[2]) if len(sys.argv) > 2 else 45.0
rng = np.random.default_rng(11)


def grava(nome, x, est=True):
    x = x / (np.max(np.abs(x)) + 1e-9) * 0.85
    d = np.stack([x, x], 1) if est else x[:, None]
    with wave.open(f'{out}/{nome}', 'wb') as w:
        w.setnchannels(d.shape[1]); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((d * 32767).astype(np.int16).tobytes())


def t_(d):
    return np.arange(int(d * SR)) / SR


def passa_baixa(x, corte):
    # filtro de 1 polo, simples e estável
    a = np.exp(-2 * np.pi * corte / SR)
    y = np.zeros_like(x)
    acc = 0.0
    for i in range(len(x)):
        acc = (1 - a) * x[i] + a * acc
        y[i] = acc
    return y


def passa_baixa_rapido(x, corte):
    # versão vetorizada aproximada (média móvel) pra sinais longos
    n = max(1, int(SR / corte / 2))
    k = np.ones(n) / n
    return np.convolve(x, k, mode='same')


# ---------- trilha ----------
t = t_(DUR)
hz = lambda nota: 440 * 2 ** (nota / 12)
# drone grave: ré 1 (36,7 Hz) + quinta, com respiração lenta
drone = (np.sin(2 * np.pi * 36.71 * t) + 0.6 * np.sin(2 * np.pi * 73.42 * t) + 0.25 * np.sin(2 * np.pi * 55.0 * t)) * (0.75 + 0.25 * np.sin(2 * np.pi * 0.07 * t))
# pad em ré menor (ré, fá, lá) com cordas desafinadas de leve, entrando devagar
pad = np.zeros_like(t)
for semi in (-19, -16, -12, -7, -4):  # ré3, fá3, lá3, ré4, fá4
    f = hz(semi)
    for det in (-0.6, 0.0, 0.7):
        for h, g in ((1, 1.0), (2, 0.35), (3, 0.15)):
            pad += g * np.sin(2 * np.pi * (f + det) * h * t + rng.uniform(0, 6.28))
pad = passa_baixa_rapido(pad, 900) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.11 * t + 1))
pad *= np.minimum(1, t / 4.0)
# pulso de relógio grave a cada 1,2 s, bem baixo
pulso = np.zeros_like(t)
k = 0
while k * 1.2 < DUR:
    i = int(k * 1.2 * SR); n = int(0.18 * SR)
    if i + n < len(t):
        tt = np.arange(n) / SR
        pulso[i:i + n] += np.sin(2 * np.pi * 52 * tt) * np.exp(-tt * 22)
    k += 1
# chiado de vinil: chiado filtrado + estalos esparsos
chiado = passa_baixa_rapido(rng.standard_normal(len(t)), 5000) * 0.05
estalos = np.zeros_like(t)
for i in rng.integers(0, len(t) - 200, int(DUR * 9)):
    estalos[i:i + 60] += rng.standard_normal(60) * np.exp(-np.arange(60) / 9) * rng.uniform(0.2, 1.0)
mix = drone * 0.55 + pad * 0.12 + pulso * 0.35 + chiado + estalos * 0.25
fade = int(2.5 * SR)
mix[-fade:] *= np.linspace(1, 0, fade)
mix[:int(0.5 * SR)] *= np.linspace(0, 1, int(0.5 * SR))
grava('trilha.wav', mix)

# ---------- efeitos ----------
tt = t_(0.06)
tecla = rng.standard_normal(len(tt)) * np.exp(-tt * 140) + 0.6 * np.sin(2 * np.pi * 2300 * tt) * np.exp(-tt * 90) + 0.5 * np.sin(2 * np.pi * 160 * tt) * np.exp(-tt * 70)
grava('maquina.wav', tecla)

tt = t_(1.2)
grava('sino.wav', (np.sin(2 * np.pi * 2093 * tt) + 0.4 * np.sin(2 * np.pi * 4186 * tt * 1.003)) * np.exp(-tt * 4))

tt = t_(2.2)
boom = np.sin(2 * np.pi * (55 * np.exp(-tt * 1.5) + 30) * tt) * np.exp(-tt * 2.2)
sopro = passa_baixa_rapido(rng.standard_normal(len(tt)), 2500) * np.exp(-tt * 6) * 0.5
grava('impacto.wav', boom + sopro)

tt = t_(0.9)
placas = np.zeros_like(tt)
for i in range(18):
    ini = int((i * 0.045 + rng.uniform(0, 0.01)) * SR); n = int(0.03 * SR)
    seg = np.arange(n) / SR
    placas[ini:ini + n] += (rng.standard_normal(n) * 0.7 + np.sin(2 * np.pi * 1400 * seg)) * np.exp(-seg * 160)
placas *= np.linspace(1, 0.5, len(tt))
grava('placas.wav', placas)

tt = t_(0.5)
papel = passa_baixa_rapido(rng.standard_normal(len(tt)), 6000) * np.sin(np.pi * tt / 0.5) ** 2
grava('papel.wav', papel)

tt = t_(0.5)
carimbo = np.sin(2 * np.pi * 90 * tt) * np.exp(-tt * 25) + rng.standard_normal(len(tt)) * np.exp(-tt * 60) * 0.6
grava('carimbo.wav', carimbo)

tt = t_(2.0)
riser = passa_baixa_rapido(rng.standard_normal(len(tt)), 3000) * (tt / 2.0) ** 2 + np.sin(2 * np.pi * (80 + 300 * (tt / 2) ** 2) * tt) * (tt / 2.0) * 0.4
grava('riser.wav', riser)
print('ok', out)
