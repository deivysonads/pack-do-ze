#!/usr/bin/env python3
"""Narração grátis SEM chave, com o VoiceStudio (programa de vozes que roda no próprio computador).

Uso (com o VoiceStudio aberto):
    python3 voz_local.py --vozes                         # lista as vozes que existem no VoiceStudio
    python3 voz_local.py roteiro.txt narracao.wav        # usa a voz padrão do programa
    python3 voz_local.py roteiro.txt narracao.wav --voz "nome da voz"

O VoiceStudio é grátis (https://github.com/debpalash/VoiceStudio, Windows, Mac e Linux). A pessoa instala,
abre, baixa um modelo de voz dentro do programa e cria ou escolhe uma voz. Ele atende em http://localhost:3900.
Cada modelo de voz tem a sua licença: confira se a voz escolhida pode ser usada em vídeo que vende.

O roteiro vai um parágrafo por vez (modelo pequeno erra menos assim) e os pedaços são emendados com 0,3 s de respiro.
Sai um WAV 48 kHz mono e um <saida>.txt com o texto puro (o alinhador usa). Precisa do ffmpeg.
"""
import argparse, json, os, subprocess, sys, tempfile, urllib.request, urllib.error

p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
p.add_argument('roteiro', nargs='?'); p.add_argument('saida', nargs='?')
p.add_argument('--voz', default='default'); p.add_argument('--modelo', default='tts-1', help="motor do VoiceStudio; 'tts-1' = o que estiver ativo")
p.add_argument('--url', default=os.environ.get('VOICESTUDIO_URL', 'http://localhost:3900'))
p.add_argument('--vozes', action='store_true', help='só lista as vozes')
a = p.parse_args()


def pede(caminho, corpo=None, espera=900):
    req = urllib.request.Request(a.url + caminho, data=json.dumps(corpo).encode() if corpo else None, headers={'Content-Type': 'application/json'})
    try:
        return urllib.request.urlopen(req, timeout=espera).read()
    except urllib.error.HTTPError as e:
        sys.exit(f'O VoiceStudio respondeu erro {e.code}: {e.read().decode(errors="ignore")[:400]}')
    except Exception as e:
        sys.exit(f'Não achei o VoiceStudio em {a.url} ({e}). Abra o programa e tente de novo.')


if a.vozes:
    d = json.loads(pede('/v1/audio/voices', espera=20))
    vozes = d.get('voices') or d.get('data') or d
    for v in vozes if isinstance(vozes, list) else []:
        print('-', v.get('name') or v.get('id') if isinstance(v, dict) else v)
    if not vozes: print('Nenhuma voz ainda: crie uma dentro do VoiceStudio.')
    sys.exit(0)
if not a.roteiro or not a.saida: p.error('faltou o roteiro e o arquivo de saída')

texto = open(a.roteiro, encoding='utf-8').read()
partes = [' '.join(x.split()) for x in texto.split('\n\n') if x.strip()]
tmp = tempfile.mkdtemp(); arquivos = []
for i, parte in enumerate(partes):
    bruto = pede('/v1/audio/speech', {'model': a.modelo, 'input': parte, 'voice': a.voz, 'response_format': 'wav'})
    f = os.path.join(tmp, f'p{i}.bin'); open(f, 'wb').write(bruto)
    w = os.path.join(tmp, f'p{i}.wav')
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', f, '-ac', '1', '-ar', '48000',
                    '-af', 'silenceremove=start_periods=1:start_threshold=-45dB,areverse,silenceremove=start_periods=1:start_threshold=-45dB,areverse,apad=pad_dur=0.3', w], check=True)
    arquivos.append(w); print(f'parte {i + 1} de {len(partes)} pronta', flush=True)
lista = os.path.join(tmp, 'lista.txt'); open(lista, 'w').write(''.join(f"file '{w}'\n" for w in arquivos))
subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', lista, '-c:a', 'pcm_s16le', a.saida], check=True)
open(a.saida + '.txt', 'w', encoding='utf-8').write('\n\n'.join(partes))
print('voz pronta:', a.saida)
