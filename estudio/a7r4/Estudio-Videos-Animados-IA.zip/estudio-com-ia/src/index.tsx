// Registro dos vídeos. Cada vídeo novo = um arquivo em src/videos/ + uma <Composition> aqui.
// Id só com letras minúsculas, números e "-" (o Remotion recusa "_").
// Reels/Shorts/TikTok: 1080x1920 a 60 fps. YouTube deitado: 1920x1080 a 30 fps (vídeo longo renderiza 2x mais rápido).
import React from 'react';
import { Composition, registerRoot } from 'remotion';
import { ExemploCaderno, CADERNO_FIM } from './exemplos/caderno';
import { ExemploEsquete, ESQUETE_FIM } from './exemplos/esquete';
import { ExemploAula, AULA_FIM } from './exemplos/aula';
import { ExemploNarrado, NARRADO_FIM } from './exemplos/narrado';
import { ExemploDossie, DOSSIE_FIM } from './exemplos/dossie';

const REEL = { width: 1080, height: 1920, fps: 60 };
const LONGO = { width: 1920, height: 1080, fps: 30 };
const q = (s: number, fps: number) => Math.ceil(s * fps);

const Raiz: React.FC = () => (
  <>
    <Composition id="exemplo-caderno" component={ExemploCaderno} durationInFrames={q(CADERNO_FIM, 60)} {...REEL} />
    <Composition id="exemplo-esquete" component={ExemploEsquete} durationInFrames={q(ESQUETE_FIM, 60)} {...REEL} />
    <Composition id="exemplo-narrado" component={ExemploNarrado} durationInFrames={q(NARRADO_FIM, 60)} {...REEL} />
    <Composition id="exemplo-aula" component={ExemploAula} durationInFrames={q(AULA_FIM, 30)} {...LONGO} />
    <Composition id="exemplo-dossie" component={ExemploDossie} durationInFrames={q(DOSSIE_FIM, 30)} width={1080} height={1920} fps={30} />
  </>
);
registerRoot(Raiz);
