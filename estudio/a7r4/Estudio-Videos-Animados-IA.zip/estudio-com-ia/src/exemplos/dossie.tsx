// Exemplo do motor dossiê (9:16, 30 fps): como nasceu a Coca-Cola, em 30 segundos.
// Fonte dos fatos: The Coca-Cola Company, "The Birth of a Refreshing Idea" (1886, 5 centavos o copo, 9 copos por dia no 1º ano;
// Asa Candler ficou com o negócio por um investimento total de US$ 2.300).
// Para fazer o seu: copie este arquivo para src/videos/, troque as provas, as paradas da câmera (uma por cena, presa à frase) e os sons.
import React from 'react';
import { AbsoluteFill, Audio, interpolate, staticFile } from 'remotion';
import d from '../data/exemplo-dossie.json';
import { Carimbo, Circulo, Datilografado, Entra, F, Filme, Fontes, Jornal, LegendaDossie, Mesa, Palavra, Parada, Placas, PostIt, Som, Barbante, achador, cl, comAlgarismos } from '../kit/dossie';

const W = (d as { words: Palavra[] }).words;
/** Na legenda, número em algarismo (a voz fala por extenso). */
const LEG = comAlgarismos(W, [['mil oitocentos e oitenta e seis', '1886'], ['cinco centavos', '5 centavos'], ['nove copos', '9 copos'], ['dois mil e trezentos dólares', 'US$ 2.300']]);
const q = achador(W);
export const DOSSIE_FIM = W[W.length - 1].end + 2.0;

// A mesa tem 2400×3300. Cada parada: quando (segundos), centro (x, y), zoom (z), giro (r) e duração da viagem (d).
const P: Parada[] = [
  { at: 0, x: 800, y: 620, z: 0.6 },
  { at: 0.2, x: 800, y: 620, z: 1.2, d: 1.8 },
  { at: q('Um farmacêutico') - 0.3, x: 1650, y: 900, z: 1.15, r: 1 },
  { at: q('O copo custa') - 0.3, x: 760, y: 1560, z: 1.25, r: -1 },
  { at: q('No primeiro ano,') - 0.3, x: 1650, y: 1700, z: 1.2, r: 1 },
  { at: q('Doente e sem') - 0.3, x: 1000, y: 2350, z: 1.05, r: -1 },
  { at: q('Quem fica com') - 0.3, x: 1560, y: 2800, z: 1.2, r: 1 },
  { at: q('O nome do xarope?') - 0.2, x: 1200, y: 1700, z: 0.42, d: 1.6 },
];

export const ExemploDossie: React.FC = () => (
  <AbsoluteFill style={{ background: '#0E0805' }}>
    <Fontes />
    <Mesa paradas={P} w={2400} h={3300}>
      {/* 1. a data e o lugar */}
      <Entra at={0} x={800} y={620} r={-3} som={null}>
        <div style={{ width: 760, background: '#F2EADB', padding: '40px 30px 46px', boxShadow: '0 16px 30px rgba(0,0,0,.5)', textAlign: 'center' }}>
          <div style={{ fontFamily: F.courier, fontWeight: 700, fontSize: 40, letterSpacing: 14, color: '#3B2E24' }}>ATLANTA</div>
          <div style={{ fontFamily: F.jornal, fontWeight: 900, fontSize: 200, lineHeight: 1, color: '#1E1712' }}>1886</div>
        </div>
      </Entra>
      {/* 2. o personagem */}
      <Entra at={q('Um farmacêutico') - 0.15} x={1650} y={900} r={2}>
        <Datilografado w={860} topo="FARMÁCIA · FICHA" linhas={[{ de: q('John Pemberton'), txt: '> John Pemberton', dur: 0.8 }, { de: q('mistura um xarope'), txt: '> um xarope novo', dur: 0.8 }]} size={60} />
      </Entra>
      <Barbante at={q('O copo custa') - 0.5} de={[1500, 1150]} ate={[800, 1330]} />
      {/* 3. o preço */}
      <Entra at={q('O copo custa') - 0.2} x={760} y={1560} r={-2}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: F.courier, fontWeight: 700, fontSize: 32, letterSpacing: 6, color: '#E9DCC0', marginBottom: 14 }}>PREÇO DO COPO</div>
          <Placas trocas={[{ at: q('cinco centavos.'), txt: '$0,05' }]} size={170} />
        </div>
      </Entra>
      {/* 4. as vendas */}
      <Entra at={q('No primeiro ano,') - 0.15} x={1650} y={1700} r={4} de={[120, 0]}>
        <div style={{ position: 'relative' }}>
          <PostIt txt="9 copos por dia" size={74} w={460} />
          <div style={{ position: 'absolute', left: 30, top: 110, width: 400, height: 170 }}><Circulo at={q('Nove.')} w={400} h={170} /></div>
        </div>
      </Entra>
      {/* 5. a venda da fórmula */}
      <Entra at={q('Doente e sem') - 0.15} x={1000} y={2350} r={-2}>
        <Jornal w={960} secao="ATLANTA · NEGÓCIOS" titulo={<>VENDE A<br />FÓRMULA</>} texto="Doente e sem dinheiro, o farmacêutico passa adiante a receita do xarope que criou." />
      </Entra>
      <Entra at={q('Quem fica com') - 0.15} x={1560} y={2800} r={2}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: F.courier, fontWeight: 700, fontSize: 32, letterSpacing: 6, color: '#E9DCC0', marginBottom: 14 }}>ASA CANDLER PAGOU</div>
          <Placas trocas={[{ at: q('dois mil e trezentos'), txt: 'US$2.300' }]} size={130} />
        </div>
      </Entra>
      {/* 6. a virada: o nome */}
      <Entra at={q('O nome do xarope?') + 1.3} x={1740} y={380} r={-4} som={null}>
        <div style={{ transform: 'scale(2.1)' }}><Carimbo at={q('Coca-Cola.')} txt="COCA-COLA" size={90} r={0} /></div>
      </Entra>
    </Mesa>
    <Filme />
    <LegendaDossie W={LEG} />
    {/* som: a narração, a trilha de suspense bem baixa e um impacto em cada troca grande de cena */}
    <Audio src={staticFile('exemplo-dossie.wav')} />
    <Audio src={staticFile('sfx/trilha.wav')} volume={f => interpolate(f / 30, [0, 1, DOSSIE_FIM - 1.5, DOSSIE_FIM], [0, 0.16, 0.16, 0], cl)} />
    {[0.05, q('O copo custa') - 0.3, q('Doente e sem') - 0.3].map((a, i) => <Som key={'i' + i} at={a} s="impacto" v={0.5} />)}
    {P.slice(2).map((p, i) => <Som key={'w' + i} at={p.at} s="whoosh-1" v={0.22} />)}
    <Som at={q('O nome do xarope?') - 1.4} s="riser" v={0.3} />
    <Som at={q('Coca-Cola.')} s="brilho-1" v={0.3} />
  </AbsoluteFill>
);
