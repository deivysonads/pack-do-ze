// Motor "dossiê de investigação": uma história real contada como investigação, numa mesa de madeira com provas
// (polaroide, folha datilografada, post-it, contador de placas, recorte de jornal, carimbo, barbante vermelho).
// A câmera viaja de prova em prova com desfoque de movimento, e o look de filme (sépia, vinheta, grão) vai por cima.
// Tudo preso ao tempo das palavras da narração. Fontes em public/fontes/ e sons em public/sfx/*.wav.
// Exemplo pronto: src/exemplos/dossie.tsx. Como usar: references/04-motores.md, seção "Motor dossiê".
import React, { useEffect, useState } from 'react';
import { AbsoluteFill, Audio, Img, Sequence, continueRender, delayRender, interpolate, staticFile, useCurrentFrame, useVideoConfig, Easing } from 'remotion';

export type Palavra = { text: string; start: number; end: number };
export const cl = { extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const };
export const lerp = (v: number, a: number, b: number) => a + (b - a) * v;
export const useT = () => { const f = useCurrentFrame(); const { fps } = useVideoConfig(); return f / fps; };
const limpa = (x: string) => x.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\p{L}\p{N}%$]/gu, '');
export const achador = (W: Palavra[]) => (frase: string, n = 0): number => {
  const a = frase.split(/\s+/).map(limpa).filter(Boolean);
  let v = 0;
  for (let i = 0; i <= W.length - a.length; i++) if (a.every((x, j) => limpa(W[i + j].text) === x) && v++ === n) return W[i].start;
  throw new Error('Frase não achada na narração: "' + frase + '"');
};

export const TINTA = '#2A1E16', VERMELHO = '#B3261E', PAPEL = '#EFE4CC', PAPEL2 = '#E6D6B4', POSTIT = '#F2C94C';
export const F = { maquina: 'Special Elite', courier: 'Courier Prime', mao: 'Caveat', jornal: 'Playfair Display', placa: 'Oswald' };

/** Carrega as fontes de publicdossie/fontes pela FontFace API (sem internet) e segura o quadro até elas estarem prontas.
 *  A 1ª versão injetava @font-face por CSS: em alguns quadros a legenda saía invisível (09/11). */
const FACES: [string, string, string][] = [
  [F.maquina, 'specialelite-400', '400'], [F.courier, 'courierprime-400', '400'], [F.courier, 'courierprime-700', '700'],
  [F.mao, 'caveat-700', '700'], [F.jornal, 'playfairdisplay-900', '900'], [F.placa, 'oswald-600', '600'],
];
let carregando: Promise<void> | null = null;
const carrega = () => {
  if (!carregando) {
    carregando = Promise.all(FACES.flatMap(([fam, arq, w]) => [
      new FontFace(fam, `url(${staticFile(`fontes/${arq}-latin.woff2`)}) format('woff2')`, { weight: w, unicodeRange: 'U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD' }),
      new FontFace(fam, `url(${staticFile(`fontes/${arq}-ext.woff2`)}) format('woff2')`, { weight: w, unicodeRange: 'U+0100-02BA, U+1E00-1EFF' }),
    ].map(f => f.load().then(x => { (document.fonts as unknown as { add: (f: FontFace) => void }).add(x); })))).then(() => undefined);
  }
  return carregando;
};
export const Fontes: React.FC = () => {
  const [h] = useState(() => delayRender('fontes-dossie', { timeoutInMilliseconds: 30000 }));
  useEffect(() => {
    let livre = false;
    const solta = () => { if (!livre) { livre = true; continueRender(h); } };
    carrega().then(() => document.fonts.ready).then(solta).catch(e => { console.error('Fonte do dossiê falhou', e); solta(); });
    return () => solta();
  }, [h]);
  return null;
};

export const Som: React.FC<{ at: number; s: string; v?: number; d?: number }> = ({ at, s, v = 0.5, d = 2.5 }) => {
  const { fps } = useVideoConfig();
  return <Sequence from={Math.max(0, Math.round(at * fps))} durationInFrames={Math.max(1, Math.round(d * fps))} layout="none"><Audio src={staticFile(`sfx/${s}.wav`)} volume={v} /></Sequence>;
};

// ---------- câmera ----------
export type Parada = { at: number; x: number; y: number; z: number; d?: number; r?: number };
/** Posição da câmera no tempo t (centro na mesa, zoom, giro), com curva suave entre as paradas. */
export const camEm = (paradas: Parada[], t: number) => {
  let x = paradas[0].x, y = paradas[0].y, z = paradas[0].z, r = paradas[0].r ?? 0;
  for (const p of paradas.slice(1)) {
    const k = interpolate(t, [p.at, p.at + (p.d ?? 0.85)], [0, 1], { ...cl, easing: Easing.bezier(0.65, 0, 0.35, 1) });
    x = lerp(k, x, p.x); y = lerp(k, y, p.y); z = lerp(k, z, p.z); r = lerp(k, r, p.r ?? 0);
  }
  // leve deriva de câmera na mão
  return { x: x + Math.sin(t * 0.6) * 6, y: y + Math.cos(t * 0.45) * 6, z: z * (1 + Math.sin(t * 0.3) * 0.006), r: r + Math.sin(t * 0.25) * 0.25 };
};

export const Mesa: React.FC<{ paradas: Parada[]; w: number; h: number; children: React.ReactNode }> = ({ paradas, w, h, children }) => {
  const t = useT();
  const { fps, width, height } = useVideoConfig();
  const c = camEm(paradas, t), c0 = camEm(paradas, t - 1 / fps);
  const vel = Math.hypot((c.x - c0.x) * c.z, (c.y - c0.y) * c.z) + Math.abs(c.z - c0.z) * 900;
  const blur = Math.min(16, vel * 0.22);
  return (
    <AbsoluteFill style={{ overflow: 'hidden', background: '#140D08' }}>
      <div style={{ position: 'absolute', left: 0, top: 0, width: w, height: h, transformOrigin: '0 0', transform: `translate(${width / 2}px, ${height / 2}px) rotate(${c.r}deg) scale(${c.z}) translate(${-c.x}px, ${-c.y}px)`, filter: `blur(${blur.toFixed(2)}px) sepia(.35) contrast(1.08) saturate(.9)` }}>
        <Madeira w={w} h={h} />
        {children}
      </div>
    </AbsoluteFill>
  );
};

/** Madeira escura com veios. */
const Madeira: React.FC<{ w: number; h: number }> = ({ w, h }) => (
  <div style={{ position: 'absolute', left: -1600, top: -1600, width: w + 3200, height: h + 3200,
    background: `repeating-linear-gradient(90deg, rgba(0,0,0,.0) 0 38px, rgba(0,0,0,.18) 38px 41px, rgba(0,0,0,0) 41px 120px),
      repeating-linear-gradient(90deg, rgba(255,200,140,.05) 0 7px, rgba(0,0,0,.06) 7px 13px),
      linear-gradient(180deg, #4A2E1C, #3A2416 40%, #4B2F1D 70%, #352013)` }} />
);

// ---------- look de filme ----------
export const Filme: React.FC<{ luz?: [number, number] }> = ({ luz = [50, 40] }) => {
  const t = useT();
  const f = useCurrentFrame();
  const respira = (Math.sin(t * 1.3) * 0.5 + Math.sin(t * 0.47) * 0.5) * 0.02; // luz que respira devagar, sem pisca-pisca
  return (
    <>
      <AbsoluteFill style={{ background: `radial-gradient(ellipse 70% 55% at ${luz[0] + Math.sin(t * 0.4) * 2}% ${luz[1]}%, rgba(255,190,110,.18), transparent 70%)`, mixBlendMode: 'screen' }} />
      <AbsoluteFill style={{ background: 'radial-gradient(ellipse 72% 62% at 50% 46%, transparent 45%, rgba(10,5,2,.55) 78%, rgba(5,2,1,.92) 100%)' }} />
      <AbsoluteFill style={{ background: 'rgba(120,70,20,.10)', mixBlendMode: 'multiply' }} />
      <AbsoluteFill style={{ opacity: 0.09, mixBlendMode: 'overlay' }}>
        <svg width="100%" height="100%"><filter id="grao"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={Math.floor(f / 2) % 23} /><feColorMatrix type="saturate" values="0" /></filter><rect width="100%" height="100%" filter="url(#grao)" /></svg>
      </AbsoluteFill>
      <AbsoluteFill style={{ background: `rgba(0,0,0,${0.04 + respira})` }} />
    </>
  );
};

// ---------- peças ----------
const sombra = '0 18px 30px rgba(0,0,0,.55), 0 4px 8px rgba(0,0,0,.4)';
/** Aparece deslizando e girando um pouco, com som de papel. */
export const Entra: React.FC<{ at: number; x: number; y: number; r?: number; de?: [number, number]; som?: string | null; children: React.ReactNode }> = ({ at, x, y, r = 0, de = [0, -160], som = 'papel', children }) => {
  const t = useT();
  const k = interpolate(t, [at, at + 0.45], [0, 1], { ...cl, easing: Easing.out(Easing.cubic) });
  return (
    <>
      {som && <Som at={at} s={som} v={0.35} />}
      <div style={{ position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) translate(${(1 - k) * de[0]}px, ${(1 - k) * de[1]}px) rotate(${r + (1 - k) * 6}deg)`, opacity: k }}>{children}</div>
    </>
  );
};

export const Tachinha: React.FC<{ x?: string | number; y?: number }> = ({ x = '50%', y = -14 }) => (
  <div style={{ position: 'absolute', left: x, top: y, width: 34, height: 34, marginLeft: -17, borderRadius: '50%', background: 'radial-gradient(circle at 35% 35%, #FF6B5E, #A3160E 60%, #5A0A05)', boxShadow: '3px 6px 6px rgba(0,0,0,.5)', zIndex: 3 }} />
);

export const Polaroide: React.FC<{ src: string; w: number; h?: number; legenda: string; pos?: string }> = ({ src, w, h, legenda, pos = 'center' }) => (
  <div style={{ background: '#F4EEE2', padding: '22px 22px 0', boxShadow: sombra, position: 'relative' }}>
    <Tachinha />
    <Img src={staticFile(src)} style={{ width: w, height: h ?? w * 0.75, objectFit: 'cover', objectPosition: pos, filter: 'grayscale(1) contrast(1.15) brightness(.95) sepia(.15)', display: 'block' }} />
    <div style={{ fontFamily: F.maquina, fontSize: 40, color: TINTA, textAlign: 'center', padding: '16px 0 22px', letterSpacing: 4 }}>{legenda}</div>
  </div>
);

/** Folha datilografada: as linhas aparecem letra a letra a partir de `de`, com o som das teclas. */
export const Datilografado: React.FC<{ w: number; topo?: string; linhas: { de: number; txt: string; dur?: number }[]; size?: number; children?: React.ReactNode }> = ({ w, topo, linhas, size = 52, children }) => {
  const t = useT();
  return (
    <div style={{ width: w, background: `linear-gradient(180deg, ${PAPEL}, ${PAPEL2})`, padding: '34px 44px 44px', boxShadow: sombra, position: 'relative', fontFamily: F.maquina, color: TINTA }}>
      <Tachinha x="12%" />
      {topo && <div style={{ fontSize: 26, letterSpacing: 6, opacity: 0.6, marginBottom: 22, borderBottom: '2px solid rgba(42,30,22,.25)', paddingBottom: 10 }}>{topo}</div>}
      {linhas.map((l, i) => {
        const dur = l.dur ?? Math.max(0.6, l.txt.length * 0.045);
        const n = Math.floor(interpolate(t, [l.de, l.de + dur], [0, l.txt.length], cl));
        const cursor = t >= l.de && t < l.de + dur + 0.6 && (t * 2.5) % 1 < 0.55;
        const sons = Math.min(l.txt.length, 40);
        return (
          <div key={i} style={{ fontSize: size, lineHeight: 1.3, minHeight: size * 1.3 }}>
            {l.txt.slice(0, n)}{cursor ? '▌' : ''}
            {Array.from({ length: sons }).map((_, j) => <Som key={j} at={l.de + (j * dur) / sons} s="maquina" v={0.18 + ((j * 37) % 10) / 60} d={0.2} />)}
            <Som at={l.de + dur + 0.05} s="sino" v={0.12} d={1.2} />
          </div>
        );
      })}
      {children}
    </div>
  );
};

export const PostIt: React.FC<{ txt: string; w?: number; size?: number; r?: number }> = ({ txt, w = 360, size = 60, r = 0 }) => (
  <div style={{ width: w, minHeight: w * 0.85, background: `linear-gradient(170deg, ${POSTIT}, #E3B53A)`, boxShadow: '0 14px 22px rgba(0,0,0,.45)', padding: '30px 26px', fontFamily: F.mao, fontWeight: 700, fontSize: size, lineHeight: 1.05, color: '#3A2A10', transform: `rotate(${r}deg)`, display: 'flex', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>{txt}</div>
);

/** Círculo vermelho de caneta que se desenha. */
export const Circulo: React.FC<{ at: number; w: number; h: number; som?: boolean }> = ({ at, w, h, som = true }) => {
  const t = useT();
  const p = interpolate(t, [at, at + 0.5], [1, 0], { ...cl, easing: Easing.inOut(Easing.cubic) });
  if (t < at) return null;
  return (
    <>
      {som && <Som at={at} s="papel" v={0.25} />}
      <svg width={w + 40} height={h + 40} style={{ position: 'absolute', left: -20, top: -20, overflow: 'visible', pointerEvents: 'none' }}>
        <ellipse cx={(w + 40) / 2} cy={(h + 40) / 2} rx={w / 2 + 10} ry={h / 2 + 6} fill="none" stroke={VERMELHO} strokeWidth={8} strokeLinecap="round" pathLength={1} strokeDasharray="1" strokeDashoffset={p} transform={`rotate(-3 ${(w + 40) / 2} ${(h + 40) / 2})`} />
      </svg>
    </>
  );
};
/** Risco vermelho que atravessa um texto. */
export const Risco: React.FC<{ at: number; w: number; y?: number }> = ({ at, w, y = 0 }) => {
  const t = useT();
  const k = interpolate(t, [at, at + 0.35], [0, 1], { ...cl, easing: Easing.out(Easing.cubic) });
  if (t < at) return null;
  return <div style={{ position: 'absolute', left: -12, top: y, width: (w + 24) * k, height: 10, background: VERMELHO, borderRadius: 6, transform: 'rotate(-2deg)', opacity: 0.92 }} />;
};
/** Letra de mão vermelha que aparece da esquerda pra direita. */
export const Mao: React.FC<{ at: number; txt: string; size?: number; cor?: string; dur?: number }> = ({ at, txt, size = 96, cor = VERMELHO, dur = 0.6 }) => {
  const t = useT();
  const k = interpolate(t, [at, at + dur], [0, 100], { ...cl, easing: Easing.out(Easing.quad) });
  if (t < at) return null;
  return <div style={{ fontFamily: F.mao, fontWeight: 700, fontSize: size, color: cor, lineHeight: 1, whiteSpace: 'nowrap', clipPath: `inset(-20% ${100 - k}% -20% -5%)` }}>{txt}</div>;
};

export const Carimbo: React.FC<{ at: number; txt: string; size?: number; r?: number }> = ({ at, txt, size = 70, r = -12 }) => {
  const t = useT();
  const k = interpolate(t, [at, at + 0.14], [0, 1], { ...cl, easing: Easing.in(Easing.cubic) });
  if (t < at) return null;
  return (
    <>
      <Som at={at + 0.1} s="carimbo" v={0.6} />
      <div style={{ transform: `scale(${lerp(k, 2.4, 1)}) rotate(${r}deg)`, opacity: k * 0.9, fontFamily: F.placa, fontWeight: 600, fontSize: size, color: VERMELHO, border: `8px solid ${VERMELHO}`, borderRadius: 14, padding: '4px 22px', letterSpacing: 4, whiteSpace: 'nowrap', mixBlendMode: 'multiply' }}>{txt}</div>
    </>
  );
};

/** Contador de placas: cada troca de `valores` gira as placas com o som mecânico. */
export const Placas: React.FC<{ trocas: { at: number; txt: string }[]; size?: number }> = ({ trocas, size = 150 }) => {
  const t = useT();
  const atual = [...trocas].reverse().find(x => t >= x.at) ?? trocas[0];
  const ini = atual.at;
  const girando = t >= ini && t < ini + 0.55;
  const L = Math.max(...trocas.map(x => x.txt.length));
  const txt = atual.txt.padStart(L, ' ');
  const CH = '0123456789$R,. ';
  return (
    <div style={{ display: 'flex', gap: 10, background: '#120E0B', padding: 18, borderRadius: 14, boxShadow: sombra, border: '4px solid #2B231C' }}>
      {trocas.map(x => <Som key={x.at} at={x.at} s="placas" v={0.5} />)}
      {txt.split('').map((c, i) => {
        const embaralha = girando && (t - ini) < 0.08 * (i + 1) + 0.15;
        const ch = embaralha ? CH[Math.floor((t * 40 + i * 7) % CH.length)] : c;
        return (
          <div key={i} style={{ width: size * 0.62, height: size * 1.1, background: 'linear-gradient(180deg, #2C2621 49%, #000 49% 51%, #221D19 51%)', borderRadius: 8, color: '#F3E9D2', fontFamily: F.placa, fontWeight: 600, fontSize: size * 0.82, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: 'inset 0 2px 0 rgba(255,255,255,.08)' }}>{ch === ' ' ? '' : ch}</div>
        );
      })}
    </div>
  );
};

/** Recorte de jornal. */
export const Jornal: React.FC<{ w: number; secao: string; titulo: React.ReactNode; texto?: string; children?: React.ReactNode }> = ({ w, secao, titulo, texto, children }) => (
  <div style={{ width: w, background: 'linear-gradient(175deg, #E8DFC9, #D6C8A7)', padding: '28px 34px 40px', boxShadow: sombra, position: 'relative', clipPath: 'polygon(0 2%, 4% 0, 30% 1.5%, 55% 0, 80% 1.2%, 100% 0, 99% 30%, 100% 62%, 98.5% 100%, 70% 98.6%, 40% 100%, 12% 98.4%, 0 100%, 1.2% 60%)' }}>
    <div style={{ fontFamily: F.courier, fontWeight: 700, fontSize: 24, letterSpacing: 6, borderBottom: '3px solid #2A1E16', paddingBottom: 8, color: '#2A1E16' }}>{secao}</div>
    <div style={{ fontFamily: F.jornal, fontWeight: 900, fontSize: 92, lineHeight: 0.98, color: '#1E1712', margin: '18px 0 14px' }}>{titulo}</div>
    {texto && <div style={{ columnCount: 2, columnGap: 26, fontFamily: F.courier, fontSize: 22, lineHeight: 1.35, color: '#3B3027', textAlign: 'justify' }}>{texto}</div>}
    {children}
  </div>
);

/** Barbante vermelho entre dois pontos da mesa, desenhado a partir de `at`. */
export const Barbante: React.FC<{ at: number; de: [number, number]; ate: [number, number] }> = ({ at, de, ate }) => {
  const t = useT();
  const k = interpolate(t, [at, at + 0.6], [0, 1], { ...cl, easing: Easing.inOut(Easing.cubic) });
  if (t < at) return null;
  const mx = (de[0] + ate[0]) / 2, my = (de[1] + ate[1]) / 2 + 70;
  return (
    <svg style={{ position: 'absolute', left: 0, top: 0, overflow: 'visible', pointerEvents: 'none' }} width={1} height={1}>
      <path d={`M${de[0]} ${de[1]} Q${mx} ${my} ${ate[0]} ${ate[1]}`} fill="none" stroke="#9E1B14" strokeWidth={7} strokeLinecap="round" pathLength={1} strokeDasharray="1" strokeDashoffset={1 - k} style={{ filter: 'drop-shadow(4px 8px 4px rgba(0,0,0,.5))' }} />
    </svg>
  );
};

/** Papel quadriculado com uma linha vermelha que sobe. */
export const Grafico: React.FC<{ at: number; w: number; h: number; topo: string }> = ({ at, w, h, topo }) => {
  const t = useT();
  const k = interpolate(t, [at, at + 1.6], [0, 1], { ...cl, easing: Easing.in(Easing.quad) });
  const pts = Array.from({ length: 14 }, (_, i) => { const x = i / 13; const y = Math.pow(x, 2.6) * 0.9 + Math.sin(i * 1.7) * 0.03; return [40 + x * (w - 80), h - 60 - y * (h - 140)]; });
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0]} ${p[1]}`).join(' ');
  return (
    <div style={{ width: w, height: h, position: 'relative', background: `#F1EAD8`, backgroundImage: 'linear-gradient(rgba(60,110,160,.18) 2px, transparent 2px), linear-gradient(90deg, rgba(60,110,160,.18) 2px, transparent 2px)', backgroundSize: '40px 40px', boxShadow: sombra }}>
      <Tachinha />
      <div style={{ position: 'absolute', left: 24, top: 18, fontFamily: F.courier, fontWeight: 700, fontSize: 26, letterSpacing: 5, color: '#4A3B2E' }}>{topo}</div>
      <svg width={w} height={h} style={{ position: 'absolute', inset: 0 }}><path d={d} fill="none" stroke={VERMELHO} strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray="1" strokeDashoffset={1 - k} /></svg>
    </div>
  );
};

/** Legenda discreta embaixo, palavra por palavra, em máquina de escrever. */
export const LegendaDossie: React.FC<{ W: Palavra[]; top?: number; size?: number }> = ({ W, top = 1640, size = 64 }) => {
  const t = useT();
  const grupos: Palavra[][] = []; let g: Palavra[] = [];
  W.forEach((w, i) => { g.push(w); if (/[.,!?:]$/.test(w.text) || g.length >= 4 || (W[i + 1] && W[i + 1].start - w.end > 0.35)) { grupos.push(g); g = []; } });
  if (g.length) grupos.push(g);
  const atual = grupos.find((gr, i) => t >= gr[0].start - 0.05 && t < (grupos[i + 1]?.[0].start ?? gr[gr.length - 1].end + 0.5));
  if (!atual) return null;
  return (
    <div style={{ position: 'absolute', left: 60, right: 60, top, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '0 18px' }}>
      {atual.map((w, i) => <span key={i} style={{ fontFamily: F.maquina, fontSize: size, lineHeight: 1.15, color: t >= w.start - 0.02 ? '#FFF3DC' : 'rgba(255,243,220,.35)', textShadow: '0 4px 14px rgba(0,0,0,.9), 0 0 3px rgba(0,0,0,.8)', textTransform: 'uppercase' }}>{w.text.replace(/[.,!?:]$/, '')}</span>)}
    </div>
  );
};

/** Troca números falados por extenso por algarismo na legenda (a voz continua por extenso).
 *  `troca`: pares [texto falado, texto da legenda]; a comparação ignora acento e pontuação. */
export const comAlgarismos = (W: Palavra[], troca: [string, string][]): Palavra[] => {
  const seqs = troca.map(([a, b]) => [a.split(' ').map(limpa), b] as [string[], string]).sort((x, y) => y[0].length - x[0].length);
  const out: Palavra[] = [];
  for (let i = 0; i < W.length; i++) {
    const m = seqs.find(([s]) => s.every((x, j) => W[i + j] && limpa(W[i + j].text) === x));
    if (m) {
      const ult = W[i + m[0].length - 1];
      out.push({ text: m[1] + (ult.text.match(/[.,!?:]$/)?.[0] ?? ''), start: W[i].start, end: ult.end });
      i += m[0].length - 1;
    } else out.push(W[i]);
  }
  return out;
};
